#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <conio.h>

#include "arraylist.h"
#include "funciones.h"


void em_calcularSueldo(void* p)
{
    if(((eEmpleado*)p)!=NULL){
        if(((eEmpleado*)p)->horasTrab<=176){
            ((eEmpleado*)p)->sueldo = ((eEmpleado*)p)->horasTrab * 180;
        }
        if(((eEmpleado*)p)->horasTrab>176 && ((eEmpleado*)p)->horasTrab<=208){
            ((eEmpleado*)p)->sueldo = ((eEmpleado*)p)->horasTrab * 270;
        }
        if(((eEmpleado*)p)->horasTrab>208 && ((eEmpleado*)p)->horasTrab<=240){
            ((eEmpleado*)p)->sueldo = ((eEmpleado*)p)->horasTrab * 360;
        }
    }
}
//**************************************************************************
int employee_setName(eEmpleado* Emp, char nombre[])
{
    //Emp->name;
    strcpy(Emp->nombre,nombre);
    return 0;

}
int employee_setID(eEmpleado* Emp, int id)
{
    //Emp->name;
    Emp->id=id;
    return 0;

}
//*****************************************************************************
int employee_setHora(eEmpleado* Emp, int HS)
{
    //Emp->name;
    Emp->horasTrab=HS;
    return 0;


}
//******************************************************************************
int employee_setSueldo(eEmpleado* Emp, float salario)
{
    //Emp->name;
    Emp->sueldo=salario;
    return 0;

}
//******************************************************************************
eEmpleado* newEmp()
{
    eEmpleado* aux;
    aux = (eEmpleado*) malloc (sizeof(eEmpleado));
    return aux;
}
//******************************************************************************
eEmpleado* newPersonParametros( char nombre[],int id, int hora)
{
    eEmpleado* Emp;

    Emp = newEmp();
    if(Emp!=NULL)
    {
        strcpy(Emp->nombre,nombre);

        Emp->id=id;
        Emp->horasTrab=hora;

    }

    return Emp;
}

//******************************************************************************
int parserEmployee( FILE* Archivo,ArrayList* lista,char nombreArch[])
{
    char  fitrs_name[50], id[10],Hra[10];
    eEmpleado* emp;
    int retorno;

    Archivo=fopen(nombreArch,"r");
    if(Archivo==NULL||lista==NULL)
    {
        retorno=0;
    }
    else
    {

        fscanf(Archivo, "%[^,],%[^,],%[^\n]\n",id,fitrs_name,Hra);

        while(!feof(Archivo))
        {

            fscanf(Archivo, "%[^,],%[^,],%[^\n]\n",id,fitrs_name,Hra);
            emp=newPersonParametros(fitrs_name,id,Hra);
            if(emp!=NULL)
            {

                employee_setName(emp,fitrs_name);
                emp->id=atoi(id);
                emp->horasTrab=atoi(Hra);
                if(feof(Archivo))
                {
                    break;
                }
                al_add(lista,emp);



            }


        }

        retorno=1;
    }


    fclose(Archivo);

    return retorno;


}
//*******************************************************************************
void employee_print(eEmpleado* Emp)
{
    printf("|%-5d\t\t%-15s\t\t%-15d\t\t%-15.2f|\n",Emp->id,Emp->nombre,Emp->horasTrab,Emp->sueldo);
}
//*******************************************************************************
void employeePrint(ArrayList* lista)
{
    eEmpleado* Emp;

        int i;
        printf("|===============================================================================|\n");
        printf("|                               EMPLEADOS                                       |\n");
        printf("|===============================================================================|\n");
        printf("| ID        |         NAME        |        HORAS    |    SUELDOS        \n");
        printf("|===============================================================================|\n");
        for(i=0; i<lista->len(lista); i++)
        {
             if(i>0)
            {
                if(i%50==0)
                {
                    system("pause");
                }
            }
            Emp = al_get(lista,i);
            employee_print(Emp);
        }


}
//**********************************************************************
void cargar(ArrayList* lista, FILE* archivo)
{
    int Arch;
    char respuesta[30];
    printf("Ingrese el nombre del archivo: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",respuesta);
    Arch=parserEmployee(archivo,lista,respuesta);
    if(Arch==0)
    {
        printf("\n Error al abrir el archivo\n");
    }
    else
    {
        printf("\n Archivo cargado con exito\n");

    }
   // employeePrint(lista);
}
//********************************************************
void generarArchivo(ArrayList* lista )
{
    int i;
    eEmpleado* Emp;
    FILE* archivo;
    archivo = fopen("out.csv","w");

    if(archivo!=NULL)
    {
        for(i=0; i<al_len(lista); i++)
        {

            Emp = al_get(lista,i);
            fprintf(archivo,"%d,%s,%d,%.2f\n",Emp->id,Emp->nombre,Emp->horasTrab,Emp->sueldo);

         }
         printf("Archivo generado correctamente!\n");
    }
    else
    {
        printf("Ha ocurrido un error!\n");
    }
    fclose(archivo);

}
