/**
 * Permite verificar si la cadena ingresada es un numero entero
 * @param array de char
 * @return 1 si es y 0 si no es
 */
int verifNumero(char cad[]);
/**
 * Pide que se ingrese el array hasta que sea un numero entero
 * @param array de char
 * @return array validado
 */
void isNumber(char aux[]);
/**
 * Muestra las distintas opciones que va a contener el programa
 * @param array de char
 * @return retorna la opcion seleccionada
 */
int menu(char auxOP[]);
/**
 * Permite verificar si la cadena ingresada es un numero flotante
 * @param array de char
 * @return 1 si es y 0 si no es
 */
int verifFloat(char cad[]);
/**
 * Pide que se ingrese el array hasta que sea un numero flotante
 * @param array de char
 * @return array validado
 */
void isFloat(char aux[]);
/**
 * Permite verificar si la cadena ingresada contiene solamente letras
 * @param array de char
 * @return 1 si es y 0 si no es
 */
int EsLetra(char letras[]);
/**
 * Pide que se ingrese el array hasta que solamente este contenga letras
 * @param array de char
 * @return array validado
 */
void isWord(char aux[]);
/**
 * Permite verificar si la cadena ingresada contiene solamente letras y numeros
 * @param array de char
 * @return 1 si es y 0 si no es
 */
int VefAphaandNumber(char aux[]);
/**
 * Pide que se ingrese el array hasta que solamente contenga letras y numeros
 * @param array de char
 * @return array validado
 */
void isAlphaNumber(char aux []);
/** \brief Modifica todo dato que solamente este compuesto por letras
  * \param un char que determiana si se hace la modificacion o no
  * \param el array el cual queremos modificar
  * \return el array modificado
  *
  */
