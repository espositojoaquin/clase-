
typedef struct
{
   int id;
   char NombreAP[50];
   char direccion[70];
   long long int tarjeta;
   int estado;
}EPropietario;
typedef struct
{
   int idPropietario;
   char patente[50];
   char marca[50];
   long long int tarjeta;
   float hora;
   int estado;
}EAuto;

 void inicializarRP(EPropietario propietario[],int tam);
 int EspacioLibre(EPropietario propietario[],int tam);
 void IngresoDatos(EPropietario propietario[],int tam);
 void mostrarPersonaIgresada(EPropietario propietario);
 void altaPropietario(EPropietario gente[],int tam);
 void inicializarRPA(EAuto propietario[],int tam);
 void IngresoDatosA(EAuto propietario[],int tam);
 void mostrarPersonaIgresadaA(EAuto gente);
 int EspacioLibreA(EAuto propietario[],int tam);
 void altaAuto(EAuto gente[],int tam);
 void Egreso(EAuto gente[],EPropietario propietario[],int TAM);
 void harcodear(EPropietario propietario[], int tam);
 void harcodear2( EAuto autos[], int tam);


