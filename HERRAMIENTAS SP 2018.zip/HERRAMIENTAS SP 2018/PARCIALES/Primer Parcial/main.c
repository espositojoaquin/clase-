#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "funciones.h"
#define TAM 10
#define TAMA 20

int main()
{
    char seguir='s';
    int opcion=0;


    ECliente cliente[TAM];
    EAlquiler alquiler[TAMA];

    inicializarRP(cliente,TAM);
    inicializarRPA(alquiler,TAMA);
     system("color C");
     printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\tALQUILERES GERMIN\n\n\n\n\n\n\n\n\n\n");
     printf("Si quiere ingresar: ");
     system("pause");
     system("cls");


     system("Color 4F");
    while(seguir=='s')
    {
        printf("\t\tREGISTRO DE ALQUILERES\n");
        printf("\n1- Alta de Cientes\n");
        printf("2- Modificar datos del Cliente\n");
        printf("3- Baja del Cliente\n");
        printf("4- Nuevo Alquiler\n");
        printf("5- Fin del alquiler\n");
        printf("6- Informe\n");
        printf("7- Harcodeo\n");
        printf("8- Salir\n");



        printf("\ningrese una opcion: ");

        scanf("%d",&opcion);
        system("pause");
        system("cls");
        while(opcion<1||opcion>7)
        {
            printf("Reingrese una opcion (1-7) :");

            scanf("%d",&opcion);
            system("pause");
            system("cls");

        }

        switch(opcion)
        {

        case 1:
            altaCliente(cliente,TAM);
            system("pause");
            system("cls");


            break;
        case 2:
            ModificarP(cliente,TAM);
            system("pause");
            system("cls");

            break;
        case 3:
            BajaC(cliente,TAM);
            system("pause");
            system("cls");

            break;
        case 4:
            altaAlquiler(alquiler,cliente,TAMA,TAM);
            system("pause");
            system("cls");

            break;
        case 5:
            finDeAlquiler(alquiler,TAMA);
            system("pause");
            system("cls");

            break;
        case 6:
            clientesYalquileres(cliente,alquiler,TAM,TAMA);
            MasAlquilado(alquiler,cliente,TAMA,TAM);
            clienteMasA(alquiler,cliente,TAM,TAMA);
            promedioHoras(alquiler,TAMA);
            system("pause");
            system("cls");


            break;
        case 7:
            HardCode(cliente,TAM);
            HardCodeA(alquiler,TAMA);

            break;
        case 8:
            seguir = 'n';
            break;

        }
    }

}
