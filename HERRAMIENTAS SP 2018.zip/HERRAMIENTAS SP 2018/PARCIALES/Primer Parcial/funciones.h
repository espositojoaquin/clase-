
typedef struct
{
    int idCliente;
    int dni;
    char nombre[30];
    char Apellido[30];
    int alquileres;
    int estado;

}ECliente;

typedef struct
{
    int cliente;
    int id;
    int equipo;
    float tiempoEstimado;
    float tiempoReal;
    char Operador[30];
    int estado;
}EAlquiler;

void inicializarRP(ECliente cliente[],int tam);
int EspacioLibre(ECliente cliente[],int tam);
void IngresoDatos(ECliente cliente[],int tam);
void mostrarPersonaIgresada(ECliente cliente);
int validacionDNI(ECliente cliente[],int tam,int);
void altaCliente(ECliente cliente[],int tam);
//*****************************************************
void inicializarRPA(EAlquiler alquiler[],int tam);
int EspacioLibreA(EAlquiler alquiler[],int tam);

void HardCode(ECliente gente[],int tam);
void mostrar(ECliente gente[],int tam);
void HardCodeA(EAlquiler alquiler[],int tam);
void clientesYalquileres(ECliente cliente[],EAlquiler alquiler[],int tam,int tamA);
void ModificarP(ECliente gente[],int tam);
void BajaC(ECliente gente[],int tam);
 void IngreseAlquiler(EAlquiler alquiler[],ECliente clientes[],int tamA,int tamC);
void altaAlquiler(EAlquiler alquiler[],ECliente cliente[],int tamA,int tamC);

void finDeAlquiler(EAlquiler alquiler[],int tam);

void promedioHoras(EAlquiler alquiler[],int tam);
void MasAlquilado(EAlquiler alquiler[],ECliente cliente[],int tam,int tamC);
void clienteMasA(EAlquiler alquiler[],ECliente cliente[],int tamC,int tamA);

//void Equipo(EAlquiler alquiler[],ECliente cliente[],int tam,int tamC);







