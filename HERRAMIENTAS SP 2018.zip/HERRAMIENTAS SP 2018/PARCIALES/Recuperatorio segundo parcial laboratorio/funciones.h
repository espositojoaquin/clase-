typedef struct
{
    int id;
    char nombre[30];
    int edad;
    char profesion[20];

}eEmpleados;

/** \brief crea un empleado
 *
 * \return el empleado
 *
 */
eEmpleados* newEmpleado();

//** \brief crea un empleado con datos
// *
// * \param id el id del empleado
// * \param edad la edad del empleado
// * \param profesion la profesion del empleado
// * \return el empleado creado con datos
// *
// */
//eEmpleados* newEmpleadoConParametros(int, int, char[]);

/** \brief lee un archivo con datos y los carga en memoria
 *
 * \param archivo el archivo a leer
 * \param lista la lista dinamica
 * \return 1 o 0 si pudo leer o no
 *
 */
int leerEmpleados(ArrayList* lista);

/** \brief filtra empleados
 *
 * \param item lo que se deseea filtrar
 * \return si pudo realizar el filtro
 *
 */
int funcionQueFiltra(void*);

/** \brief guarda los datos filtrados
 *
 * \param lista la lista dinamica
 *
 */
void guardarOut(ArrayList* lista);

/** \brief muestra los empleados
 *
 * \param lista la lista dinamica
 *
 */
void mostrar(ArrayList* lista);
