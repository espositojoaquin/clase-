#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "funciones.h"

eEmpleados* newEmpleado()
{
    eEmpleados* aux;
    aux = (eEmpleados*) malloc (sizeof(eEmpleados));
    return aux;
}

/*eEmpleados* newEmpleadoConParametros(int id, int edad, char profesion[])
{
    eEmpleados* empleado;
    // ArrayList* lista;

    empleado = newEmpleado();

    if(empleado!=NULL)
    {
        empleado->id = id;
        empleado->edad = edad;
        strcpy(empleado->profesion, profesion);
    }

    return empleado;
}
*/
int leerEmpleados(ArrayList* lista)
{
    FILE* archivo;
    eEmpleados* empleado;

    int retorno = 0;
    char nombre[100],profesion[100],edad[20],id[20];

    archivo = fopen("empleados.csv","r");

    if(archivo!=NULL && lista != NULL)
    {
        while(!feof(archivo))
        {
            fscanf(archivo, "%[^,],%[^,],%[^,],%[^\n]\n",id,nombre,profesion,edad);

            empleado = newEmpleado();

            strcpy(empleado->nombre,nombre);
            strcpy(empleado->profesion,profesion);
            empleado->id=atoi(id);
            empleado->edad=atoi(edad);

            al_add(lista,empleado);
        }
        retorno = 1;
    }

    fclose(archivo);

    return retorno;
}

int funcionQueFiltra(void* item)
{
    int retorno;

    if(stricmp(((eEmpleados*)item)->profesion, "programador") == 0 && ((eEmpleados*)item)->edad >= 30)
    {
        retorno = 1;
    }
    else
    {
        retorno = 0;
    }
    return retorno;
}

void guardarOut(ArrayList* lista)
{
    FILE* archivo;
    eEmpleados* empleado;
    int i;

    archivo = fopen("out.csv","w");

    for(i=0; i<al_len(lista); i++)
    {
        //empleado = newEmpleado();
        empleado = al_get(lista,i);
        fprintf(archivo,"%d,%s,%d,%s\n",empleado->id, empleado->nombre, empleado->edad, empleado->profesion);

    }
    printf("Archivo OUT.CSV generado correctamente!!!\n");

}

void mostrar(ArrayList* lista)
{
    eEmpleados* empleado;
    int i;

    if(lista->isEmpty(lista)==0)
    {
        printf("\nID\t\tNombre\t\t\tEdad\t\tProfesion\n\n");
        for(i=0; i<lista->len(lista); i++)
        {
            empleado = (eEmpleados*)lista->get(lista,i);

            printf("%d\t\t%s\t\t%d\t\t%s\n",empleado->id,empleado->nombre,empleado->edad,empleado->profesion);

        }
    }
    else
    {
        printf("\nNo hay empleados cargados!!!\n");
    }

}
