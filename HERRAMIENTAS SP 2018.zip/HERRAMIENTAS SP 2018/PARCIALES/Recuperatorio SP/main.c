#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Funciones.h"

int main()
{
    char seguir='s';
    int opcion=0;
    int Arch;
    eEmpleado* empleado;
    ArrayList* lista;
    ArrayList* sublista;
    sublista= al_newArrayList();
    lista = al_newArrayList();
    int i;

     FILE* archivo;
     system("color 2E");
     printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\tEMPRESA\n\n\n\n\n\n\n\n\n\n");
     printf("Si quiere ingresar: ");
     system("pause");
     system("cls");
    system("color 4F");


    while(seguir=='s')
    {
        printf("1- Cargar lista de Empleados\n");
        printf("2- Listar\n");
        printf("3- Filtrar\n");
        printf("4- Archivo de texto\n");
        printf("5- Generar archivos\n");
        printf("6- Salir\n");

        printf("\nIngrese una opcion: ");
        scanf("%d",&opcion);
        system("cls");

        switch(opcion)
        {
        case 1:
            Arch=leerEmpleados(lista);
            if(Arch==0)
            {
                printf("\n Error al abrir el archivo\n");
            }
            else
            {
                printf("\n Archivo cargado con exito\n");

            }
            system("pause");
            system("cls");

            break;
        case 2: mostrarEmpleado(lista);

            break;
        case 3:

                sublista=al_filter(lista,funcionQueFiltra);
                mostrarEmpleado(sublista);

            break;
        case 4:    generarArchivo(sublista);

            break;
        case 5:

            break;
        case 6:
            seguir = 'n';
            break;

        default:
        {
            printf("\nPor favor ingrese una opcion entre (1-6)\n");
        }



        }

    }

    return 0;
}
