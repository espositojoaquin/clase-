#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Funciones.h"

eEmpleado* newEmpleado()
{
    eEmpleado* empleado;
    empleado=(eEmpleado*)malloc(sizeof(eEmpleado));
    return empleado;
}
eEmpleado* newEmpleadoPar(char nombre[],int edad, char profesion[])
{
    eEmpleado* empleado;
    empleado=newEmpleado();

    if(empleado!=NULL)
    {
        strcpy(empleado->nombre,nombre);
        empleado->edad=edad;
        strcpy(empleado->profesion,profesion);
    }
    return empleado;
}
int LeerTareas( FILE* Archivo,ArrayList* lista)
{
    char nombre[20],edad[20],ocupasion[20];
    eEmpleado* empleado;
    int retorno;
    int Ed;
    Archivo=fopen("Empleados.csv","r");
    if(Archivo==NULL||lista==NULL)
    {
        retorno=0;
    }
    else
    {

        fscanf(Archivo, "%[^,],%[^,],%[^\n]\n",nombre,edad,ocupasion);

        while(!feof(Archivo))
        {
            fscanf(Archivo, "%[^,],%[^,],%[^\n]\n",nombre,edad,ocupasion);

            empleado=newEmpleadoPar(nombre,edad,ocupasion);
            if(empleado!=NULL)
            {
                Ed=atoi(edad);
                strcpy(empleado->nombre,nombre);
                strcpy(empleado->profesion,ocupasion);
                empleado->edad=Ed;
                al_add(lista,empleado);

            }

        }

        retorno=1;
    }


    fclose(Archivo);

    return retorno;

}

void mostrarEmpleado(ArrayList* lista)
{
    eEmpleado* empleado;
    if(lista->isEmpty(lista)==0)
    {
        int i;
        printf("|===============================================================================|\n");
        printf("|                              TABLA DE TAREAS                                  \n");
        printf("|===============================================================================|\n");
        printf("|    NOMBRE  |    EDAD      |   PROFESION     |              \n");
        printf("|===============================================================================|\n");
        for(i=0; i<lista->len(lista); i++)
        {
            empleado=(eEmpleado*)lista->get(lista,i);

            printf("|%-20s%-20d%-10s|\n",empleado->nombre,empleado->edad,empleado->profesion);
            printf("|===============================================================================|\n");
        }
    }
    else
    {
        printf("\nNo hay Empleados ingresadas");
    }

}

int funcionQueFiltra(void* empleado)
{
    int retorno;
    if(((eEmpleado*)empleado)->edad>30)
    {
        if(strcmpi(((eEmpleado*)empleado)->profesion,"Programador")==0)
        {
           retorno=1;
        }
        else
        {
            retorno=0;
        }
    }
    else
    {
        retorno=0;
    }
    return retorno;
}

 void generarArchivo(ArrayList* lista )
{
    int i;
    eEmpleado* empleado;
    FILE* archivo;
    archivo = fopen("out.csv","w");

    if(archivo!=NULL)
    {
        for(i=0; i<al_len(lista); i++)
        {

            empleado = al_get(lista,i);
            fprintf(archivo,"%s, %d, %s \n",empleado->nombre,empleado->edad,empleado->profesion);

         }
         printf("Archivo generado correctamente!\n");
    }
    else
    {
        printf("Ha ocurrido un error!\n");
    }
    fclose(archivo);

}




