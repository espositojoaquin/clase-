
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Funciones.h"

EClub* newClub()
{
    EClub* aux;
    aux = (EClub*) malloc (sizeof(EClub));
    return aux;
}
EClub* newClubParametros( char nombre[],int posicion,int seguidores,char apodo[])
{
    EClub* Club;
    ArrayList* lista;

    Club = newClub();
    if(Club!=NULL)
    {
        strcpy(Club->nombre,nombre);
        Club->posicion=posicion;
        Club->seguidores=seguidores;
        strcpy(Club->apodo,apodo);


    }

    return Club;
}
int cargarBinario( EClub* Club,ArrayList* lista)
{
    int retorno=-1;
    FILE* bin;
    bin=fopen("Club.dat","rb");

    fread(Club,sizeof(EClub),al_len(lista),bin);
    retorno=0;
    fclose(bin);
    return retorno;
}
void generarBinario(ArrayList* lista,  EClub* aux)
{
    int i;
    FILE* bin;
    bin = fopen("Club.dat","wb");

    if(bin != NULL)
    {
        for(i=0; i<al_len(lista); i++)
        {
            aux = newClub();
            aux = al_get(lista,i);
            fwrite(aux, sizeof(EClub),al_len(lista),bin);
        }
        printf("Archivo generado correctamente!\n");
    }
    else
    {
        printf("Ha ocurrido un error!\n");
    }
    fclose(bin);

}


void agregarClub(ArrayList* lista)
{
    EClub* club;
    char nombre[50],apodo[50];
    int posicion,seguidores;
    int i,j;
    EClub* equipo;


    printf("\nPor favor ingrese el nombre del Club\n ");
    fflush(stdin);
    gets(nombre);

    printf("\nPor favor ingrese el apodo del Club\n ");
    fflush(stdin);
    gets(apodo);

    printf("\Por favor ingrese la cantidad de seguidores\n");
    scanf("%d",&seguidores);

    printf("\Por favor ingrese la posicion de su equipo \n");
    scanf("%d",&posicion);
    for(i=0; i<lista->len(lista); i++)
    {
        club=(EClub*)lista->get(lista,i);
        while(posicion==club->posicion)
        {
            printf("\n Por favor ingrese una posicion diferente\n");
            scanf("%d",&posicion);


        }
        while(posicion>22||posicion<1)
        {
            printf("\n Por favor ingrese una posicion entre (1-22)\n");
            scanf("%d",&posicion);

        }


    }
    club=newClubParametros(nombre,posicion,seguidores,apodo);

    if(club!=NULL)
    {
        lista->add(lista,club);
        printf("\n El club fue Cargado con exito");


    }


}
void mostrarClub(ArrayList* lista)
{
    EClub* club;
    if(lista->isEmpty(lista)==0)
    {
        int i;
        printf("|===============================================================================|\n");
        printf("|                               TABLA DE POSICIONES                     \n");
        printf("|===============================================================================|\n");
        printf("| POSICION      |    EQUIPO      |        APODO     |         SEGUIDORES     \n");
        printf("|===============================================================================|\n");
        for(i=0; i<lista->len(lista); i++)
        {
            club=(EClub*)lista->get(lista,i);

            printf("|%-5d\t\t%-10s\t\t %-15s\t %-15d|\n",club->posicion,club->nombre,club->apodo,club->seguidores);
            printf("|===============================================================================|\n");
        }
    }
    else
    {
        printf("\nNo hay equipos ingresados");
    }

}

void EliminarClub(ArrayList* lista)
{
    EClub* club;
    char respuesta;
    int i,posicion;
    int auxI;

    printf("\nIngrese la posicion del equipo que desea eliminar\n");
    scanf("%d",&posicion);
    club=(EClub*)lista->get(lista,posicion-1);

    auxI=lista->indexOf(lista,club);

    if(auxI!=-1)
    {
        club=(EClub*)lista->get(lista,auxI);
        printf("\n %s\t %s\t %d\t %d\n",club->nombre,club->apodo,club->posicion,club->seguidores);

        printf("\nDesea eliminar este Club??(s/n)\n");
        fflush(stdin);
        scanf("%c",&respuesta);
        if(respuesta=='s')
        {

            for(i=auxI; i<lista->len(lista); i++)
            {
                club=(EClub*)lista->get(lista,i);
                club->posicion=(club->posicion-1);

            }
            lista->remove(lista,auxI);
            printf("Club eliminado\n");



        }
        else
        {
            printf("\nEliminacion cancelada\n");
        }
    }
    else
    {
        printf("\nClub inexistente\n");
    }



}

void ModifocarClub(ArrayList* lista)
{
    EClub* club;
    char respuesta;
    int i,posicion;
    int auxI=-1;

    printf("\nIngrese la posicion del equipo que desea modificar\n");
    scanf("%d",&posicion);
    club=(EClub*)lista->get(lista,posicion-1);
    auxI=lista->indexOf(lista,club);

    if(auxI!=-1)
    {
        club=(EClub*)lista->get(lista,auxI);
        printf("\n %s\t %s\t %d\t %d\n",club->nombre,club->apodo,club->posicion,club->seguidores);
        printf("\nDesea modificar este Club??(s/n)\n");
        fflush(stdin);
        scanf("%c",&respuesta);
        if(respuesta=='s')
        {
            printf("\nPor favor ingrese el nombre del Club\n ");
            fflush(stdin);
            gets(club->nombre);

            printf("\nPor favor ingrese el apodo del Club\n ");
            fflush(stdin);
            gets(club->apodo);

            printf("\Por favor ingrese la cantidad de seguidores\n");
            scanf("%d",&club->seguidores);

            printf("\Por favor ingrese la posicion de su equipo \n");
            scanf("%d",&club->posicion);

            club=(EClub*)lista->set(lista,auxI,club);



        }
        else
        {
            printf("\nModificacion cancelada cancelada\n");
        }
    }
    else
    {
        printf("\nClub inexistente\n");
    }

}
void PosicionEspecificada(ArrayList* lista )
{
    EClub* club;
    int i;
    char nombre[50], apodo[50];
    int aux,posicion,seguidores;

    printf("\nPor favor ingrese el nombre del Club\n ");
    fflush(stdin);
    gets(nombre);

    printf("\nPor favor ingrese el apodo del Club\n ");
    fflush(stdin);
    gets(apodo);

    printf("\Por favor ingrese la cantidad de seguidores\n");
    scanf("%d",&seguidores);

    printf("\nPor favor ingrese la posicion donde quiere ubicar su club \n");
    scanf("%d",&posicion);

    for(i=posicion-1; i<lista->len(lista); i++)
    {
        club=(EClub*)lista->get(lista,i);
        club->posicion=(club->posicion+1);

    }
    club = newClubParametros(nombre,posicion,seguidores,apodo);
    if(lista->push(lista,posicion,club)==0)
    {
        printf("\nSu club fue insertado correctamente");

    }
    else
    {
        printf("\n No se ha podido a�adir este nuevo equipo");
    }


}

int comparaEquipo(void* club,void* Equipo)
{

    if(((EClub*)club)->posicion > ((EClub*)Equipo)->posicion)
    {
        return 1;
    }
    if(((EClub*)club)->posicion < ((EClub*)Equipo)->posicion)
    {
        return -1;
    }
    return 0;
}
//*******************************************************
int LeerEquipos( FILE* Archivo,ArrayList* lista)
{
    char  posicion[500],nombre[500], apodo[500],seguidores[500];
    EClub* Equipo;
    int retorno;
    Archivo=fopen("arch.csv","r");
    if(Archivo==NULL||lista==NULL)
    {
        retorno=0;
    }
    else
    {

        fscanf(Archivo, "%[^,],%[^,],%[^,],%[^\n]\n",nombre,apodo,posicion,seguidores);

        while(!feof(Archivo))
        {
            fscanf(Archivo, "%[^,],%[^,],%[^,],%[^\n]\n",nombre,apodo,posicion,seguidores);

            Equipo=newClubParametros(nombre,posicion,seguidores,apodo);
            if(Equipo!=NULL)
            {


                Equipo->posicion=atoi(posicion);
                strcpy(Equipo->nombre,nombre);
                strcpy(Equipo->apodo,apodo);
                Equipo->seguidores=atoi(seguidores);

                al_add(lista,Equipo);


            }

        }

        retorno=1;
    }


    fclose(Archivo);

    return retorno;


}
void EquiposLIB(ArrayList* lista)
{
    ArrayList* pList2=NULL;
    int tam,i;
    tam=lista->size;
    EClub* club;
    pList2 = al_newArrayList();

    for(i=0; i<lista->len(lista); i++)
    {
        club=(EClub*)lista->get(lista,i);
        if(lista->len(lista)>5)
        {
            if(club->posicion>0&&club->posicion<6)
            {
                al_add(pList2,al_get(lista,i));
            }
        }
        else
        {
            al_add(pList2,al_get(lista,i));
        }

    }
    mostrarClub(pList2);


    //Sublista=lista->subList(lista,0,4);
    /* if(0<=tam && 0>-1 )
     {

         if(pList2!=NULL)
         {
             for(i=0; i<5; i++)
             {
                 al_add(pList2,al_get(lista,i));
             }
         }

     }*/



}







