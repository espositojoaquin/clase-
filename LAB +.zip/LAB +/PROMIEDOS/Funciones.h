
typedef struct
{
    int posicion;
    char nombre[50];
    int seguidores;
    char apodo[50];
}EClub;

EClub* newClub();
//void generarBinario(ArrayList* lista, FILE* bin)
void agregarClub(ArrayList* lista);
void mostrarClub(ArrayList* lista);
int cargarBinario( EClub* ,ArrayList* lista);
void guardarBinario(EClub* club,ArrayList* lista);
void EliminarClub(ArrayList* lista);
void ModifocarClub(ArrayList* lista);
void PosicionEspecificada(ArrayList* lista);
int comparaEquipo(void* club,void* Equipo);
int LeerEquipos( FILE* Archivo,ArrayList* lista);
void EquiposLIB(ArrayList* lista);
EClub* newClubParametros( char nombre[],int posicion,int seguidores,char apodo[]);



