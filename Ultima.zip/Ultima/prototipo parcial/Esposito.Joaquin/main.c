#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Funciones.h"

int main()
{
    char seguir='s';
    int opcion=0;
    int Arch;
    ArrayList* lista;
    ArrayList* sublista;

    sublista= al_newArrayList();

    lista = al_newArrayList();
    int i;

    FILE* archivo;
     system("color 2E");
     printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\tEMPRESA\n\n\n\n\n\n\n\n\n\n");
     printf("Si quiere ingresar: ");
     system("pause");
     system("cls");
    system("color 4F");


    while(seguir=='s')
    {
        printf("1- \n");
        printf("2- \n");
        printf("3-\n");
        printf("4- \n");
        printf("5-\n");
        printf("6- Salir\n");

        printf("\nIngrese una opcion: ");
        scanf("%d",&opcion);
        system("cls");

        switch(opcion)
        {
        case 1:
            Arch=LeerEmpleados(archivo,lista);
            if(Arch==0)
            {
                printf("\n Error al abrir el archivo\n");
            }
            else
            {
                printf("\n Archivo cargado con exito\n");

            }
            system("pause");
            system("cls");

            break;
        case 2:

            break;
        case 3:



            break;
        case 4:

            break;
        case 5:


            break;
        case 6:
            seguir = 'n';
            break;

        default:
        {
            printf("\nPor favor ingrese una opcion entre (1-6)\n");
        }



        }

    }

    return 0;
}
