typedef struct
{
    char Tarea[10];
    int importancia;
    int hora;
}ETarea;

ETarea* newTarea();
ETarea* newTareaParametros(char nombre[],int importancia,int horas);
int LeerTareas( FILE* Archivo,ArrayList* lista);
int comparaTarea(void* tarea,void* deber);
void mostrarTareas(ArrayList* lista);
void particionar(ArrayList* lista,ArrayList* sublist,ArrayList* sublista2);
void ResolverTarea(ArrayList* sublista,ArrayList* sublista2);
void generarAlta(ArrayList* lista);




