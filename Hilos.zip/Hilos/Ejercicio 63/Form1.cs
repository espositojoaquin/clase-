﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace Ejercicio_63
{
    public partial class Form1 : Form
    {
        Thread t1;
        delegate void Hilo(string hilo);
        public Form1()
        {
            InitializeComponent();
            t1= new Thread(Actualizar);
            t1.Start();
         
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Thread t1= new Thread(Actualizar);

            while(true)
            {

             t1.Start();
            System.Threading.Thread.Sleep(1000);

            }

        }

        public void AsignarHora(string hora)
        {
            if(this.label1.InvokeRequired)
            {
                Hilo h = new Hilo(this.AsignarHora);
                object[] objs = new object[] { hora };
                this.Invoke(h,objs);
            }
            else
            {
                label1.Text = hora;
            }
      


        }
        public void Actualizar()
        {
            do
            {

                string hora = DateTime.Now.ToString(("dd/MM/yyyy hh:mm:ss"));
                System.Threading.Thread.Sleep(1000);
                this.AsignarHora(hora);

            } while (t1.IsAlive);

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            t1.Abort();
        }
    }
}
