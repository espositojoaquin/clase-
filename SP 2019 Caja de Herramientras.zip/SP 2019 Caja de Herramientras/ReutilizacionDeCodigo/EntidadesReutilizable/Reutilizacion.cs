﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntidadesReutilizable
{
    public class Reutilizacion
    {
        #region Costructores
        /* static Moto()
          {
              valorhora = 30;
          }

          public Moto(string patente, int cilin) : base(patente)
          {
              this.cilindradra = cilin;
          }

          public Moto(string patente, int cilindrada, short ruedas) : this(patente, cilindrada)
          {
              this.ruedas = ruedas;
          }

          public Moto(string patente, int cilindrada, short ruedas, int valor) : this(patente, cilindrada, ruedas)
          {
              valorhora = valor;
          }


        static Robot()
        {
            Robot.capacidadEnergia = 50;
            Robot.contador = 0;
        }

        protected Robot()
        {
            this.origen = "Coreano";
            this.energia = 10;
            Robot.contador += 1;
            this.codigo = contador;
        }

        public Robot(int energia, string origen) : this()
        {
            this.energia = energia;
            this.origen = origen;
        }
          
         */

        #endregion

        #region Propiedades
        /* public DirectorTecnico DirectorTecnico
         {
             set
             {
                 if (value != null)
                 {
                     if (value.ValidarAptitud())
                     {
                         this.directorTecnico = value;
                     }
                 }


             }
         }*/
        #endregion

        #region Operador == y !=

        /// <summary>
        /// Son iguales si el codigo es el mismo 
        /// </summary>
        /// <param name="rob1"></param>
        /// <param name="rob2"></param>
        /// <returns></returns> true si ubo igualdad false sino
        public static bool operator ==(Robot rob1, Robot rob2)
        {
            bool retorno = false;
            if (!(rob1 is null) && !(rob2 is null))
            {
                if (rob1.Codigo == rob2.Codigo)
                {
                    retorno = true;
                }
            }
            return retorno;
        }

        public static bool operator !=(Robot rob1, Robot rob2)
        {
            bool retorno = false;
            if (!(rob1 is null) && !(rob2 is null))
            {
                retorno = !(rob1 == rob2);

            }
            return retorno;
        }
        //***********************************************************************************
        /// <summary>
        /// Seran iguales si robot se encuentra dentro de arena
        /// </summary>
        /// <param name="are"></param>
        /// <param name="rob"></param>
        /// <returns></returns> true si ubo igualdad false sino
        public static bool operator ==(Arena are, Robot rob)
        {
            bool retorno = false;
            if (rob is RobotDeCombate)
            {
                foreach (RobotDeCombate item in are.robotsDeCombate)
                {
                    if (item == rob)
                    {
                        retorno = true;
                        break;
                    }
                }
            }
            else if (rob is RobotSirviente)
            {
                foreach (RobotSirviente item in are.robotsSirvientes)
                {
                    if (item == rob)
                    {
                        retorno = true;
                        break;
                    }
                }
            }

            return retorno;

        }

        public static bool operator !=(Arena are, Robot rob)
        {
            return !(are == rob);
        }
        //***********************************************************************************
        public static bool operator ==(Estacionamiento est, Vehiculo vehi)
        {
            bool retorno = false;

            foreach (Vehiculo item in est.vehiculos)
            {
                if (item == vehi)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }
        public static bool operator !=(Estacionamiento est, Vehiculo vehi)
        {
            return !(est == vehi);
        }
        //************************************************************************************
        public static bool operator ==(Equipo equi, Jugador jug)
        {
            bool retorno = false;

            foreach (Jugador item in equi.jugadores)
            {
                if (item == jug)
                {
                    retorno = true;
                    break;
                }
            }
            return retorno;
        }

        public static bool operator !=(Equipo equi, Jugador jug)
        {
            return !(equi == jug);
        }
        #endregion

        #region Operador +
        /// <summary>
        /// Agrega un jugagador al equipo en caso de que no este en ella 
        /// </summary>
        /// <param name="equi"></param>
        /// <param name="jug"></param>
        /// <returns></returns> el dato con los datos cagados en caso de que se haya podido
        public static Equipo operator +(Equipo equi, Jugador jug)
        {
            if (equi.jugadores.Count < Equipo.cantidadMaximaJugador)
            {
                if (equi != jug)
                {
                    if (jug.ValidarAptitud())
                    {
                        equi.jugadores.Add(jug);
                    }
                }
            }

            return equi;

        }
        //********************************************************************************
        public static Arena operator +(Arena are, Robot rob)
        {
            if (are != rob)
            {
                if (rob is RobotDeCombate)
                {
                    are.robotsDeCombate.Add((RobotDeCombate)rob);
                }
                else
                {
                    are.robotsSirvientes.Add((RobotSirviente)rob);
                }
            }
            return are;
        }
        //********************************************************************************
        public static Estacionamiento operator +(Estacionamiento est, Vehiculo vehi)
        {
            if (est.vehiculos.Count < est.espacioDisponible)
            {
                if (vehi.Patente != null)
                {
                    if (est != vehi)
                    {
                        est.vehiculos.Add(vehi);
                    }
                }
            }

            return est;
        }

        #endregion

        #region Operador -
        /// <summary>
        /// Saca un elemnto de la lista en caso que lo encuentra
        /// </summary>
        /// <param name="are"></param>
        /// <param name="rob"></param>
        /// <returns></returns> clase de la lista 
        public static Arena operator -(Arena are, Robot rob)
        {
            if (are == rob)
            {
                if (rob is RobotDeCombate)
                {
                    are.robotsDeCombate.Remove((RobotDeCombate)rob);
                }
                else
                {
                    are.robotsSirvientes.Remove((RobotSirviente)rob);
                }
            }
            return are;
        }
        //********************************************************************************
        public static string operator -(Estacionamiento est, Vehiculo vehi)
        {
            string retorno = "El vehiculo no es parte del Estacionamiento";
            if (!(vehi is null))
            {
                if (est == vehi)
                {
                    retorno = vehi.ImprimirTiket();
                    est.vehiculos.Remove(vehi);
                }
            }
            return retorno;
        }
        //**********************************************************************************
        public static string operator -(Maquina ma, Periferico peri)
        {
            string retorno = "No se puede desconectar el dispositivo";

            for (int i = 0; i < ma.perifericos.Count; i++)
            {
                if (peri == ma.perifericos[i])
                {
                    // ma.perifericos.Remove(ma.perifericos[i]);
                    ma.perifericos.RemoveAt(i);
                    retorno = "Dispositivo Desconectado";


                    break;
                }
            }

            return retorno;

        }
        //**********************************************************************************
        #endregion

        #region ToString
        /// <summary>
        /// Muestra todos los elementos 
        /// </summary>
        /// <returns></returns> un string con todos los datos
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"{this.nombre}\n");
            sb.AppendLine("Lista de robots de Combate\n*****************\n");
            foreach (RobotDeCombate item in this.robotsDeCombate)
            {
                sb.AppendLine($"{item.ServirHumanidad()}");
            }
            sb.AppendLine("Lista de robots de Servicio\n*****************\n");
            foreach (RobotSirviente item in this.robotsSirvientes)
            {
                sb.AppendLine($"{item.ServirHumanidad()}");
            }

            return sb.ToString();
        }

        public static implicit operator string(Arena arena)
        {
            return arena.ToString();
        }
        //***********************************************************************************
        public virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Nombre: {this.Nombre}");
            sb.AppendLine($"Apellido: {this.Apellido}");
            sb.AppendLine($"Dni: {this.Dni}");
            sb.AppendLine($"Edad: {this.Edad}");
            return sb.ToString();
        }

        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"{base.Mostrar()}Altura:{this.Altura}\nPeso:{this.Peso}\nPosicion{this.Posicion} ");
            return sb.ToString();

        }
        #endregion

        #region Explicit 
        public static explicit operator string(Equipo equi)
        {
            StringBuilder sb = new StringBuilder();

            if (equi.directorTecnico != null)
            {
                sb.AppendLine($"Nombre:{equi.Nombre}\nDT\n{equi.directorTecnico.Mostrar()}\n");
            }
            else
            {
                sb.AppendLine($"Nombre:{equi.Nombre}\nSin DT Asignado\n");
            }
            sb.AppendLine("Jugadores\n");
            foreach (Jugador item in equi.jugadores)
            {
                sb.AppendLine($"{item.Mostrar()}");
            }

            return sb.ToString();
        }
        //****************************************************************************************
        public static explicit operator string(Estacionamiento est)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Nombre:{est.nombre}\nCapacidad:{est.espacioDisponible}");
            if (est.vehiculos.Count > 0)
            {
                sb.AppendLine("Lista de Vehiculos\n===================");
                foreach (Vehiculo item in est.vehiculos)
                {
                    sb.AppendLine(item.ConsultarDatos());
                }
            }
            else
            {
                sb.AppendLine("El Estacionamiento se encuentra vacio");
            }

            return sb.ToString();
        }
        //*****************************************************************************************
        public static explicit operator string(Periferico peri)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"Marca:{peri.marca}\nModelo: {peri.modelo}\nConector:{peri.conector}\n");

            return sb.ToString();
        }

        #endregion

        #region Metodos interesantes
        public bool ValidarEstadoFisico()
        {
            float imc;
            bool retorno = false;

            imc = this.Peso / (float)(Math.Pow(this.altura, 2));
            if (imc > 18.4 && imc < 25.1)
            {
                retorno = true;
            }
            return retorno;
        }

        #endregion

        #region Form
        /*  form1
          Form2 form2 = new Form2();
        if (form2.ShowDialog() == DialogResult.OK)
        {
          listaPersonas.Add(form2.persona);
        }

      form2
      persona = new Personas(txtName.Text, txtSurname.Text, Convert.ToInt32(txtDni.Text), Convert.ToDouble(txtTarjeta.Text));

        this.DialogResult = DialogResult.OK;*/

        MessageBox.Show(" Carlitos Agrego Sal");
    #endregion

        #region Archivos

        #region Binario

        #region serializacion
		    Dato p = new Dato();
        p.Nombre = "Mi Nombre";
            p.Edad = 25; //Objeto a serializar.
            FileStream fs;        //Objeto que escribirá en binario.
        BinaryFormatter ser;  //Objeto que serializará.

        fs = new FileStream("archivo.dat", FileMode.Create);
        //Se indica ubicación del archivo binario y el modo.
        ser = new BinaryFormatter();
        //Se crea el objeto serializador.
        ser.Serialize(fs, p);
            //Serializa el objeto p en el archivo contenido en fs.
            fs.Close();
            //Se cierra el objeto fs.
	#endregion

            
       #region Desearilizacion
		     Dato aux = new Dato();   //Objeto que alojará los datos


        //contenidos en el archivo binario.
        FileStream fs;                  //Objeto que leerá en binario.
        BinaryFormatter ser;      //Objeto que Deserializará.

        fs = new FileStream("Archivo.dat", FileMode.Open);
        //Se indica ubicación del archivo binario y el modo.
        ser = new BinaryFormatter();
        //Se crea el objeto deserializador.
        aux = (Dato) ser.Deserialize(fs);
        //Deserializa el archivo contenido en fs, lo guarda 
        //en aux.
        fs.Close();
            //Se cierra el objeto fs. 
	#endregion


        #endregion

        #region Xml

        #region XmlSimple
		    public class Xml<T> : IArchivo<T>
        {
            public void Guardar(string archivo, T datos)
            {
                try
                {
                    using (StreamWriter sw = new StreamWriter(archivo))
                    {
                        XmlSerializer serializar = new XmlSerializer(typeof(T));
                        serializar.Serialize(sw, datos);
                    }

                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            public void Leer(string archivo, out T datos)
            {
                try
                {
                    using (StreamReader sr = new StreamReader(archivo))
                    {
                        XmlSerializer serializar = new XmlSerializer(typeof(T));
                        datos = (T)serializar.Deserialize(sr);
                    }

                }
                catch (Exception e)
                {
                    throw e;
                }
            }

        }

        #endregion

        #endregion

        #region Texto

        #region TextoSimple


        public class Texto : IArchivo<String>
        {
            public bool guardar(string archivo, string datos)
            {
                try
                {
                    using (StreamWriter file = new StreamWriter(archivo))
                    {

                        string[] partes = datos.Split('\n');
                        foreach (string texto in partes)
                        {
                            file.WriteLine(texto);
                        }
                        return true;
                    }
                }
                catch (Exception e)
                {
                    throw new ArchivosException(e);
                }
            }

            public bool leer(string archivo, out string datos)
            {
                try
                {
                    using (StreamReader file = new StreamReader(archivo))
                    {
                        datos = file.ReadToEnd().ToString();
                        return true;
                    }
                }
                catch (Exception e)
                {
                    throw new ArchivosException(e);
                }
            }
        }

        #endregion

        #region Texto con Queue
        public class Texto : IArchivo<Queue<Patente>>
        {
            public void Guardar(string archivo, Queue<Patente> datos)
            {
                try
                {

                    using (StreamWriter file = new StreamWriter(archivo, File.Exists(archivo)))
                    {

                        // string[] partes = datos.Split('\n');
                        foreach (Patente texto in datos)
                        {
                            file.WriteLine(texto.ToString());
                        }
                        //  return true;
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }

            public void Leer(string archivo, out Queue<Patente> datos)
            {
                Queue<Patente> aux = new Queue<Patente>();
                try
                {
                    using (StreamReader file = new StreamReader(archivo))
                    {
                        while (!file.EndOfStream)
                        {
                            Patente pat = new Patente();

                            pat = PatenteStringExtension.ValidarPatente(file.ReadLine());
                            // pat=pat.ToString().ValidarPatente();
                            pat.CodigoPatente = file.ReadLine();

                            aux.Enqueue(pat);
                        }

                        datos = aux;

                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
        #endregion

        #region Texto ValiCuil
        public List<Persona> LeerNombres()
        {
            using (var reader = new StreamReader(@"C:\Users\Joaquin\Desktop\ValidacionCuil\nombres.csv"))
            {
                while (!reader.EndOfStream)
                {
                    Persona per = new Persona();
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    per.nom = values[0].ToString();
                    per.sex = values[1].ToString();

                    listNombres.Add(per);
                }
            }
            return listNombres;
        }


        public void EscribirArchivo(List<Persona> lista)
        {
            StreamWriter sw = new StreamWriter(@"C:\Users\Joaquin\Desktop\ValidacionCuil\Validos.txt");
            sw.WriteLine("NIP; CUIL; TIPO DE DOC; NRO DOCUMENTO; SEXO; NOMBRE; SEXO VALIDADO");
            foreach (Persona per in lista)
            {
                string perstring = per.nip + ";" + per.cuil + ";" + per.tipodoc + ";" + per.doc + ";" + per.sex + ";" + per.nom + ";" + per.sexVal;
                sw.WriteLine(perstring);

            }
            sw.Close();

        }
        #endregion

        #endregion

        #region Sql

        #region Sql Tp4

        #region Atributos
        private static SqlConnection cn;
        private static SqlCommand command;

        #endregion

        #region Metodos
        /// <summary>
        /// Creo un objeto sqlConecction
        /// Creo un objeto SqlComand
        /// Inicio la conecxion
        /// </summary>
        static PaqueteDAO()
        {
            PaqueteDAO.cn = new SqlConnection(Properties.Settings.Default.MiBase);
            PaqueteDAO.command = new SqlCommand();
            PaqueteDAO.command.CommandType = System.Data.CommandType.Text;
            PaqueteDAO.command.Connection = PaqueteDAO.cn;
        }
        /// <summary>
        /// Inserta un Paquete a la base de datos
        /// </summary>
        /// <param name="pac"></param>
        /// <returns> true si se pudo caso contrario false y se lanza el evento</returns>
        public static bool Insertar(Paquete pac)
        {
            bool retorno = false;

            try
            {
                PaqueteDAO.command.CommandText = $"insert into Paquetes (direccionEntrega,trackingID,alumno) values ('{pac.DireccionEntrega}','{pac.TrackingID}','Joaquin Esposito')";
                PaqueteDAO.cn.Open();
                PaqueteDAO.command.ExecuteNonQuery();
                PaqueteDAO.cn.Close();
                retorno = true;

            }
            catch (SqlException)
            {

                PaqueteDAO.EventoSql();

            }
            catch (Exception)
            {
                PaqueteDAO.EventoSql();
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    PaqueteDAO.cn.Close();
                }
            }

            return retorno;
        }
        #endregion

        #endregion

        #region SqlPatentes
        public class Sql : IArchivo<Queue<Patente>>
        {
            private static SqlCommand command;
            private static SqlConnection cn;
            private static SqlDataReader Ord;


            public Sql()
            {
                cn = new SqlConnection(Properties.Settings.Default.miBase);
                command = new SqlCommand();
                command.Connection = cn;

            }
            public void Guardar(string tabla, Queue<Patente> dato)
            {


                SqlDataAdapter Dao = new SqlDataAdapter();

                foreach (Patente item in dato)
                {
                    command.CommandText = $"insert into {tabla} (tipo,patente) values ('{item.TipoCodigo}','{item.CodigoPatente}')";

                }

                try
                {
                    cn.Open();
                    command.ExecuteNonQuery();
                    cn.Close();

                }
                catch (SqlException)
                {
                    throw new Exception("ERROR DE SQL");
                }
                catch (Exception)
                {

                    throw new Exception("ERROR DE SQL");
                }
                finally
                {
                    if (cn.State == System.Data.ConnectionState.Open)
                    {
                        cn.Close();
                    }
                }


            }

            public void Leer(string tabla, out Queue<Patente> dato)
            {

                Queue<Patente> aux = new Queue<Patente>();
                List<Patente> list = new List<Patente>();

                command.CommandType = System.Data.CommandType.Text;

                command.CommandText = $"SELECT patente,tipo FROM {tabla}";

                try
                {
                    cn.Open();

                    Ord = command.ExecuteReader();

                    while (Ord.Read())
                    {

                        Patente pat = new Patente();

                        pat.CodigoPatente = (string)Ord["patente"];


                        if ((string)Ord["tipo"] == "Mercosur")
                        {
                            pat.TipoCodigo = Patente.Tipo.Mercosur;
                        }
                        else
                        {
                            pat.TipoCodigo = Patente.Tipo.Vieja;
                        }

                        aux.Enqueue(pat);


                    }

                    dato = aux;
                    cn.Close();
                }
                catch (SqlException)
                {
                    throw new Exception("Fallo en conexion de base de datos");
                }
                catch (Exception)
                {
                    throw new Exception("Comuniquese con el administrador del servidor");
                }
                finally
                {
                    cn.Close();
                }

            }

        }
        #endregion

        #region SqlIng_Egreso_modificacion
        public class PersonaDAO
        {
            List<Persona> listaPersonas = new List<Persona>();
            public string Guardar(Persona per)
            {
                string message = string.Empty;
                SqlConnection cn = new SqlConnection(Properties.Settings.Default.BaseSQL);
                SqlCommand command = new SqlCommand();
                SqlDataAdapter Dao = new SqlDataAdapter();

                command.CommandText = $"insert into Persona (Nombre,Apellido) values ('{per.Nombre}','{per.Apellido}')";

                try
                {
                    cn.Open();
                    command.ExecuteNonQuery();
                    cn.Close();
                    message = "Persona guardada esitosamente.";
                }
                catch (SqlException ex)
                {
                    message = $"ERROR DE SQL {ex.Message}";
                }
                catch (Exception ex)
                {
                    message = $"ERROR: {ex.Message}";
                }
                finally
                {
                    if (cn.State == System.Data.ConnectionState.Open)
                    {
                        cn.Close();
                    }
                }

                return message;
            }

            public List<Persona> Leer()
            {
                SqlConnection cn = new SqlConnection(Properties.Settings.Default.BaseSQL);
                SqlCommand command = new SqlCommand();
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = "SELECT id,Nombre,Apellido FROM Persona";

                try
                {
                    cn.Open();

                    SqlDataReader Ord = command.ExecuteReader();

                    while (Ord.Read())
                    {
                        Persona per = new Persona((string)Ord["nombre"], (string)Ord["Apellido"], (int)(decimal)Ord["id"]);
                        this.listaPersonas.Add(per);
                    }
                    cn.Close();
                }
                catch (SqlException)
                {
                    throw new Exception("Fallo en conexion de base de datos");
                }
                catch (Exception)
                {
                    throw new Exception("Comuniquese con el administrador del servidor");
                }
                finally
                {
                    cn.Close();
                }
                return this.listaPersonas;
            }

            public Persona LeerPorId(int id)
            {
                Persona per;
                SqlConnection cn = new SqlConnection(Properties.Settings.Default.BaseSQL);
                SqlCommand command = new SqlCommand();

                command.Connection = cn;
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = $"Select id={id} from Persona";

                try
                {
                    cn.Open();
                    SqlDataReader Ord = command.ExecuteReader();

                    per = new Persona((string)Ord["nombre"], (string)Ord["Apellido"], (int)(decimal)Ord["id"]);
                    cn.Close();
                }
                catch (SqlException)
                {

                    throw new Exception("Erro de base de datos");
                }
                catch (Exception)
                {
                    throw new Exception("No se encontro el id especificado");
                }
                finally
                {
                    if (cn.State == System.Data.ConnectionState.Open)
                    {
                        cn.Close();
                    }

                }
                return per;
            }

            public string ModificarID(Persona per)
            {
                string retorno;
                Persona per2;
                SqlConnection cn = new SqlConnection(Properties.Settings.Default.BaseSQL);
                SqlCommand command = new SqlCommand();

                command.Connection = cn;
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = $" update Persona set Nombre ={per.Nombre},set Apellido={per.Apellido} where id={per.Id}";
                try
                {
                    cn.Open();
                    SqlDataReader Ord = command.ExecuteReader();
                    cn.Close();
                }
                catch (SqlException e)
                {

                    retorno = $"Error de SQL {e.Message}";
                }
                catch (Exception ex)
                {
                    retorno = $"ERROR: {ex.Message}";
                }
                finally
                {
                    if (cn.State == System.Data.ConnectionState.Open)
                    {
                        cn.Close();
                    }

                }

                return retorno;
            }
            #endregion

            #endregion
            #endregion

            #region Interfases

            public interface IArchivo<T>
            {
                void Guardar(string archivo, T datos);

                void Leer(string archivo, out T datos);
            }

            public interface IMostrar<T>
            {
                #region Metodos

                string MostarDatos(IMostrar<T> elementos);
                #endregion
            }

            #endregion

            #region Delegado y eventos
            #region Ejemplo TP4
            /// <summary>
            /// Delegado de Informar Estado
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            public delegate void DelegadoEstado(object sender, EventArgs e);

            /// <summary>
            /// Evento a ejecutar para informar los estados en ese momento de los paquetes
            /// </summary>
            public event DelegadoEstado InformaEstado;
            /// <summary>
            /// Lanzamiento de evento
            /// </summary>
            public void MockCicloDeVida()
            {
                do
                {
                    Thread.Sleep(4000);
                    if (this.Estado == EEstado.Ingresado)
                    {
                        this.Estado = EEstado.EnViaje;
                    }
                    else
                    {
                        if (this.Estado == EEstado.EnViaje)
                        {
                            this.Estado = EEstado.Entregado;
                        }

                    }

                    InformaEstado(this, new EventArgs());

                } while (this.Estado != EEstado.Entregado);

                PaqueteDAO.Insertar(this);

            }
            /// <summary>
            /// Agrega un elemento al objeto correo y lo agrega e la base de datos en caso de ser posible
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void btnAgregar_Click(object sender, EventArgs e)
            {

                if (mtxtTrackingID.Text.Length != 12)
                {
                    MessageBox.Show("Datos incompletos en TrackingID!");
                }
                else if (txtDireccion.Text == "")
                {

                    MessageBox.Show("Por favor Ingrese una direccion!");
                }
                else
                {
                    Paquete PaqNuev = new Paquete(txtDireccion.Text, mtxtTrackingID.Text);

                    PaqNuev.InformaEstado += paq_InformaEstado;
                    try
                    {
                        correo += PaqNuev;
                        PaqueteDAO.EventoSql += PaqueteDAO_EventoSql;
                        this.ActualizarEstado();
                    }
                    catch (TrackingIdRepetidoExeption id)
                    {
                        MessageBox.Show(id.Message);
                    }
                    catch (SqlException exS)
                    {
                        MessageBox.Show(exS.Message);

                    }
                    catch (Exception exep)
                    {
                        MessageBox.Show(exep.Message);
                    }

                }

            }
            /// <summary>
            /// Manejador del evento que informa el estado del paquete en ese momento
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void paq_InformaEstado(object sender, EventArgs e)
            {
                if (InvokeRequired)
                {
                    Paquete.DelegadoEstado d = new Paquete.DelegadoEstado(paq_InformaEstado);
                    this.Invoke(d, new object[] { sender, e });

                }
                else
                {
                    this.ActualizarEstado();
                }
            }
            #endregion

            #region EjemploCompleto
            public delegate void MostrarPatente(object patente);
            public delegate void FinExposicionPatente(VistaPatente vp);
            public event FinExposicionPatente finExposicion;

            /// <summary>
            /// lanzamiento del evento
            /// </summary>
            /// <param name="patente"></param>
            public void MostrarPatente(object patente)
            {
                if (lblPatenteNro.InvokeRequired)
                {
                    try
                    {
                        Random r = new Random();

                        // Llamar al hilo principal

                        MostrarPatente d = new MostrarPatente(MostrarPatente);
                        this.Invoke(d, new object[] { patente });
                        // ALUMNO
                        Thread.Sleep(r.Next(2000, 5000));
                        this.finExposicion(this);
                        // Agregar evento de que finalizó la exposición de la patente
                        // ALUMNO
                    }
                    catch (Exception) { }
                }
                else
                {
                    picPatente.Image = fondosPatente.Images[(int)((Patente)patente).TipoCodigo];
                    lblPatenteNro.Text = patente.ToString();
                }
            }
            /// <summary>
            /// implementacion
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void FrmPpal_Load(object sender, EventArgs e)
            {
                vistaPatente1.finExposicion += ProximaPatente;
                vistaPatente2.finExposicion += ProximaPatente;


            }
            /// <summary>
            /// Manejador del evento
            /// </summary>
            /// <param name="vp"></param>
            private void ProximaPatente(Patentes.VistaPatente vp)
            {
                if (cola.Count != 0)
                {

                    Thread hilo = new Thread(vp.MostrarPatente);
                    hilo.Start(cola.Dequeue());
                    lista.Add(hilo);
                }
                else
                {
                    MessageBox.Show("No Hay mas Patentes cargadas");
                }

            }
            #endregion

            #endregion

            #region Test Unitarios
            [TestClass]
            public class UnitTest1
            {

                #region Test Lista instanciada
                /// <summary>
                /// verifica que la lista de Paquetes del correo este instanciada
                /// </summary>
                [TestMethod]
                public void listaInstanciada()
                {
                    //Arrange 
                    Correo correo = new Correo();
                    List<Paquete> lista = null;
                    //Act
                    lista = correo.Paquetes;
                    //Assert
                    Assert.IsNotNull(lista);

                }

                #endregion

                #region Test Paquete Repetido
                /// <summary>
                /// Verifica que se lance la exepcion cuando se intenta agreagar un paquete que ya se encuentra dentro de la lista
                /// </summary>
                [TestMethod]
                public void PaquetesID()
                {

                    //Arrange 
                    Correo correo = new Correo();
                    Paquete p1 = new Paquete("Padre Javier 588", "445-612-4562");
                    Paquete p2 = new Paquete("Padre Javier 588", "445-612-4562");
                    //Act
                    try
                    {
                        correo += p1;
                        correo += p2;
                    }
                    catch (Exception e)
                    {
                        //Assert
                        Assert.IsInstanceOfType(e, typeof(TrackingIdRepetidoExeption));
                    }

                }
                #endregion

                #region Test Tp3
                /// <summary>
                /// Verifica si se ingresa un alumno repetido a la universidad.
                /// </summary>
                [TestMethod]
                public void checkAlumnoRepetido()
                {
                    try
                    {
                        Universidad g1 = new Universidad();
                        Alumno a1 = new Alumno(1, "Juan", "Lopez", "12234456",
                        EntidadesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Programacion, Alumno.EEstadoCuenta.Becado);

                        Alumno a2 = new Alumno(2, "Juana", "Martinez", "12234458",
                       EntidadesAbstractas.Persona.ENacionalidad.Extranjero, Universidad.EClases.Laboratorio, Alumno.EEstadoCuenta.Deudor);
                        g1 += a1;
                        g1 += a2;
                    }
                    catch (Exception e)
                    {
                        Assert.IsInstanceOfType(e, typeof(AlumnoRepetidoException));
                    }
                }
                /// <summary>
                /// Verifica que la longitud del DNI con respecto a la nacionalidad sea válido.
                /// </summary>
                [TestMethod]
                public void checkLongitudDni()
                {
                    try
                    {
                        Alumno a2 = new Alumno(2, "Carlos", "Gonzales", "899999999", EntidadesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio, Alumno.EEstadoCuenta.AlDia);
                    }
                    catch (Exception e)
                    {
                        Assert.IsInstanceOfType(e, typeof(NacionalidadInvalidaException));
                    }
                }
                /// <summary>
                /// Verifica que el DNI ingresado sea válido.
                /// </summary>
                [TestMethod]
                public void checkNumeroDniIvalidoArg()
                {
                    try
                    {
                        Alumno a2 = new Alumno(6, "Juan", "Perez", "1223asd4656", EntidadesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio, Alumno.EEstadoCuenta.Deudor);
                    }
                    catch (Exception e)
                    {
                        Assert.IsInstanceOfType(e, typeof(DniIvalidoException));
                    }
                }
                /// <summary>
                /// Verifica que el DNI ingresado con respecto a la nacionalidad sea válido
                /// </summary>
                [TestMethod]
                public void checkNumeroDniIvalidoExt()
                {
                    try
                    {
                        Alumno a2 = new Alumno(7, "Joaquin", "Suarez", "911224", EntidadesAbstractas.Persona.ENacionalidad.Extranjero, Universidad.EClases.Laboratorio, Alumno.EEstadoCuenta.AlDia);
                    }
                    catch (NacionalidadInvalidaException e)
                    {
                        Assert.IsInstanceOfType(e, typeof(NacionalidadInvalidaException));
                    }
                }
                /// <summary>
                /// Verifica que el valor ingresado es incorrecto
                /// </summary>
                [TestMethod]
                public void checkNombreApellido()
                {
                    string valorErroneo = " ";
                    Alumno a2 = new Alumno(8, "Rodrigo", "Sm4ith", "22236456", EntidadesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Legislacion,
                   Alumno.EEstadoCuenta.AlDia);
                    Assert.AreEqual(valorErroneo, a2.Apellido);

                }
                /// <summary>
                /// Verifica que no haya valores nulos
                /// </summary>
                [TestMethod]
                public void checkValoresNulos()
                {
                    Profesor i1 = new Profesor(2, "Roberto", "Juarez", "32234456", EntidadesAbstractas.Persona.ENacionalidad.Argentino);
                    Jornada j1 = new Jornada(Universidad.EClases.Legislacion, i1);
                    Assert.IsNotNull(j1.Alumnos);
                }
                /// <summary>
                /// Verifica si hay valores nulos en la instancia dada.
                /// </summary>
                [TestMethod]
                public void checkValoresNulos2()
                {
                    Profesor i1 = new Profesor(1, "Juan", "Lopez", "12234456", EntidadesAbstractas.Persona.ENacionalidad.Argentino);
                    Jornada j1 = new Jornada(Universidad.EClases.Legislacion, i1);
                    j1.Alumnos = null;
                    Assert.IsNull(j1.Alumnos);
                }
                #endregion

            }
            #endregion

            #region Metodos de Extension

            public static class PatenteStringExtension
            {
                #region Metodo de extension
                public const string patente_vieja = "^[A-Z]{3}[0-9]{3}$";
                public const string patente_mercosur = "^[A-Z]{2}[0-9]{3}[A-Z]{2}$";

                public static Patente ValidarPatente(this string str)
                {
                    Patente aux = new Patente();
                    Regex r1V = new Regex(PatenteStringExtension.patente_vieja);
                    Regex r2N = new Regex(PatenteStringExtension.patente_mercosur);

                    if (r1V.IsMatch(str))
                    {
                        aux.TipoCodigo = Patente.Tipo.Vieja;
                    }
                    else if (r2N.IsMatch(str))
                    {
                        aux.TipoCodigo = Patente.Tipo.Mercosur;
                    }
                    else
                    {
                        string s = string.Format("{0} no cumple el formato.", str);
                        throw new PatenteInvalidaException(s);
                    }

                    return aux;

                }
                #endregion

            }
            /// <summary>
            /// Manda un archivo de texto al escritorio
            /// </summary>
            public static class GuardarString
            {
                #region Metodo

                /// <summary>
                /// Extension de metodo.
                /// Guarda archivo de texto en el escritorio.
                /// </summary>
                /// <param name="texto"></param>
                /// <param name="archivo">Nombre del archivo.</param>
                /// <returns></returns> true si se pudo guardar caso contrario false

                public static bool Guardar(this string texto, string archivo)
                {
                    bool retorno = false;
                    string[] aux;
                    try
                    {
                        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                        path += @"\" + archivo;

                        using (StreamWriter file = new StreamWriter(path, File.Exists(path)))
                        {
                            aux = texto.Split('\n');
                            foreach (string item in aux)
                            {
                                file.WriteLine(item);
                            }

                            retorno = true;
                        }
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }

                    return retorno;
                }
                #endregion
            }

            #endregion









        }
    }
