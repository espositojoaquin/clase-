﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            //Excepción de fecha de nacimiento
            //Guardar y leer un XML
            //Guardar y leer un Binario
        }
    }
}
