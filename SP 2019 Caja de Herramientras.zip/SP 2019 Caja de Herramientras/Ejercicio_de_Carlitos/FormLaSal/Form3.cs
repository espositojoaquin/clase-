﻿using EntidadesLaSal;
using System;
using System.Windows.Forms;

namespace FormLaSal
{
    public partial class Form3 : Form
    {
        public Persona persona;

        public Form3()
        {
            InitializeComponent();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            persona = new Persona(Convert.ToInt32(txtDni.Text));
            this.DialogResult = DialogResult.Yes;
        }
    }
}
