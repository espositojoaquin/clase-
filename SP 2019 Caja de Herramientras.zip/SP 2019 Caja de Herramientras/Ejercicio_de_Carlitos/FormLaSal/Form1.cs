﻿using EntidadesLaSal;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;



namespace FormLaSal
{
    public partial class Form1 : Form
    {
        public List<Persona> personas;

        public Form1()
        {
            personas = new List<Persona>();
            personas = DeserializarBinario();
            //personas = Deserializar();
            //this.IsMdiContainer = true;
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            if(form2.ShowDialog()== DialogResult.OK)
            {
                personas.Add(form2.persona);
            }

        }

        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();

            foreach (Persona item in personas)
            {
                sb.AppendFormat(item.ToString());
            }

            rtbListaPersonas.Text = sb.ToString();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            //form3.MdiParent = this;

            if (form3.ShowDialog() == DialogResult.Yes)
            {
                for (int i = 0; i < personas.Count; i++)
                {
                    if(form3.persona.Dni==personas[i].Dni)
                    {
                        personas.Remove(personas[i]);
                    }
                }
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            XmlTextWriter writer;
            XmlSerializer ser;

            writer = new XmlTextWriter(@"D:\VisualStudio\Ejercicio_de_Carlitos\ListaCarlitos.Xml", Encoding.ASCII);
            ser = new XmlSerializer(typeof(List<Persona>));

            ser.Serialize(writer, personas);

            writer.Close();
            
            FileStream fs;        
            BinaryFormatter serBin; 

            
            fs = new FileStream(@"D:\VisualStudio\Ejercicio_de_Carlitos\ListaCarlitosBinario.Dat", FileMode.Create);
            serBin = new BinaryFormatter();

            serBin.Serialize(fs, personas);

            fs.Close();

        }

        public List<Persona> Deserializar()
        {
            List<Persona> aux = new List<Persona>();
            XmlTextReader reader;
            XmlSerializer ser;
            
            reader = new XmlTextReader(@"D:\VisualStudio\Ejercicio_de_Carlitos\ListaCarlitos.Xml");
            ser = new XmlSerializer(typeof(List<Persona>));

            aux = (List<Persona>)ser.Deserialize(reader);
            reader.Close();

            return aux;
        }

        public List<Persona> DeserializarBinario()
        {
            List<Persona> aux = new List<Persona>();
            FileStream fs;      
            BinaryFormatter ser;   
            
            fs = new FileStream(@"D:\VisualStudio\Ejercicio_de_Carlitos\ListaCarlitosBinario.Dat", FileMode.Open);
            ser = new BinaryFormatter();

            aux = (List<Persona>)ser.Deserialize(fs);

            fs.Close();

            return aux;
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
