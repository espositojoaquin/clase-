﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesLaSal
{
    [Serializable]
    public class Persona
    {
        #region Atributos
        protected string nombre;
        protected string apellido;
        protected int dni;
        private double tarjeta;
        #endregion

        #region Constructores
        public Persona()
        {


        }

        public Persona(int dni):this()
        {
            this.dni = dni;
        }
        public Persona(string apellido, string nombre,int dni,double tarjeta) : this(dni)
        {
            this.apellido = apellido;
            this.nombre = nombre;
            this.tarjeta = tarjeta;
        }
        #endregion

        #region Propiedades
        public string Nombre
        {
            get { return this.nombre; }
            set { this.nombre = value; }
        }
        public string Apellido
        {
            get { return this.apellido; }
            set { this.apellido = value; }
        }
        public int Dni
        {
            get { return this.dni; }
            set { this.dni = value; }
        }
        /*public double Tarjeta
        {
            get { return this.tarjeta; }
            set { this.tarjeta = value; }
        }*/
        #endregion

        #region Operadores
        public static bool operator ==(Persona p1, Persona p2)
        {
            bool retorno = false;

            if (!(p1 is null) && !(p2 is null))
            {
                if (p1.Dni == p2.Dni)
                {
                    retorno = true;
                }
            }

            return retorno;
        }
        public static bool operator !=(Persona p1, Persona p2)
        {
            return !(p1 == p2);
        }
        #endregion

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat($"Apellido: {this.Apellido} Nombre: {this.Nombre} DNI: {this.Dni} Tarjeta Nº: {this.tarjeta}\n");
            
            return sb.ToString();
        }

        public void SetTarjeta(double tarjeta)
        {
            this.tarjeta = tarjeta;
        }
    }
}
