﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Entidades
{
    public static class GuardarString
    {
        #region Metodo

        /// <summary>
        /// Extension de metodo.
        /// Guarda archivo de texto en el escritorio.
        /// </summary>
        /// <param name="texto"></param>
        /// <param name="archivo">Nombre del archivo.</param>
        /// <returns></returns> true si se pudo guardar caso contrario false

        public static bool Guardar(this string texto, string archivo)
        {
            bool retorno = false;
            string[] aux;
            try
            {
                string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                path += @"\" + archivo;

                using (StreamWriter file = new StreamWriter(path, File.Exists(path)))
                {
                    aux = texto.Split('\n');
                    foreach (string item in aux)
                    {
                        file.WriteLine(item);
                    }

                    retorno = true;
                }
            }
            catch (Exception e)
            {
                throw e;
            }

            return retorno;
        }
    #endregion
    } 
}
