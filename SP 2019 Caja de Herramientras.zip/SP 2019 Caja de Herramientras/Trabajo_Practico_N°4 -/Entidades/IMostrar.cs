﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public interface IMostrar<T>
    {
        #region Metodos

        string MostarDatos(IMostrar<T> elementos); 
        #endregion
    }
}
