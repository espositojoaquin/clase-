﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class TrackingIdRepetidoExeption:Exception
    {
        public TrackingIdRepetidoExeption(string mensaje):base(mensaje)
        {

        }
        public TrackingIdRepetidoExeption(string mensaje,Exception inner):base(mensaje,inner)
        {

        }
    }
}
