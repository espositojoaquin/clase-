﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using System.Data.SqlClient;

namespace MainCorreo
{
    public partial class Form1 : Form
    {
       
        public Correo correo;
       

        /// <summary>
        /// Contructor que inicializa los componentes y el objet Correo
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            correo = new Correo();
        }

        /// <summary>
        /// Limpia y Actualiza los estados en las listTex
        /// </summary>
        public void ActualizarEstado()
        {
            this.lstEstadoIngresado.Items.Clear();
            this.lstEstadoEnViaje.Items.Clear();
            this.lstEstadoEntregado.Items.Clear();
            foreach (Paquete item in correo.Paquetes)
            {
                switch (item.Estado)
                {
                    case Paquete.EEstado.Ingresado:
                        this.lstEstadoIngresado.Items.Add(item);
                        break;
                    case Paquete.EEstado.EnViaje:
                        this.lstEstadoEnViaje.Items.Add(item);
                        break;
                    case Paquete.EEstado.Entregado:
                        this.lstEstadoEntregado.Items.Add(item);
                        break;
                }
            }

        }

        /// <summary>
        /// Agrega un elemento al objeto correo y lo agrega e la base de datos en caso de ser posible
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAgregar_Click(object sender, EventArgs e)
        {

            if (mtxtTrackingID.Text.Length != 12)
            {
                MessageBox.Show("Datos incompletos en TrackingID!");
            }
            else if (txtDireccion.Text == "")
            {

                MessageBox.Show("Por favor Ingrese una direccion!");
            }
            else
            {
                Paquete PaqNuev = new Paquete(txtDireccion.Text, mtxtTrackingID.Text);

                PaqNuev.InformaEstado += paq_InformaEstado;
                try
                {
                    correo += PaqNuev;
                    PaqueteDAO.EventoSql += PaqueteDAO_EventoSql;
                    this.ActualizarEstado();
                }
                catch (TrackingIdRepetidoExeption id)
                {
                    MessageBox.Show(id.Message);
                }
                catch (SqlException exS)
                {
                    MessageBox.Show(exS.Message);

                }
                catch (Exception exep)
                {
                    MessageBox.Show(exep.Message);
                }

            }

        }
        /// <summary>
        /// Manejador del evento que informa el estado del paquete en ese momento
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void paq_InformaEstado(object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                Paquete.DelegadoEstado d = new Paquete.DelegadoEstado(paq_InformaEstado);
                this.Invoke(d, new object[] { sender, e });

            }
            else
            {
                this.ActualizarEstado();
            }
        }
        /// <summary>
        /// Manejador del evento que indica que hubo un fallo al conectarse con la base de datos
        /// </summary>
        private void PaqueteDAO_EventoSql()
        {
            MessageBox.Show("Fallo en la conecxion con la base de datos");
        }

        /// <summary>
        /// Muestra la informacion de cualquier elemento que le llegue
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="elemento"></param>
        private void MostrarInformacion<T>(IMostrar<T> elemento)
        {
            if (!(Equals(elemento, null)))
            {
                try
                {
                    if (elemento is Correo)
                    {
                        this.rtbMostrar.Text = elemento.MostarDatos(elemento);
                    }
                    else if (elemento is Paquete)
                    {
                        rtbMostrar.Text = elemento.MostarDatos(elemento);
                    }

                    rtbMostrar.Text.Guardar("Salida.txt");
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }
            }
        }

        /// <summary>
        /// Al seleccionar un elemento de lstEstadoEntregado y al hacer click derecho despliega un menu mostrar el cual mostrara esa iformacion en el rtbText
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<Paquete>((IMostrar<Paquete>)lstEstadoEntregado.SelectedItem);
        }


        /// <summary>
        /// Mostrara todos lo elementos dentro de la lista de Paquetes del correo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMostrarTodos_Click_1(object sender, EventArgs e)
        {
            this.MostrarInformacion<List<Paquete>>((IMostrar<List<Paquete>>)correo);
        }
        /// <summary>
        /// Al cerrarse el formulario se preguntara si en verdad se quiere cerrar y de ser asi llama al metodo que mata los hilos que se encuentran activos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            DialogResult result = MessageBox.Show("¿Esta seguro de querer abandonar el Fomulario?", "Cerrar", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.Cancel)
            {
                e.Cancel = true;

            }
            else
            {
                this.correo.FinEntregas();
            }

        }
    }
}

