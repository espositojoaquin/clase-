﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using Archivos;
using System.Threading;
using VistaPatentes;



namespace _20181122_SP
{
    public partial class FrmPpal : Form
    {
        Queue<Patente> cola;
        List<Thread> lista;

        public FrmPpal()
        {
            InitializeComponent();

            this.cola = new Queue<Patente>();
            this.lista = new List<Thread>();
            

        }

        private void FrmPpal_Load(object sender, EventArgs e)
        {
            vistaPatente1.finExposicion += ProximaPatente;
            vistaPatente2.finExposicion += ProximaPatente;
            

        }

        private void ProximaPatente(Patentes.VistaPatente vp)
        {
            if(cola.Count!=0)
            {

                Thread hilo = new Thread(vp.MostrarPatente);
                hilo.Start(cola.Dequeue()); 
                lista.Add(hilo);
            }
            else
            {
                MessageBox.Show("No Hay mas Patentes cargadas");
            }
            
        }

        private void FrmPpal_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("¿Esta seguro de querer abandonar el Fomulario?", "Cerrar", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.Cancel)
            {
                e.Cancel = true;

            }
            else
            {
                this.FinalizarSimulacion();
            }

        }

        private void btnXml_Click(object sender, EventArgs e)
        {
          /*  Xml<Patente> xml = new Xml<Patente>();

            foreach (Patente item in this.cola)
            {
                
            }
            xml.Leer("patente",this.cola);*/




        }

        private void btnTxt_Click(object sender, EventArgs e)
        {
            try
            {
                Texto tex = new Texto();
                tex.Leer("patentes.txt", out this.cola);
                IniciarSimulacion();
            }
            catch (PatenteInvalidaException eIE)
            {
                MessageBox.Show(eIE.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSql_Click(object sender, EventArgs e)
        {
           
            try
            {
                Sql sql = new Sql();
                sql.Leer("Patentes", out this.cola);
                IniciarSimulacion();
               
            }
            catch (PatenteInvalidaException eIE)
            {

                MessageBox.Show(eIE.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FinalizarSimulacion()
        {

            foreach (Thread item in this.lista)
            {
                if (item.IsAlive)
                    item.Abort();
            }

        }
     
      /*  public void ProximaPat( Patentes.VistaPatente c1)
        {   
            if (cola.Count>0)
            { 
                Thread hilo = new Thread( c1.MostrarPatente);
                hilo.Start(cola.Dequeue());
                lista.Add(hilo); 
            }
        }*/
        public void IniciarSimulacion()
        {
           
            FinalizarSimulacion();
            ProximaPatente(this.vistaPatente1);
            ProximaPatente(this.vistaPatente2);

        }
        
    }
}
