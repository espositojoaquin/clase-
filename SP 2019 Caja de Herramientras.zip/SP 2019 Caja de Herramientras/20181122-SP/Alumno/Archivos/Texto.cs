using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
//using Excepciones;
using Entidades;

namespace Archivos
{
    public class Texto : IArchivo<Queue<Patente>>
    {
        public void Guardar(string archivo, Queue<Patente> datos)
        {
            try
            {

                using (StreamWriter file = new StreamWriter(archivo, File.Exists(archivo)))
                {

                    // string[] partes = datos.Split('\n');
                    foreach (Patente texto in datos)
                    { 
                        file.WriteLine(texto.ToString());
                    }
                    //  return true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void Leer(string archivo, out Queue<Patente> datos)
        {
            Queue<Patente> aux = new Queue<Patente>();
            try
            {
                using (StreamReader file = new StreamReader(archivo))
                {
                    while (!file.EndOfStream)
                    {
                        Patente pat = new Patente();

                        pat = PatenteStringExtension.ValidarPatente(file.ReadLine());
                       // pat=pat.ToString().ValidarPatente();
                        pat.CodigoPatente = file.ReadLine();

                        aux.Enqueue(pat);
                    }

                    datos = aux;
                  
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
