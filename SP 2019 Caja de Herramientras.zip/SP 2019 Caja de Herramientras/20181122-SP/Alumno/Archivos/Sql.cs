using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using Entidades;

namespace Archivos
{
    public class Sql : IArchivo<Queue<Patente>>
    {
        private static SqlCommand command;
        private static SqlConnection cn;
        private static SqlDataReader Ord;


        public Sql()
        {
            cn = new SqlConnection(Properties.Settings.Default.miBase);
            command = new SqlCommand();
            command.Connection = cn;

        }
        public void Guardar(string tabla, Queue<Patente> dato)
        {

           
            SqlDataAdapter Dao = new SqlDataAdapter();

            foreach (Patente item in dato)
            {
                command.CommandText = $"insert into {tabla} (tipo,patente) values ('{item.TipoCodigo}','{item.CodigoPatente}')";

            }

            try
            {
                cn.Open();
                command.ExecuteNonQuery();
                cn.Close();

            }
            catch (SqlException)
            {
                throw new Exception("ERROR DE SQL");
            }
            catch (Exception)
            {

                throw new Exception("ERROR DE SQL");
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }


        }

        public void Leer(string tabla, out Queue<Patente> dato)
        {
           
            Queue<Patente> aux = new Queue<Patente>();
            List<Patente> list = new List<Patente>();
          
            command.CommandType = System.Data.CommandType.Text;

            command.CommandText = $"SELECT patente,tipo FROM {tabla}";

            try
            {
                cn.Open();

                Ord = command.ExecuteReader();

                while (Ord.Read())
                {

                    Patente pat = new Patente();
                    
                    pat.CodigoPatente = (string)Ord["patente"];

                    
                    if ((string)Ord["tipo"] == "Mercosur")
                    {
                        pat.TipoCodigo = Patente.Tipo.Mercosur;
                    }
                    else
                    {
                        pat.TipoCodigo = Patente.Tipo.Vieja;
                    }
                   
                     aux.Enqueue(pat);
                   
                   
                }
               
                dato = aux;
                cn.Close();
            }
            catch (SqlException)
            {
                throw new Exception("Fallo en conexion de base de datos");
            }
            catch (Exception)
            {
                throw new Exception("Comuniquese con el administrador del servidor");
            }
            finally
            {
                cn.Close();
            }

        }

    }
}
