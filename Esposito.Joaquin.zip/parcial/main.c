#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "productos.h"
#include "provedores.h"
#include "input.h"
#define TAM 100
#define TAM2 1000



int main()
{
    int opcion,idUs;
    char respuesta='s';
    char auxOP[30];

    eProvedor provedor[TAM];
    eProducto producto[TAM2];
    inicializarEstado(producto,TAM2);
    inicializarEstadoP(provedor,TAM);
    ID1(provedor);
    IDproducto(producto,TAM2);
    Harcodeo(provedor);

    do
    {

        opcion=menu(auxOP);
        switch(opcion)
        {
        case 1: AltaProducto(producto,TAM2,provedor,TAM);

            system("pause");
            system("cls");
            break;
        case 2: modificarProducto(producto,provedor,TAM2,TAM);

             system("pause");
            system("cls");

            break;
        case 3: BajaProducto(provedor,producto,TAM,TAM2);

            system("pause");
            system("cls");
            break;
        case 4: importes(producto,TAM2);

            system("pause");
            system("cls");
            break;
        case 5: ListarProductos(producto,TAM2);
                productosMenor10(producto,TAM2);
                productosMayor10(producto,TAM2);


            productosMasImportes(producto,TAM2);
            productosMenosImportes(producto,TAM2);
            idUs=numIDProvedor(auxOP,provedor,TAM);

            publcacionesProvedor(provedor,producto,TAM,TAM2,idUs);
            system("pause");
            system("cls");
            break;
        case 6:  respuesta='n';
            system("pause");
            system("cls");
            break;

        default:
            printf("Ingrese una opcion entre 1-6\n");

            break;
        }


    }
    while(respuesta=='s');
    return 0;
}

