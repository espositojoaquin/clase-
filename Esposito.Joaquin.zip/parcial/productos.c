#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "provedores.h"
#include "productos.h"
#include "input.h"
#define TAM 100
#define TAM2 1000

void inicializarEstado(eProducto dato[],int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        dato[i].estado=0;


    }

}
//***********************************************************************
void IDproducto(eProducto dato[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {

        dato[i].idProducto=i+100;

    }
}
//************************************************************************
int EspacioLibre(eProducto dato[],int tam)
{
    int i;
    int retorno;
    for(i=0; i<tam; i++)
    {
        if(dato[i].estado==0)
        {
            retorno=i;
            break;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;
}
//*********************************************************

//************************************************************************
void AltaProducto(eProducto dato[],int tamPro,eProvedor estruct[],int tamU)
{
    int indice;
    int auxID;
    char aux[50];
    char auxStock[30];
    indice=EspacioLibre(dato,tamPro);
    if(indice==-1)
    {
        printf("NO HAY MAS ESPACIO DISPONIBLE\n");
    }
    else
    {
        printf("Por favor ingrese su Codigo de Usuario: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        isNumber(aux);
        auxID=atoi(aux);
        while(BuscarUSID(estruct,tamU,auxID)==-1)
        {
            printf("\nUsuario inexsitente\n");
            printf("\nPor favor reingresar Usuario: ");
            setbuf(stdin,NULL);
            scanf("%[^\n]",aux);
            isNumber(aux);
            auxID=atoi(aux);
            system("pause");
            system("cls");

        }

        dato[indice].idProvedor=auxID;

        printf("Igrese la descripcion del producto: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",dato[indice].Descripcion);
        isWord(dato[indice].Descripcion);
        printf("Ingrese el Stock disponible : ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxStock);
        isNumber(auxStock);
        dato[indice].stock=atoi(auxStock);
        setbuf(stdin,NULL);
        printf("Por favor ingrese el Importe: ");
        scanf("%[^\n]",aux);
        isFloat(aux);
        dato[indice].importe=atof(aux);

        dato[indice].estado=1;
        printf("Publicacion registrada exitosamente\n");
        printf(" Su numero de publicacion es: %.4d\n",dato[indice].idProducto);

    }

}
//**********************************************************
void mostrarP(eProducto dato)
{
    if(dato.estado==1)
    {
        printf("Descripcion:%s\n id provedor:%d \n id Producto:%d\n stock:%d\n Precio:%.2f\n \n\n ",dato.Descripcion,dato.idProvedor,dato.idProducto,dato.stock,dato.importe);
    }

}
//*******************************************************************************************************
void mostrarPS(eProducto dato[],int tam)
{
    int i,flag=0;
    for(i=0; i<tam; i++)
    {
        if(dato[i].estado==1)
        {
            flag=1;

            mostrarP(dato[i]);
        }

    }
    if(flag==0)
    {
        printf("No hay Productos ingresados\n");
    }
}
//*****************************************************************
int numIDProvedor(char cad[],eProvedor dato[],int tamU)
{
    int aux,indice;
    printf("Ingrese su numero de Usuario: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",cad);
    isNumber(cad);
    aux=atoi(cad);
    indice=BuscarUSID(dato,tamU,aux);
    while(indice==-1)
    {
        printf("Numero de Usuario inexistente\n");
        printf("Reingrese su numero de Usuario: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",cad);
        isNumber(cad);
        aux=atoi(cad);
        indice=BuscarUSID(dato,tamU,aux);
        system("pause");
        system("cls");
    }
    return aux;
}
//*****************************************************************
void publcacionesProvedor(eProvedor dato[],eProducto estruc[],int tamU,int tamP,int idUs)
{
    int indice,i;


    indice=BuscarUSID(dato,tamU,idUs);


    for(i=0; i<tamP; i++)
    {
        if(estruc[i].idProvedor==dato[indice].idProvedor)
        {
            if(dato[indice].estado==1)
            {
                mostrarP(estruc[i]);

            }

        }
    }

}
//*****************************************************************
int buscarPorProvedor(eProducto dato[],int tam,int aux,int id)
{
    int i;
    int retorno;

    for(i=0; i<tam; i++)
    {
        if(aux==dato[i].idProducto&&id==dato[i].idProvedor)
        {
            retorno=i;
            break;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;

}
//*****************************************************************
void modificarProducto(eProducto dato[],eProvedor estruc[],int tamP,int tamU)
{
    int aux,indice,Publicaciones,auxId,opcion;
    float auxPrecio;
    char respuesta;
    char auxP[30];
    char confirm;
    char auxOP[50];
    aux=numIDProvedor(auxP,estruc,tamU);
    publcacionesProvedor(estruc,dato,tamU,tamP,aux);

    printf("\n Ingrese el Codigo de publicacion que desea modificar: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxP);
    isNumber(auxP);
    auxId=atoi(auxP);
    indice=buscarPorProvedor(dato,tamP,auxId,aux);
    while(indice==-1)
    {
        printf("\nPublicacion Inexistente\n");
        printf("\n Reingrese el Codigo de publicacion que desea modificar: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxP);
        isNumber(auxP);
        aux=atoi(auxP);
        indice=buscarPorProvedor(dato,tamP,auxId,aux);

    }
    mostrarP(dato[indice]);
    printf("\nDesea modificar este preducto?(s/n)\n");
    setbuf(stdin,NULL);
    confirm=getch();
    while(confirm!='s'&&confirm!='n')
    {
        printf("ERROR\n");
        printf("Desea modificar el nombre de este usuario? [s/n]");
        setbuf(stdin,NULL);
        confirm=getch();
    }
    if(confirm=='s')
    {
        do
        {
            printf("1-Modificar Descripcion\n");
            printf("2-Modificar importe\n");
            printf("3-Modificar stock\n");
            printf("4-Salir\n");
            printf("Ingrese una opcion: ");
            setbuf(stdin,NULL);
            scanf("%s",auxOP);
            if(verifNumero(auxOP)==1)
            {
                opcion=atoi(auxOP);
            }
            switch(opcion)
            {
            case 1:
                printf("Descripcion: %s\n",dato[indice].Descripcion);
                printf("Desea modificar la descripcion de este Producto? [s/n]");
                setbuf(stdin,NULL);
                confirm=getch();
                while(confirm!='s'&&confirm!='n')
                {
                    printf("ERROR\n");
                    printf("Desea modificar la descripcion de este Producto? [s/n]");
                    setbuf(stdin,NULL);
                    confirm=getch();
                }
                if(confirm=='s')
                {
                    printf("\n Ingrese la descripcion: ");
                    setbuf(stdin,NULL);
                    scanf("%[^\n]",dato[indice].Descripcion);
                    isWord(dato[indice].Descripcion);
                    printf("\n Modificacion realizada con Exito\n");
                }
                else
                {
                    printf("Accion cancelada por el Usuario");
                }

                break;
            case 2:
                printf("Importe: %.2f\n",dato[indice].importe);
                printf("Desea modificar el importe de este producto? [s/n] ");
                setbuf(stdin,NULL);
                confirm=getch();
                while(confirm!='s'&&confirm!='n')
                {
                    printf("ERROR\n");
                    printf("Desea modificar el importe de este producto? [s/n] ");
                    setbuf(stdin,NULL);
                    confirm=getch();
                }
                if(confirm=='s')
                {
                    printf("\nIngrese el importe: ");
                    setbuf(stdin,NULL);
                    scanf("%[^\n]",auxOP);
                    isFloat(auxOP);
                    auxPrecio=atof(auxOP);
                    dato[indice].importe=auxPrecio;
                    printf("\n Modificacion realizada con Exito\n");
                }
                else
                {
                    printf("Accion cancelada por el Usuario");
                }
                break;
            case 3:
                printf("Stock: %s\n",dato[indice].stock);
                printf("Desea modificar el Stock de este Producto? [s/n]");
                setbuf(stdin,NULL);
                confirm=getch();
                while(confirm!='s'&&confirm!='n')
                {
                    printf("ERROR\n");
                    printf("Desea modificar el Stock de este Producto? [s/n]");
                    setbuf(stdin,NULL);

                    confirm=getch();
                }
                if(confirm=='s')
                {
                    printf("\nIngrese el stock: ");
                    setbuf(stdin,NULL);
                    scanf("%[^\n]",auxP);
                    isNumber(auxP);
                    aux=atoi(auxP);
                    dato[indice].stock=aux;
                    printf("\n Modificacion realizada con Exito\n");
                }
                else
                {
                    printf("Accion cancelada por el Usuario");
                }
                break;

            case 4:
                respuesta='n';
                break;
            default:
                printf("Ingrese una opcion entre 1-4\n");

                break;
            }


        }
        while(respuesta=='s');
    }
    else
    {
        printf("Accion cancelada por el Usuario");
    }


}
//***************************************************************************************
void BajaProducto(eProvedor estruc[],eProducto dato[],int tamU,int tamP)
{
    int IdPubli,indice,Publicaciones,aux;
    int IdUs=0;
    float auxPrecio;
    char respuesta;
    char auxP[30];
    char confirm;
    IdUs=numIDProvedor(auxP,estruc,tamU);
    publcacionesProvedor(estruc,dato,tamU,tamP,IdUs);

    printf("\n Ingrese el Codigo de publicacion que desea eliminar: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxP);
    isNumber(auxP);
    IdPubli=atoi(auxP);
    indice=buscarPorProvedor(dato,tamP,IdPubli,IdUs);
    while(indice==-1)
    {
        printf("\nPublicacion Inexistente\n");
        printf("\n Reingrese el Codigo de producto que desea eliminar: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxP);
        isNumber(auxP);
        aux=atoi(auxP);
        indice=buscarPorProvedor(dato,tamP,aux,IdUs);
        system("pause");
        system("cls");

    }
    mostrarP(dato[indice]);
    printf("\nDesea eliminar este preducto?(s/n)\n");
    setbuf(stdin,NULL);
    confirm=getch();
    while(confirm!='s'&&confirm!='n')
    {
        printf("ERROR\n");
        printf("Desea eliminar este preoducto? [s/n]");
        setbuf(stdin,NULL);
        confirm=getch();
    }
    if(confirm=='s')
    {
        dato[indice].estado=0;
        printf("\n Se ha eliminado la publicacion Exitosamente\n");
    }
    else
    {
        printf("Accion cancelada por el Usuario");
    }


}
//****************************************************************
void ListarProductos(eProducto dato[],int tam)
{
    int i,j;
    eProducto auxiliar;
    for(i=0; i<tam-1; i++)
    {
        for(j=i+1; j<tam; j++)
        {
            if(dato[i].estado==1&&dato[j].estado==1)
            {
                if(dato[i].importe>dato[j].importe)
                {
                    auxiliar=dato[i];
                    dato[i]=dato[j];
                    dato[j]=auxiliar;

                }
                else
                {
                    if(dato[i].importe==dato[j].importe)
                    {
                        if(strcmpi(dato[i].Descripcion,dato[j].Descripcion)>0)
                        {
                            auxiliar=dato[i];
                            dato[i]=dato[j];
                            dato[j]=auxiliar;

                        }
                    }
                }
            }


        }
    }
    mostrarPS(dato,tam);
}
//*************************************************************
void productosMenor10(eProducto dato[],int tam)
{
    printf("\nProductos con stock menor o igual a 10\n");
    int i;
    for(i=0; i<tam; i++)
    {
        if(dato[i].stock<11)
        {
            mostrarP(dato[i]);
        }
    }
}
//***********************************************************
void productosMayor10(eProducto dato[],int tam)
{
    printf("\nProductos con stock mayor a 10\n");
    int i;
    for(i=0; i<tam; i++)
    {
        if(dato[i].stock>10)
        {
            mostrarP(dato[i]);
        }
    }
}
void importes(eProducto dato[],int tam)
{
    int i,cont=0;
    int masP=0;
    int menosP=0;
    int contSmy10=0;
    int contSme10=0;
    float total=0;
    float promedio;
    for(i=0; i<tam; i++)
    {
        if(dato[i].estado==1)
        {
            total+=dato[i].importe;
            cont++;
        }

    }

    promedio=total/cont;
    for(i=0;i<tam;i++)
    {
        if(dato[i].estado==1)
        {
            if(promedio<dato[i].importe)
            {
                masP++;
            }
            else
            {
                menosP++;
            }
            if(dato[i].stock>10)
            {
                contSmy10++;
            }
            else
            {
                contSme10++;
            }

        }

    }

    printf("\n El Importe promedio es: %.2f",promedio);
    printf("\n La cantidad de productos que no superan el importe promedio son: %d",menosP);
    printf("\n La cantidad de productos que  superan el importe promedio son: %d",masP);
    printf("\nLa cantidad de productos cuyo stock es menor o igual a 10 es: %d",contSme10);
     printf("\nLa cantidad de productos cuyo stock es mayor a 10 es: %d",contSmy10);



}
void productosMasImportes(eProducto dato[], int tam)
{
    int i,cont=0;
    int masP=0;
    int menosP=0;
    float total=0;
    float promedio;
    for(i=0; i<tam; i++)
    {
        if(dato[i].estado==1)
        {
            total+=dato[i].importe;
            cont++;
        }

    }

    promedio=total/cont;
     printf("\n Productos mayores al importe promedio: ");
    for(i=0;i<tam;i++)
    {
        if(dato[i].estado==1)
        {
            if(dato[i].importe>promedio)
            {
                mostrarP(dato[i]);
            }


        }

    }

}
void productosMenosImportes(eProducto dato[], int tam)
{
    int i,cont=0;
    int masP=0;
    int menosP=0;
    float total=0;
    float promedio;
    for(i=0; i<tam; i++)
    {
        if(dato[i].estado==1)
        {
            total+=dato[i].importe;
            cont++;
        }

    }

    promedio=total/cont;
    printf("\n Productos menores al importe promedio: ");
    for(i=0;i<tam;i++)
    {
        if(dato[i].estado==1)
        {
            if(dato[i].importe<promedio)
            {
                mostrarP(dato[i]);
            }


        }

    }

}

