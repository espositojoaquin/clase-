
int menu(char auxOP[]);
int verifNumero(char cad[]);
