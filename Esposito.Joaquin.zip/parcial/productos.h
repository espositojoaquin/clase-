
typedef struct
{
    int idProducto;
    int idProvedor;
    char Descripcion[50];
    float importe;
    int stock;
    int estado;
}eProducto;
void inicializarEstado(eProducto dato[],int tam);
