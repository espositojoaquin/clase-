#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "provedores.h"
#include "productos.h"
#include "input.h"
#define TAM 100
#define TAM2 1000
int menu(char auxOP[])
{
    int opcion;
        printf("1.Altas \n");
        printf("2.Modificar \n");
        printf("3.Baja \n");
        printf("4.Informar \n");
        printf("5.Listar \n");
        printf("6.salir\n");
        printf("Ingrese una opcion: \n");
        setbuf(stdin,NULL);
        scanf("%s",auxOP);
        isNumber(auxOP);
        opcion=atoi(auxOP);
        return opcion;

}
//*********************************************************************************************
int verifNumero(char cad[])
{
    int tam;
    int i;
    int retorno;
    tam= strlen(cad);
    for(i=0; i<tam; i++)
    {
        if(cad[i]>'9'||cad[i]<'0')
        {
            retorno=0;
            break;
        }
        else
        {
            retorno=1;
        }
    }
    return retorno;
}
//******************************************************************************************************
void isNumber(char aux[])
{
    while(verifNumero(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");


    }
}
//******************************************************************************************************
int verifFloat(char cad[])
{
    int tam;
    int i;
    int cont=0;
    int retorno;
    tam= strlen(cad);
    for(i=0; i<tam; i++)
    {
        if(cad[i]=='.')
        {
            cont++;
        }
        if(cad[i]>'9'&&cad[i]!='.'||cad[i]<'0'&&cad[i]!='.')
        {
            retorno=0;
            break;
        }
        else
        {
            if(cont>1)
            {
                retorno=0;
            }
            else
            {
                retorno=1;
            }

        }
    }
    return retorno;
}
//*******************************************************************************************
void isFloat(char aux[])
{
    while(verifFloat(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");


    }
}
//*******************************************************************************************
int EsLetra(char letras[])
{
    int i,retorno;
    int tam=strlen(letras);
    strlwr(letras);

    for(i=0; i<tam; i++)
    {
        if(letras[i]<'a'&&letras[i]!=' '||letras[i]>'z'&&letras[i]!=' ')
        {
            retorno=0;
            break;
        }
        else
        {

            retorno=1;
            letras[0]=toupper(letras[0]);

        }
    }
    return retorno;
}
//*******************************************************************************
void isWord(char aux[])
{
    while(EsLetra(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");

    }
}
//*******************************************************************************
int VefAphaandNumber(char aux[])
{
    int retorno;
    int i;
    int tam=strlen(aux);
    for(i=0; i<tam; i++)
    {
        if(aux[i]>' '&&aux[i]<'/'||aux[i]>'9'&&aux[i]<'`'||aux[i]>'z')
        {
            retorno=0;
        }
        else
        {
            retorno=1;
        }

    }

    return retorno;
}
//***************************************************************************
void isAlphaNumber(char aux [])
{
    while(VefAphaandNumber(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");

    }
}
