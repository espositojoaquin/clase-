#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "provedores.h"
#include "productos.h"
#include "input.h"
#define TAM 100
#define TAM2 1000
void inicializarEstadoP(eProvedor dato[],int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        dato[i].estado=0;


    }

}
void ID1(eProvedor dato[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {

         dato[i].idProvedor=i+1;

    }
}

void Harcodeo(eProvedor dato[])
{   int i;
    char descripcion[5][50]={"provedor 1","provedor 2","provedor 3","provedor 4","provedor 5"};

    for(i=0;i<5;i++)
    {
        strcpy(dato[i].descripcion,descripcion);
        dato[i].estado=1;
    }


}
int BuscarUSID(eProvedor dato[],int tam,int aux)
{
    int i,flag=0;
    int retorno;

    for(i=0; i<tam; i++)
    {

        if(aux==dato[i].idProvedor)
        {
            if(dato[i].estado==1)
            {
                retorno=i;
                flag=1;
                break;

            }

        }
        if(flag==0)
        {
            retorno=-1;
        }
    }
    return retorno;
}
