
typedef struct
{
    int idProvedor;
    char descripcion[50];
    int estado;
}eProvedor;
