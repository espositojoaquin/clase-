
#include "funciones.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>


void inicializarRP(EPropietario propietario[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {
        propietario[i].estado=0;
    }

}

int EspacioLibre(EPropietario propietario[],int tam)
{
    int i;
    int flag= -1;
    for(i=0; i<tam; i++)
    {
        if(propietario[i].estado==0)
        {
            flag=i;
            break;
        }
    }
    return flag;
}
void IngresoDatos(EPropietario propietario[],int tam)
{

    int i;


    for(i=0; i<tam; i++)
    {
        if(propietario[i].estado==0)
        {
            printf("\ningrese su codido de identificacion: ");
            scanf("%d",&propietario[i].id);
            printf("\nPor favor ingrese su nombre y apellido: ");
            fflush(stdin);
            gets(propietario[i].NombreAP);
            printf("\ningrese su direccion: ");
            fflush(stdin);
            gets(propietario[i].direccion);
            printf("\ningrese su numero de tarjeta: ");
            scanf("%lld",&propietario[i].tarjeta);
            propietario[i].estado=1;
            mostrarPersonaIgresada(propietario[i]);
            printf("\n %d \n",propietario[i].id);

            break;
        }
    }

}
void mostrarPersonaIgresada(EPropietario gente)
{
    printf("\n%s\t%s\t%lld\n",gente.NombreAP,gente.direccion,gente.tarjeta);
}

void altaPropietario(EPropietario gente[],int tam)
{


    int EL;

    EL=EspacioLibre(gente,tam);
    if(EL==-1)
    {
        printf("No hay mas espacio disponible \n");
        system("pause");
        system("cls");


    }
    else
    {
        IngresoDatos(gente,tam);

        system("pause");
        system("cls");

    }


}
//***************************************************************
void ModificarP(EPropietario gente[],int TAM)
{
    int i;
    int flag=0;
    long long int aux;
    char respuesta='s';
    printf("\nPor favor ingrese el numero de su tarjeta de credito: ");
    scanf("%lld",&aux);
    for(i=0; i<TAM; i++)
    {
        if(aux==gente[i].tarjeta)
        {
            flag=1;
            printf(" Desea modificar este numero de Tarjeta de Credito?(s/n)\n %s\t%lld \n",gente[i].NombreAP,gente[i].tarjeta);
            fflush(stdin);
            respuesta=getch();
            while(respuesta!='s'&&respuesta!='n')
            {
                printf("Por favor responda (s/n)\n");
                fflush(stdin);
                respuesta=getch();
                system("pause");
                system("cls");
            }
            if(respuesta=='s')
            {
                printf("\nIngrese el nuevo numero de su Tarjeta: ");
                scanf("%lld",&aux);
                gente[i].tarjeta=aux;
                printf("Tarjeta modificada con exito\n");
                system("pause");
                system("cls");
                break;
            }
            else
            {
                printf("Accion cancelada por el usuario\n");
                system("pause");
                system("cls");
                break;
            }
        }

    }
    if(flag==0)
    {
        printf(" Tarjeta inexistente\n");
        system("pause");
        system("cls");

    }

}
//**************************************************************************

void inicializarRPA(EAuto propietario[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {
        propietario[i].estado=0;
    }

}
//************************************************************************

int EspacioLibreA(EAuto propietario[],int tam)
{
    int i;
    int flag= -1;
    for(i=0; i<tam; i++)
    {
        if(propietario[i].estado==0)
        {
            flag=i;
            break;
        }
    }
    return flag;
}
//************************************************************************
void IngresoDatosA(EAuto propietario[],int tam)
{

    int i;


    for(i=0; i<tam; i++)
    {
        if(propietario[i].estado==0)
        {
            printf("\ningrese su codigo de identificacion: ");
            scanf("%d",&propietario[i].idPropietario);
            printf("\nPor favor ingrese la marca: ");
            fflush(stdin);
            gets(propietario[i].marca);
            printf("\ningrese su patente: ");
            fflush(stdin);
            gets(propietario[i].patente);
            printf("\nintroduzca el horario de ingreso : ");
            scanf("%f",&propietario[i].hora);
            propietario[i].estado=1;
            mostrarPersonaIgresadaA(propietario[i]);
            printf("\n%d",propietario[i].idPropietario);

            break;
        }
    }


}
//**************************************************************************

void mostrarPersonaIgresadaA(EAuto gente)
{
    printf("\n%s\t%s\t%.2f\n",gente.marca,gente.patente,gente.hora);
}
//**************************************************************************
void altaAuto(EAuto gente[],int tam)
{


    int EL;

    EL=EspacioLibreA(gente,tam);
    if(EL==-1)
    {
        printf("No hay mas espacio disponible \n");
        system("pause");
        system("cls");


    }
    else
    {
        IngresoDatosA(gente,tam);

        system("pause");
        system("cls");

    }


}
//****************************************************************************
/*void Egreso(EAuto gente[],EPropietario propietario[],int TAM)
{
    int i,j;
    int flag=0;
    int aux;
    float resultado;
    float hora;
    char respuesta='s';
    printf("\nPor favor ingrese el codigo de indentificacion del auto: ");
    scanf("%d",&aux);

    for(i=0;i<TAM;i++)
    {
        for(j=0;j<TAM;j++)
        {
            if(propietario[i].id==aux&&gente[j].idPropietario==aux)
            {
                flag=1;
                printf(" Desea que este auto salga del estacionamiento ?(s/n)\n %s\t%s\t%s \n",propietario[i].NombreAP,gente[j].marca,gente[j].patente);
                fflush(stdin);

                //respuesta=getch();
                while(respuesta!='s'&&respuesta!='n')
                {
                    printf("Por favor responda (s/n)\n");
                    fflush(stdin);
                    respuesta=getch();
                    system("pause");
                    system("cls");
                }
                if(respuesta=='s')
                {
                    printf("\ningrese el horario de salida: ");
                    scanf("%f",&hora);
                    resultado=(hora-gente[i].hora);
                    gente[i].estado=0;
                    printf("\n%s\t\%s\t%s\t%.2f\n",propietario[j].NombreAP,gente[i].marca,gente[i].patente,resultado);
                    system("pause");
                    system("cls");
                    break;
                }
                else
                {
                    printf("Accion cancelada por el usuario\n");
                    system("pause");
                    system("cls");
                    break;
                }
            }

            /* if(aux==propietario[i].id)
             {
                 if(propietario[i].id==gente[j].idPropietario)
                 {
                     flag=1;
                     printf(" Desea que este auto salga del estacionamiento ?(s/n)\n %s\t%s\t%s \n",propietario[i].NombreAP,gente[j].marca,gente[j].patente);
                     fflush(stdin);
                     respuesta=getch();
                     while(respuesta!='s'&&respuesta!='n')
                     {
                         printf("Por favor responda (s/n)\n");
                         fflush(stdin);
                         respuesta=getch();
                         system("pause");
                         system("cls");
                     }
                     if(respuesta=='s')
                     {
                         printf("\ningrese el horario de salida: ");
                         scanf("%f",&hora);
                         resultado=(hora-gente[i].hora);
                         gente[i].estado=0;
                         printf("\n%s\t\%s\t%s\t%.2fn",propietario[j].NombreAP,gente[i].marca,gente[i].patente,resultado);
                         system("pause");
                         system("cls");
                         break;
                     }
                     else
                     {
                         printf("Accion cancelada por el usuario\n");
                         system("pause");
                         system("cls");
                         break;
                     }
                 }


        }

    }
    if(flag==0)
    {
        printf(" El auto ingresado jamas entro en la playa de estacionamiento\n");
        system("pause");
        system("cls");

    }
}*/
//******************************************************************************************
void harcodear(EPropietario propietario[], int tam)
{
    int Id[5] = {1001, 1002, 1003, 1004, 1005};
    char Nombre[5][30] = {"Nicolas","Juan","Marcos","Pedro","Leandro"};
    char direccion[5][35] = {"Uruguayo 588","Paraguayo 645","Argentino 456","Colombiano 123","Aleman 147"};
    long long int tarjeta[5]= {1234567894561236,1234567894561235,1234567894561234,1234567894561233,1234567894561289};


    int i;
    for(i=0; i<tam; i++)
    {
        propietario[i].id = Id[i];
        strcpy(propietario[i].NombreAP, Nombre[i]);
        strcpy(propietario[i].direccion, direccion[i]);
        propietario[i].tarjeta=tarjeta[i];
        propietario[i].estado=1;
    }
    for(i=0; i<tam; i++)
    {
        if(propietario[i].estado==1)
        {
            mostrarPersonaIgresada(propietario[i]);
        }

    }



}
void harcodear2( EAuto autos[], int tam)
{

    int IdPropis[5] = {1001, 1002, 1003, 1004, 1005};
    char Patente[5][30] = {"asd456","wer789","vbn132","jkl465","iop456"};
    char marca[5][35] = {"Audi","Alpha_Romeo","Ferrari","Otros","Audi"};
    float hora[5] = {15.30,14.30,21.50,18.10,23.00};
    int i;
    for(i=0; i<tam; i++)
    {
        autos[i].idPropietario=IdPropis[i];
        strcpy(autos[i].patente,Patente[i]);
        strcpy(autos[i].marca,marca[i]);
        autos[i].hora=hora[i];

        autos[i].estado=1;

    }
    for(i=0; i<tam; i++)
    {
        if(autos[i].estado==1)
        {
            mostrarPersonaIgresadaA(autos[i]);
        }


    }
}
//********************************************************************************
void Egreso(EAuto aut[],EPropietario propietario[],int tam)
{
    int i,j,flag=0;
    char auxPat[30];
    char respuesta;
    float hora,resultado,precioF,retorno,precio/*,precio*/;

    printf("Por favor ingrese la patente de su auto: ");
    fflush(stdin);
    gets(auxPat);

    for(i=0;i<tam;i++)
    {
        for(j=0;j<tam;j++)
        {
            if(strcmpi(auxPat,aut[j].patente)==0)
            {
                flag=1;
                printf("\nDesea que este auto salga del estacionamiento(s/n): %s\t%s\t%.2f\n",aut[j].patente,aut[j].marca,aut[j].hora);
                fflush(stdin);
                respuesta=getch();

                while(respuesta!='s'&&respuesta!='n')
                {
                    printf("Por favor responda (s/n)\n");
                    fflush(stdin);
                    respuesta=getch();
                    system("pause");
                    system("cls");
                }
                if(respuesta=='s')
                {
                    if(propietario[i].id==aut[j].idPropietario)
                    {
                        printf("\ningrese el horario de salida: ");
                        scanf("%f",&hora);
                        if(strcmpi(aut[i].marca,"Audi")==0)
                        {
                            retorno=200;
                        }
                        else
                        {
                            if(strcmpi(aut[i].marca,"Alpha_Romeo")==0)
                            {
                                retorno=150;


                            }
                            else
                            {
                                if(strcmpi(aut[i].marca,"Ferrari")==0)
                                {
                                    retorno=175;


                                }
                                else
                                {
                                    retorno=250;
                                }

                            }
                        }
                        resultado=(hora-aut[j].hora);
                        precioF=retorno*resultado;

                        printf("\n\t\tTICKET\n");
                        printf("\n%s\t%s\t%s\t%.2f",propietario[i].NombreAP,aut[j].patente,aut[j].marca,precioF);

                        system("pause");
                        system("cls");

                    }
                }
                else if(respuesta=='n')
                {
                    printf("Accion cancelada por el usuario\n");
                    system("pause");
                    system("cls");

                }



            }


        }


    }
    if(flag==0)
    {
        printf("\nERROR");

    }

}















