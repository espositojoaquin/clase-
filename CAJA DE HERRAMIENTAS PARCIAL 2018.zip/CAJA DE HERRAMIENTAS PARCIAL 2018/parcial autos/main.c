#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"
#define TAM 5

int main()
{
char seguir='s';
int opcion=0;
EPropietario propietario[20];
EAuto aut[20];
inicializarRP(propietario,TAM);
inicializarRPA(aut,TAM);
  while(seguir=='s')
    {   printf("\t\tREGISTRO DE ESTACIONAMIETO\n");
        printf("\n1- Alta de propietario\n");
        printf("2- Modificacion de propietario\n");
        printf("3- ingreso de automobil\n");
        printf("4- Egreso de automobil\n");
        printf("5- informe\n");
        printf("6- Harcodeo de datos\n");
        printf("7- salir\n");

        printf("\ningrese una opcion: ");

        scanf("%d",&opcion);
        system("pause");
        system("cls");
        while(opcion<1||opcion>7)
        {
            printf("Reingrese una opcion (1-7) :");

            scanf("%d",&opcion);
            system("pause");
            system("cls");

        }
        switch(opcion)
        {

        case 1:
                   altaPropietario(propietario,TAM);

            break;
        case 2:    ModificarP(propietario,TAM);

            break;
        case 3:    altaAuto(propietario,TAM);

            break;
        case 4:   Egreso(aut,propietario,TAM);

            break;
        case 5:

            break;
        case 6:  harcodear(propietario,TAM);
                 printf("\n");
                 harcodear2(aut,TAM);

            break;

        case 7:
            seguir = 'n';
            break;
        }
    }

    return 0;
}
