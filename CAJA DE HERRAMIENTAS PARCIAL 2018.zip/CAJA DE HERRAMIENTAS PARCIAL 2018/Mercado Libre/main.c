#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "funciones.h"
#define TAM 100
#define TAM2 1000


int main()
{
    int opcion,idUs;
    char respuesta='s';
    char auxOP[30];
    eUsuario Usuario[TAM];
    eProducto producto [TAM2];
    inicializarUS(Usuario,TAM);
    inicializarESTP(producto,TAM2);
    IDusuario(Usuario,TAM);
    IDProducto(producto,TAM2);
    inicializarVentas(producto,TAM2);
    HardCode(producto);
    HarcodeUsuarios(Usuario);
    do
    {
        /*printf("1. Alta Usuario\n");
        printf("2. Modificar datos del usuario\n");
        printf("3. Baja de Usuario\n");
        printf("4. Publicar producto\n");
        printf("5.Modificar Publicacion\n");
        printf("6.Cancelar publicacion\n");
        printf("7.Comprar Producto\n");
        printf("8.Listar Publicaciones de Usuarios\n");
        printf("9.Listar Publicaciones\n");
        printf("10.Listar Usuarios\n");
        printf("11.Salir\n");
        printf("Ingrese una opcion: \n");
        setbuf(stdin,NULL);

        scanf("%s",auxOP);
        if(verifNumero(auxOP)==1)
        {
            opcion=atoi(auxOP);
        }*/
        opcion=menu(auxOP);
        switch(opcion)
        {
        case 1: AltaUsuario(Usuario,TAM);

            system("pause");
            system("cls");
            break;
        case 2:
            modificarUsuario(Usuario,TAM);
             system("pause");
            system("cls");

            break;
        case 3: Baja(Usuario,producto,TAM,TAM2);

            system("pause");
            system("cls");
            break;
        case 4: AltaProducto(producto,TAM2,Usuario,TAM);

            system("pause");
            system("cls");
            break;
        case 5: modificarPublicacion(producto,Usuario,TAM2,TAM);
            system("pause");
            system("cls");
            break;
        case 6: BajaPublicacion(Usuario,producto,TAM,TAM2);
            system("pause");
            system("cls");
            break;
        case 7: comprar(producto,Usuario,TAM,TAM2);
            system("pause");
            system("cls");
             break;
        case 8: idUs=numIDusuario(auxOP,Usuario,TAM);
            publcacionesUsuarios(Usuario,producto,TAM,TAM2,idUs);
            system("pause");
            system("cls");
             break;
        case 9: mostrarPRODUCTOS(producto,TAM2);
                PrecioMasAlto(producto,TAM2);
            system("pause");
            system("cls");
             break;
        case 10:listarUsuarioCali(Usuario,producto,TAM,TAM2);
            system("pause");
            system("cls");
             break;
        case 11:
            respuesta='n';
            break;
        default:
            printf("Ingrese una opcion entre 1-11\n");

            break;
        }


    }
    while(respuesta=='s');
    return 0;
}
