#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "funciones.h"

void inicializarUS(eUsuario dato[],int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        dato[i].estado=0;


    }

}
//*******************************************************************************
void inicializarESTP(eProducto dato[],int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        dato[i].estado=0;


    }

}
//*******************************************************************************
void inicializarVentas(eProducto dato[],int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        dato[i].sVendida=0;

    }

}
//*******************************************************************************
int EspacioLibre(eUsuario dato[],int tam)
{
    int i;
    int retorno;
    for(i=0; i<tam; i++)
    {
        if(dato[i].estado==0)
        {
            retorno=i;
            break;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;
}
//**************************************************************************************************************
int buscarUsuario(eUsuario dato[],char DNI[],int tam)
{
    int i;
    int retorno;

    for(i=0; i<tam; i++)
    {
        if(strcmpi(DNI,dato[i].documento)==0)
        {
            retorno=1;
            break;
        }
        else
        {
            retorno=0;
        }
    }
    return retorno;
}
//**************************************************************************************************************
void IDusuario(eUsuario dato[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {

         dato[i].idUsuario=i+1;

    }
}
//**************************************************************************************************************
void IDProducto(eProducto dato[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {

        dato[i].idProducto=i+100;


    }
}
//**************************************************************************************************************
int verifNumero(char cad[])
{
    int tam;
    int i;
    int retorno;
    tam= strlen(cad);
    for(i=0; i<tam; i++)
    {
        if(cad[i]>'9'||cad[i]<'0')
        {
            retorno=0;
            break;
        }
        else
        {
            retorno=1;
        }
    }
    return retorno;
}
//**************************************************************************************************************
int verifFloat(char cad[])
{
    int tam;
    int i;
    int cont=0;
    int retorno;
    tam= strlen(cad);
    for(i=0; i<tam; i++)
    {
        if(cad[i]=='.')
        {
            cont++;
        }
        if(cad[i]>'9'&&cad[i]!='.'||cad[i]<'0'&&cad[i]!='.')
        {
            retorno=0;
            break;
        }
        else
        {
            if(cont>1)
            {
                retorno=0;
            }
            else
            {
                retorno=1;
            }

        }
    }
    return retorno;
}
//**************************************************************************************************************
int EsLetra(char letras[])
{
    int i,retorno;
    int tam=strlen(letras);
    strlwr(letras);

    for(i=0; i<tam; i++)
    {
        if(letras[i]<'a'&&letras[i]!=' '||letras[i]>'z'&&letras[i]!=' ')
        {
            retorno=0;
            break;
        }
        else
        {

            retorno=1;
            letras[0]=toupper(letras[0]);

        }
    }
    return retorno;
}
//**************************************************************************************************************
void validarDNI(char aux[],eUsuario dato[],int tam)
{
    while(verifNumero(aux)==0)
    {
        system("pause");
        system("cls");
        printf("Ingrese un DNI Valido: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");


    }
    while(strlen(aux)<7||strlen(aux)>8)
    {
        system("pause");
        system("cls");
        printf("Ingrese un DNI Valido: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");

    }
    while(buscarUsuario(dato,aux,tam)==1)
    {
        system("pause");
        system("cls");
        printf("Este Usuario ya ha cido registrado");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");

    }


}
//**************************************************************************************************************
void isWord(char aux[])
{
    while(EsLetra(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");

    }
}
//**************************************************************************************************************
void isNumber(char aux[])
{
    while(verifNumero(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");


    }
}
//**************************************************************************************************************
void isFloat(char aux[])
{
    while(verifFloat(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");


    }
}
//**************************************************************************************************************
int VefAphaandNumber(char aux[])
{
    int retorno;
    int i;
    int tam=strlen(aux);
    for(i=0; i<tam; i++)
    {
        if(aux[i]>' '&&aux[i]<'/'||aux[i]>'9'&&aux[i]<'`'||aux[i]>'z')
        {
            retorno=0;
        }
        else
        {
            retorno=1;
        }

    }

    return retorno;
}

//**************************************************************************************************************
void isAlphaNumber(char aux [])
{
    while(VefAphaandNumber(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");

    }
}
//**************************************************************************************************************
void AltaUsuario(eUsuario dato[],int tam)
{
    int indice,i;
    char aux[50];
    char auxEdad[30];
    indice=EspacioLibre(dato,tam);
    if(indice==-1)
    {
        printf("NO HAY MAS ESPACIO DISPONIBLE\n");
    }
    else
    {
        printf("Por favor ingrese un numero de Documento: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        validarDNI(aux,dato,tam);
        if(buscarUsuario(dato,aux,tam)==0)
        {
            strcpy(dato[indice].documento,aux);
            printf("Igrese su nombre: ");
            setbuf(stdin,NULL);
            scanf("%[^\n]",dato[indice].nombre);
            isWord(dato[indice].nombre);
            printf("ingrese su edad: ");
            setbuf(stdin,NULL);
            scanf("%[^\n]",auxEdad);
            isNumber(auxEdad);
            dato[indice].edad=atoi(auxEdad);
            setbuf(stdin,NULL);
            printf("Por favor ingrese su direccion: ");
            scanf("%[^\n]",dato[indice].direccion);
            isAlphaNumber(dato[indice].direccion);
            dato[indice].estado=1;
            printf("Usuario registrado exitosamente\n");
            printf("Su numero de Usuario es: %.4d\n",dato[indice].idUsuario);

        }



    }

}
//************************************************************************************************
void mostrarUsuario(eUsuario dato)
{
    printf("|%-10s\t\t%-10d\t\t%-15s\t%-10s\t\t\t%-15.2f|\n",dato.nombre,dato.edad,dato.documento,dato.direccion,dato.promedio);
}

//**********************************************************************************************************
void mostrarUSUARIOS(eUsuario dato[],int tam)
{
    int i,flag=0;
    for(i=0; i<tam; i++)
    {
        if(dato[i].estado==1)
        {
            flag=1;
            if(i==0)
            {
                printf("|=======================================================================================================|\n");
                printf("|                                       USUARIOS                                                        |\n");
                printf("|=======================================================================================================|\n");
                printf("|   NOMBRE      |         EDAD        |        DOCUMENTO      |    DIRECCION          |    PROMEDIO     |\n");
                printf("|=======================================================================================================|\n");
            }

            mostrarUsuario(dato[i]);
        }

    }
    if(flag==0)
    {
        printf("No hay Usuarios ingresados\n");
    }
}
//************************************************************************************************
void mostrarProducto(eProducto dato)
{
    if(dato.estado==1)
    {
        printf("Nombre:%s\n id Vendedor:%d \n id Producto:%d\n stock:%d\n Precio:%.2f\n Vendidos: %d\n\n ",dato.nombre,dato.idUsuario,dato.idProducto,dato.stock,dato.precio,dato.sVendida);
    }

}
//************************************************************************************************
void mostrarPRODUCTOS(eProducto dato[],int tam)
{
    int i,flag=0;
    for(i=0; i<tam; i++)
    {
        if(dato[i].estado==1)
        {
            flag=1;

            mostrarProducto(dato[i]);
        }

    }
    if(flag==0)
    {
        printf("No hay Productos ingresados\n");
    }
}
//************************************************************************************************
void HardCode(eProducto dato[])
{

    int idUsuario[12]= {1,2,1,4,3,4,7,1,3,10};
    int idProducto[12]= {100,101,102,103,104,105,106,107,108,109};
    char nombre[12][50]= {"Enduido INT","Latex INT","Sintetico","Barniz INT","Barniz Marino","Laca poliuretanica","Lijas","Aguarras","Thiner","Latex EXT"};
    float precio[12]= {856,1800,240,190,200,350,23,96,120,2000};
    int stock[12]= {8,4,5,7,6,100,4,78,23,9};
    int estado;
    int i;
   // printf("\t\PRODUCTOS\n");

    for(i=0; i<10; i++)
    {
        strcpy(dato[i].nombre,nombre[i]);
        dato[i].idUsuario=idUsuario[i];
        dato[i].idProducto=idProducto[i];
        dato[i].precio=precio[i];
        dato[i].stock=stock[i];
        dato[i].estado=1;

    }
    // mostrarPRODUCTOS(dato,10);

}
//***************************************************************************************
  void HarcodeUsuarios(eUsuario dato[])
  {
    int edad[10]= {19,27,20,21,22,40,47,50,17,65};//33,37,15,26,28,29,25,23,36,45};
    char nombre[10][50]= {"Juan","Maria","Pedro","Julian","Martina","Julio","Kevin","Joaquin","Leonel","Brenda"};//,"Aldana","Luz","Agustin","Angel","Brian","Gladys","Ruben","Luis","Claudia","Vanina"};
    char dni[20][20]= {"40929964","40929954","40929966","40929969","47929964","40929914","40929963","48929964","41929964","42929964"};//,"43929964","44929964","45929964","46929964","40129964","40229964","41329964","40929644","40926984","40929147"};
    char Direccion[10][50]={"P.Javier 588","Ascasubi 456","Esperanza 452","Libertad 789","N.Pe�a 987","Jacarada 666","P.Buena 365","Boulevard 1919","Av Mitre 750","U.Gonzales 458 "};
    int estado;
    int i;
    for(i=0;i<10;i++)
    {
        dato[i].edad=edad[i];
        strcpy(dato[i].nombre,nombre[i]);
        strcpy(dato[i].documento,dni[i]);
        strcpy(dato[i].direccion,Direccion[i]);
        dato[i].estado=1;
    }
  }

//***************************************************************************************
int BuscarUSID(eUsuario dato[],int tam,int aux)
{
    int i,flag=0;
    int retorno;

    for(i=0; i<tam; i++)
    {

        if(aux==dato[i].idUsuario)
        {
            if(dato[i].estado==1)
            {
                retorno=i;
                flag=1;
                break;

            }

        }
        if(flag==0)
        {
            retorno=-1;
        }
    }
    return retorno;
}
//***************************************************************************************

//***************************************************************************************
void publcacionesUsuarios(eUsuario dato[],eProducto estruc[],int tamU,int tamP,int idUs)
{
    int indice,i;


    indice=BuscarUSID(dato,tamU,idUs);


    for(i=0; i<tamP; i++)
    {
        if(estruc[i].idUsuario==dato[indice].idUsuario)
        {
            if(dato[indice].estado==1)
            {
                mostrarProducto(estruc[i]);

            }
        }
    }




}
//***********************************************************************************
int numIDusuario(char cad[],eUsuario dato[],int tamU)
{
    int aux,indice;
    printf("Ingrese su numero de Usuario: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",cad);
    isNumber(cad);
    aux=atoi(cad);
    indice=BuscarUSID(dato,tamU,aux);
    while(indice==-1)
    {
        printf("Numero de Usuario inexistente\n");
        printf("Reingrese su numero de Usuario: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",cad);
        isNumber(cad);
        aux=atoi(cad);
        indice=BuscarUSID(dato,tamU,aux);
        system("pause");
        system("cls");
    }
    return aux;
}
//***********************************************************************************
void modificarUsuario(eUsuario dato[],int tam)
{
    int aux,indice,opcion;
    char respuesta='s';
    char auxOP[30];
    char confirm;
    printf("Ingres su numero de usuario: ");
    scanf("%d",&aux);
    indice=BuscarUSID(dato,tam,aux);
    if(indice!=-1)
    {
        do
        {
            printf("1-Modificar nombre\n");
            printf("2-Modificar edad\n");
            printf("3-Modificar Documento\n");
            printf("4-Modificar Direccion\n");
            printf("5-Salir\n");
            printf("Ingrese una opcion: ");
            setbuf(stdin,NULL);
            scanf("%s",auxOP);
            if(verifNumero(auxOP)==1)
            {
                opcion=atoi(auxOP);
            }
            switch(opcion)
            {
            case 1:
                printf("Nombre: %s\n",dato[indice].nombre);
                printf("Desea modificar el nombre de este usuario? [s/n]");
                setbuf(stdin,NULL);
                confirm=getch();
                while(confirm!='s'&&confirm!='n')
                {
                    printf("ERROR\n");
                    printf("Desea modificar el nombre de este usuario? [s/n]");
                    setbuf(stdin,NULL);
                    confirm=getch();
                }
                if(confirm=='s')
                {
                    printf("\n Ingrese su nombre: ");
                    setbuf(stdin,NULL);
                    scanf("%[^\n]",dato[indice].nombre);
                    isWord(dato[indice].nombre);
                    printf("\n Modificacion realizada con Exito\n");
                }
                else
                {
                    printf("Accion cancelada por el Usuario");
                }

                break;
            case 2:
                printf("Edad: %d\n",dato[indice].edad);
                printf("Desea modificar la edad de este usuario? [s/n] ");
                setbuf(stdin,NULL);
                confirm=getch();
                while(confirm!='s'&&confirm!='n')
                {
                    printf("ERROR\n");
                    printf("Desea modificar la edad de este usuario? [s/n] ");
                    setbuf(stdin,NULL);
                    confirm=getch();
                }
                if(confirm=='s')
                {
                    printf("\nIngrese su edad: ");
                    setbuf(stdin,NULL);
                    scanf("%[^\n]",auxOP);
                    isNumber(auxOP);
                    aux=atoi(auxOP);
                    dato[indice].edad=aux;
                    printf("\n Modificacion realizada con Exito\n");
                }
                else
                {
                    printf("Accion cancelada por el Usuario");
                }
                break;
            case 3:
                printf("DNI: %s\n",dato[indice].documento);
                printf("Desea modificar el DNI de este usuario? [s/n]");
                setbuf(stdin,NULL);
                confirm=getch();
                while(confirm!='s'&&confirm!='n')
                {
                    printf("ERROR\n");
                    printf("Desea modificar el DNI de este usuario? [s/n]");
                    setbuf(stdin,NULL);

                    confirm=getch();
                }
                if(confirm=='s')
                {
                    printf("\nIngrese su DNI: ");
                    setbuf(stdin,NULL);
                    scanf("%[^\n]",dato[indice].documento);
                    isNumber(dato[indice].documento);
                    printf("\n Modificacion realizada con Exito\n");
                }
                else
                {
                    printf("Accion cancelada por el Usuario");
                }
                break;
            case 4:
                printf("Direccion: %s\n",dato[indice].direccion);
                printf("Desea modificar la direccion de este usuario? [s/n]");
                setbuf(stdin,NULL);
                confirm=getch();
                while(confirm!='s'&&confirm!='n')
                {
                    printf("ERROR\n");
                    printf("Desea modificar la direccion de este usuario? [s/n]");
                    setbuf(stdin,NULL);
                    confirm=getch();
                }
                if(confirm=='s')
                {
                    printf("\nIngrese su direccion: ");
                    setbuf(stdin,NULL);
                    scanf("%[^\n]",dato[indice].direccion);
                    isAlphaNumber(dato[indice].direccion);
                    printf("\n Modificacion realizada con Exito\n");
                }
                else
                {
                    printf("Accion cancelada por el Usuario");
                }
                break;
            case 5:
                respuesta='n';
                break;
            default:
                printf("Ingrese una opcion entre 1-5\n");

                break;
            }


        }
        while(respuesta=='s');
    }
    else
    {
        printf("Usuario inexistente\n");
    }

}
//******************************************************************************
void Baja(eUsuario dato[],eProducto estruc[],int tamU,int tamP)
{
    int aux,i,indice;
    char confirm;
    char auxE[30];


    printf("Ingres su numero de usuario: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxE);
    isNumber(aux);
    aux=atoi(auxE);
    indice=BuscarUSID(dato,tamU,aux);
    if(indice!=-1)
    {
        mostrarUsuario(dato[indice]);
        printf("Desea elimar este Usuario y todas sus Publicaciones? [s/n]");
        setbuf(stdin,NULL);
        confirm=getch();
        while(confirm!='s'&&confirm!='n')
        {
            printf("ERROR\n");
            printf("Desea elimar este Usuario y todas sus Publicaciones? [s/n]");
            setbuf(stdin,NULL);
            confirm=getch();
        }
        if(confirm=='s')
        {
            dato[indice].estado=0;
            for(i=0; i<tamP; i++)
            {
                if(estruc[i].idUsuario==dato[indice].idUsuario)
                {
                    estruc[i].estado=0;
                }
            }

            printf("\n Usuario Eliminado con Exito\n");
        }
        else
        {
            printf("Accion cancelada por el Usuario");
        }

    }
}
//****************************************************************************
int buscarProducto(eProducto dato[],int tam,int aux)
{
    int i;
    int retorno;

    for(i=0; i<tam; i++)
    {
        if(aux==dato[i].idProducto)
        {
            retorno=i;
            break;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;

}
//****************************************************************************
int buscarPorUsuario(eProducto dato[],int tam,int aux,int id)
{
    int i;
    int retorno;

    for(i=0; i<tam; i++)
    {
        if(aux==dato[i].idProducto&&id==dato[i].idUsuario)
        {
            retorno=i;
            break;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;

}
//****************************************************************************
void comprar(eProducto dato[],eUsuario estruct[],int tamU,int tamP)
{
    int aux,indice,indice2;
    int auxU;
    char auxC[30];
    char confirm;
    mostrarPRODUCTOS(dato,tamP);
    printf("Ingrese el codigo del Producto que deseas comprar: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxC);
    isNumber(auxC);
    aux=atoi(auxC);
    indice=buscarProducto(dato,tamU,aux);

    if(indice!=-1)
    {
        mostrarProducto(dato[indice]);
        printf("Desea Comprar este producto? [s/n]");
        setbuf(stdin,NULL);
        confirm=getch();
        while(confirm!='s'&&confirm!='n')
        {
            printf("ERROR\n");
            printf("Desea Comprar este producto? [s/n]");
            setbuf(stdin,NULL);
            confirm=getch();
        }
        if(confirm=='s')
        {
            dato[indice].sVendida=dato[indice].sVendida+1;
            dato[indice].stock= dato[indice].stock-1;
            indice2=BuscarUSID(estruct,tamU,dato[indice].idUsuario);
            printf("\n La compra se ha realizado con Exito\n");
            if(indice2!=-1)
            {
                printf("\nPor favor ingrese una calificacion al Vendedor(1-10): ");
                setbuf(stdin,NULL);
                scanf("%[^\n]",auxC);
                isNumber(auxC);
                auxU=atoi(auxC);
                estruct[indice2].calificacion=estruct[indice2].calificacion+auxU;
                printf("\nGracais por su Calificacion\n");
            }


        }
        else
        {
            printf("Accion cancelada por el Usuario");
        }
    }

}
//************************************************************************
int buscarProIDU(eProducto dato[],int tam,int aux)
{
    int i;
    int retorno;

    for(i=0; i<tam; i++)
    {
        if(aux==dato[i].idUsuario)
        {
            retorno=i;
            break;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;

}
//************************************************************************
void listarUsuarioCali(eUsuario dato[],eProducto estruct[],int tamU,int tamP)
{
    int i,indice,indiceU,flag=0;
    float resultado;

    for(i=0; i<tamU; i++)
    {
        if(dato[i].estado==1)
        {
            indice=buscarProIDU(estruct,tamP,dato[i].idUsuario);

            if(indice!=-1)
            {


                indiceU=i;
                if(dato[indiceU].calificacion>0&&estruct[indice].sVendida>0)
                {
                    dato[indiceU].promedio=dato[indiceU].calificacion/(float)estruct[indice].sVendida;
                }
                else
                {
                     dato[indiceU].promedio=0;
                }




            }
        }



    }
      mostrarUSUARIOS(dato,tamU);
}
//*********************************************************************************************************************
//*******************************************************************************
int EspacioLibreProducto(eProducto dato[],int tam)
{
    int i;
    int retorno;
    for(i=0; i<tam; i++)
    {
        if(dato[i].estado==0)
        {
            retorno=i;
            break;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;
}
//*********************************************************************************************************************
void AltaProducto(eProducto dato[],int tamPro,eUsuario estruct[],int tamU)
{
    int indice;
    int auxID;
    char aux[50];
    char auxStock[30];
    indice=EspacioLibreProducto(dato,tamPro);
    if(indice==-1)
    {
        printf("NO HAY MAS ESPACIO DISPONIBLE\n");
    }
    else
    {
        printf("Por favor ingrese su Codigo de Usuario: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        isNumber(aux);
        auxID=atoi(aux);
        while(BuscarUSID(estruct,tamU,auxID)==-1)
        {
            printf("\nUsuario inexsitente\n");
            printf("\nPor favor reingresar Usuario: ");
            setbuf(stdin,NULL);
            scanf("%[^\n]",aux);
            isNumber(aux);
            auxID=atoi(aux);
            system("pause");
            system("cls");

        }

        dato[indice].idUsuario=auxID;

        printf("Igrese el nombre del producto: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",dato[indice].nombre);
        isWord(dato[indice].nombre);
        printf("Ingrese el Stock disponible : ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxStock);
        isNumber(auxStock);
        dato[indice].stock=atoi(auxStock);
        setbuf(stdin,NULL);
        printf("Por favor ingrese el Importe: ");
        scanf("%[^\n]",aux);
        isFloat(aux);
        dato[indice].precio=atof(aux);

        dato[indice].estado=1;
        printf("Publicacion registrada exitosamente\n");
        printf(" Su numero de publicacion es: %.4d\n",dato[indice].idProducto);

    }

}
void modificarPublicacion(eProducto dato[],eUsuario estruc[],int tamP,int tamU)
{
    int aux,indice,Publicaciones,auxId;
    float auxPrecio;
    char respuesta;
    char auxP[30];
    char confirm;
    aux=numIDusuario(auxP,estruc,tamU);
    publcacionesUsuarios(estruc,dato,tamU,tamP,aux);

    printf("\n Ingrese el Codigo de publicacion que desea modificar: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxP);
    isNumber(auxP);
    auxId=atoi(auxP);
    indice=buscarPorUsuario(dato,tamP,auxId,aux);
    while(indice==-1)
    {
        printf("\nPublicacion Inexistente\n");
        printf("\n Reingrese el Codigo de publicacion que desea modificar: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxP);
        isNumber(auxP);
        aux=atoi(auxP);
        indice=buscarProducto(dato,tamP,aux);


    }
    mostrarProducto(dato[indice]);
    printf("\nDesea modificar este preducto?(s/n)\n");
    setbuf(stdin,NULL);
    confirm=getch();
    while(confirm!='s'&&confirm!='n')
    {
        printf("ERROR\n");
        printf("Desea modificar el nombre de este usuario? [s/n]");
        setbuf(stdin,NULL);
        confirm=getch();
    }
    if(confirm=='s')
    {
        printf("\n Ingrese el nuevo precio: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxP);
        isFloat(auxP);
        auxPrecio=atof(auxP);
        dato[indice].precio=auxPrecio;
        printf("\n Ingrese el nuevo Stock: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxP);
        isNumber(auxP);
        aux=atoi(auxP);
        dato[indice].stock=aux;

        printf("\n Modificacion realizada con Exito\n");
    }
    else
    {
        printf("Accion cancelada por el Usuario");
    }


}
//************************************************************************************************************
void BajaPublicacion(eUsuario estruc[],eProducto dato[],int tamU,int tamP)
{
    int IdPubli,indice,Publicaciones,aux;
    int IdUs=0;
    float auxPrecio;
    char respuesta;
    char auxP[30];
    char confirm;
    IdUs=numIDusuario(auxP,estruc,tamU);
    publcacionesUsuarios(estruc,dato,tamU,tamP,IdUs);

    printf("\n Ingrese el Codigo de publicacion que desea eliminar: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxP);
    isNumber(auxP);
    IdPubli=atoi(auxP);
    indice=buscarPorUsuario(dato,tamP,IdPubli,IdUs);
    while(indice==-1)
    {
        printf("\nPublicacion Inexistente\n");
        printf("\n Reingrese el Codigo de publicacion que desea eliminar: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxP);
        isNumber(auxP);
        aux=atoi(auxP);
        indice=buscarPorUsuario(dato,tamP,aux,IdUs);
        system("pause");
        system("cls");

    }
    mostrarProducto(dato[indice]);
    printf("\nDesea eliminar este preducto?(s/n)\n");
    setbuf(stdin,NULL);
    confirm=getch();
    while(confirm!='s'&&confirm!='n')
    {
        printf("ERROR\n");
        printf("Desea eliminar esta publicacion? [s/n]");
        setbuf(stdin,NULL);
        confirm=getch();
    }
    if(confirm=='s')
    {
        dato[indice].estado=0;
        printf("\n Se ha eliminado la publicacion Exitosamente\n");
    }
    else
    {
        printf("Accion cancelada por el Usuario");
    }


}
//********************************************************************************
void PrecioMasAlto(eProducto dato[],int tam)
{
    int i;
    int masAlto=0;
    int indice=0;

    for(i=0;i<tam;i++)
    {
       if(dato[i].precio>masAlto)
       {
           masAlto=dato[i].precio;
           indice=i;
       }
    }
    printf("EL producto mas caro es:\n");
    mostrarProducto(dato[indice]);
}
//*******************************************************************************
int menu(char auxOP[])
{
    int opcion;
        printf("1. Alta Usuario\n");
        printf("2. Modificar datos del usuario\n");
        printf("3. Baja de Usuario\n");
        printf("4. Publicar producto\n");
        printf("5.Modificar Publicacion\n");
        printf("6.Cancelar publicacion\n");
        printf("7.Comprar Producto\n");
        printf("8.Listar Publicaciones de Usuarios\n");
        printf("9.Listar Publicaciones\n");
        printf("10.Listar Usuarios\n");
        printf("11.Salir\n");
        printf("Ingrese una opcion: \n");
        setbuf(stdin,NULL);
        scanf("%s",auxOP);
        isNumber(auxOP);
        opcion=atoi(auxOP);
        return opcion;

}



