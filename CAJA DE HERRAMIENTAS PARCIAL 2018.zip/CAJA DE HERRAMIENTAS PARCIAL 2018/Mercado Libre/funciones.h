
typedef struct
{
    char nombre[50];
    int edad;
    int calificacion;
    int idUsuario;
    char documento[20];
    char direccion[50];
    int estado;
    float promedio;

}eUsuario;
typedef struct
{
    int idUsuario;
    int idProducto;
    char nombre[50];
    float precio;
    int stock;
    int sVendida;
    int estado;
}eProducto;

void AltaUsuario(eUsuario dato[],int tam);
void inicializarUS(eUsuario dato[],int tam);
void inicializarESTP(eProducto dato[],int tam);
void inicializarVentas(eProducto dato[],int tam);
int EspacioLibre(eUsuario dato[],int tam);
void listarUsuarioCali(eUsuario dato[],eProducto estruct[],int tamU,int tamP);
int buscarUsuario(eUsuario dato[],char DNI[],int tam);
void IDusuario(eUsuario dato[],int tam);
int verifNumero(char cad[]);
void mostrarUsuario(eUsuario dato);
void mostrarUSUARIOS(eUsuario dato[],int tam);
void mostrarProducto(eProducto dato);
void mostrarPRODUCTOS(eProducto dato[],int tam);
void HardCode(eProducto dato[]);
int BuscarUSID(eUsuario dato[],int tam,int aux);
void publcacionesUsuarios(eUsuario dato[],eProducto estruc[],int tamU,int tamP,int id);
void modificarUsuario(eUsuario dato[],int tam);
void Baja(eUsuario dato[],eProducto estruc[],int tamU,int tamP);
int buscarProducto(eProducto dato[],int tam,int aux);
void comprar(eProducto dato[],eUsuario estruct[],int tamU,int tamP);
int buscarProIDU(eProducto dato[],int tam,int aux);
void PrecioMasAlto(eProducto dato[],int tam);
void BajaPublicacion(eUsuario estruc[],eProducto dato[],int tamU,int tamP);
void modificarPublicacion(eProducto dato[],eUsuario estruc[],int tamP,int tamU);
void AltaProducto(eProducto dato[],int tamPro,eUsuario estruct[],int tamU);
int EspacioLibreProducto(eProducto dato[],int tam);
int buscarPorUsuario(eProducto dato[],int tam,int aux,int id);
int numIDusuario(char cad[],eUsuario dato[],int tamU);
void HarcodeUsuarios(eUsuario dato[]);
void isAlphaNumber(char aux []);
int VefAphaandNumber(char aux[]);
void isFloat(char aux[]);
void isNumber(char aux[]);
void isWord(char aux[]);
void validarDNI(char aux[],eUsuario dato[],int tam);
int EsLetra(char letras[]);
int verifFloat(char cad[]);
void IDProducto(eProducto dato[],int tam);



