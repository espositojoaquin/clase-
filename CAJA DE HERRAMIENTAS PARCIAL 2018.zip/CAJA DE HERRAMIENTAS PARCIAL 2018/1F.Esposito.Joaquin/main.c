#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "funciones.h"
#define TAM 100
#define TAM2 1000

int main()
{
     int opcion,idUs;
    char respuesta='s';
    char auxOP[30];

   /* eUsuario Usuario[TAM];
    eProducto producto [TAM2];*/

    do
    {

        opcion=menu(auxOP);
        switch(opcion)
        {
        case 1:

            system("pause");
            system("cls");
            break;
        case 2:

             system("pause");
            system("cls");

            break;
        case 3:

            system("pause");
            system("cls");
            break;
        case 4:

            system("pause");
            system("cls");
            break;
        case 5:
            system("pause");
            system("cls");
            break;
        case 6:
            system("pause");
            system("cls");
            break;
        case 7:
            system("pause");
            system("cls");
             break;
        case 8:
            system("pause");
            system("cls");
             break;
        case 9:
            system("pause");
            system("cls");
             break;
        case 10:
            system("pause");
            system("cls");
             break;
        case 11:
            respuesta='n';
            break;
        default:
            printf("Ingrese una opcion entre 1-11\n");

            break;
        }


    }
    while(respuesta=='s');
    return 0;
}
    return 0;
}
