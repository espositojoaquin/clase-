#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "funciones.h"
#define TAM 100
#define TAM2 1000

void inicializarESTP(eProducto dato[],int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        dato[i].estado=0;


    }

}
//**********************************************************************************
int EspacioLibre2(eUsuario dato[],int tam)
{
    int i;
    int retorno;
    for(i=0; i<tam; i++)
    {
        if(dato[i].estado==0)
        {
            retorno=i;
            break;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;
}
//*******************************************************************************************************
void ID2(eProducto dato[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {

        dato[i].idProducto=i+100;


    }
}
//*******************************************************************************************************
void mostrarP(eProducto dato)
{
    if(dato.estado==1)
    {
        printf("Nombre:%s\n id Vendedor:%d \n id Producto:%d\n stock:%d\n Precio:%.2f\n Vendidos: %d\n\n ",dato.,dato.,dato.,dato.,dato.,dato.);
    }

}
//*******************************************************************************************************
void mostrarPS(eProducto dato[],int tam)
{
    int i,flag=0;
    for(i=0; i<tam; i++)
    {
        if(dato[i].estado==1)
        {
            flag=1;

            mostrarP(dato[i]);
        }

    }
    if(flag==0)
    {
        printf("No hay Productos ingresados\n");
    }
}
//***********************************************************************
int buscarProducto(eProducto dato[],int tam,int aux)
{
    int i;
    int retorno;

    for(i=0; i<tam; i++)
    {
        if(aux==dato[i].idProducto)
        {
            retorno=i;
            break;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;

}
//*******************************************************************
// buscar producto por id del usuario
int buscarProIDU(eProducto dato[],int tam,int aux)
{
    int i;
    int retorno;

    for(i=0; i<tam; i++)
    {
        if(aux==dato[i].idUsuario)
        {
            retorno=i;
            break;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;

}
//****************************************************************
void AltaProducto(eProducto dato[],int tamPro,eUsuario estruct[],int tamU)
{
    int indice;
    int auxID;
    char aux[50];
    char auxStock[30];
    indice=EspacioLibreProducto(dato,tamPro);
    if(indice==-1)
    {
        printf("NO HAY MAS ESPACIO DISPONIBLE\n");
    }
    else
    {
        printf("Por favor ingrese su Codigo de Usuario: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        isNumber(aux);
        auxID=atoi(aux);
        while(BuscarUSID(estruct,tamU,auxID)==-1)
        {
            printf("\nUsuario inexsitente\n");
            printf("\nPor favor reingresar Usuario: ");
            setbuf(stdin,NULL);
            scanf("%[^\n]",aux);
            isNumber(aux);
            auxID=atoi(aux);
            system("pause");
            system("cls");

        }

        dato[indice].idUsuario=auxID;

        printf("Igrese el nombre del producto: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",dato[indice].nombre);
        isWord(dato[indice].nombre);
        printf("Ingrese el Stock disponible : ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxStock);
        isNumber(auxStock);
        dato[indice].stock=atoi(auxStock);
        setbuf(stdin,NULL);
        printf("Por favor ingrese el Importe: ");
        scanf("%[^\n]",aux);
        isFloat(aux);
        dato[indice].precio=atof(aux);

        dato[indice].estado=1;
        printf("Publicacion registrada exitosamente\n");
        printf(" Su numero de publicacion es: %.4d\n",dato[indice].idProducto);

    }

}
//***************************************************************************************
void modificarPublicacion(eProducto dato[],eUsuario estruc[],int tamP,int tamU)
{
    int aux,indice,Publicaciones,auxId;
    float auxPrecio;
    char respuesta;
    char auxP[30];
    char confirm;
    aux=numIDusuario(auxP,estruc,tamU);
    publcacionesUsuarios(estruc,dato,tamU,tamP,aux);

    printf("\n Ingrese el Codigo de publicacion que desea modificar: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxP);
    isNumber(auxP);
    auxId=atoi(auxP);
    indice=buscarPorUsuario(dato,tamP,auxId,aux);
    while(indice==-1)
    {
        printf("\nPublicacion Inexistente\n");
        printf("\n Reingrese el Codigo de publicacion que desea modificar: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxP);
        isNumber(auxP);
        aux=atoi(auxP);
        indice=buscarProducto(dato,tamP,aux);


    }
    mostrarProducto(dato[indice]);
    printf("\nDesea modificar este preducto?(s/n)\n");
    setbuf(stdin,NULL);
    confirm=getch();
    while(confirm!='s'&&confirm!='n')
    {
        printf("ERROR\n");
        printf("Desea modificar el nombre de este usuario? [s/n]");
        setbuf(stdin,NULL);
        confirm=getch();
    }
    if(confirm=='s')
    {
        printf("\n Ingrese el nuevo precio: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxP);
        isFloat(auxP);
        auxPrecio=atof(auxP);
        dato[indice].precio=auxPrecio;
        printf("\n Ingrese el nuevo Stock: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxP);
        isNumber(auxP);
        aux=atoi(auxP);
        dato[indice].stock=aux;

        printf("\n Modificacion realizada con Exito\n");
    }
    else
    {
        printf("Accion cancelada por el Usuario");
    }


}
//************************************************************************************************************
void BajaPublicacion(eUsuario estruc[],eProducto dato[],int tamU,int tamP)
{
    int IdPubli,indice,Publicaciones,aux;
    int IdUs=0;
    float auxPrecio;
    char respuesta;
    char auxP[30];
    char confirm;
    IdUs=numIDusuario(auxP,estruc,tamU);
    publcacionesUsuarios(estruc,dato,tamU,tamP,IdUs);

    printf("\n Ingrese el Codigo de publicacion que desea eliminar: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxP);
    isNumber(auxP);
    IdPubli=atoi(auxP);
    indice=buscarPorUsuario(dato,tamP,IdPubli,IdUs);
    while(indice==-1)
    {
        printf("\nPublicacion Inexistente\n");
        printf("\n Reingrese el Codigo de publicacion que desea eliminar: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",auxP);
        isNumber(auxP);
        aux=atoi(auxP);
        indice=buscarPorUsuario(dato,tamP,aux,IdUs);
        system("pause");
        system("cls");

    }
    mostrarProducto(dato[indice]);
    printf("\nDesea eliminar este preducto?(s/n)\n");
    setbuf(stdin,NULL);
    confirm=getch();
    while(confirm!='s'&&confirm!='n')
    {
        printf("ERROR\n");
        printf("Desea eliminar esta publicacion? [s/n]");
        setbuf(stdin,NULL);
        confirm=getch();
    }
    if(confirm=='s')
    {
        dato[indice].estado=0;
        printf("\n Se ha eliminado la publicacion Exitosamente\n");
    }
    else
    {
        printf("Accion cancelada por el Usuario");
    }


}
//********************************************************************************
