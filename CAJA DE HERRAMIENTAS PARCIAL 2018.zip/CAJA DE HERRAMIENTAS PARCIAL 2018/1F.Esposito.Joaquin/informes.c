#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "funciones.h"
#define TAM 100
#define TAM2 1000

int menu(char auxOP[])
{
    int opcion;
        printf("1. \n");
        printf("2. \n");
        printf("3. \n");
        printf("4. \n");
        printf("5. \n");
        printf("6. \n");
        printf("7. \n");
        printf("8. \n");
        printf("9. \n");
        printf("10.\n");
        printf("11.Salir\n");
        printf("Ingrese una opcion: \n");
        setbuf(stdin,NULL);
        scanf("%s",auxOP);
        isNumber(auxOP);
        opcion=atoi(auxOP);
        return opcion;

}
//*********************************************************************************************
int verifNumero(char cad[])
{
    int tam;
    int i;
    int retorno;
    tam= strlen(cad);
    for(i=0; i<tam; i++)
    {
        if(cad[i]>'9'||cad[i]<'0')
        {
            retorno=0;
            break;
        }
        else
        {
            retorno=1;
        }
    }
    return retorno;
}
//******************************************************************************************************
void isNumber(char aux[])
{
    while(verifNumero(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");


    }
}
//******************************************************************************************************
int verifFloat(char cad[])
{
    int tam;
    int i;
    int cont=0;
    int retorno;
    tam= strlen(cad);
    for(i=0; i<tam; i++)
    {
        if(cad[i]=='.')
        {
            cont++;
        }
        if(cad[i]>'9'&&cad[i]!='.'||cad[i]<'0'&&cad[i]!='.')
        {
            retorno=0;
            break;
        }
        else
        {
            if(cont>1)
            {
                retorno=0;
            }
            else
            {
                retorno=1;
            }

        }
    }
    return retorno;
}
//*******************************************************************************************
void isFloat(char aux[])
{
    while(verifFloat(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");


    }
}
//*******************************************************************************************
int EsLetra(char letras[])
{
    int i,retorno;
    int tam=strlen(letras);
    strlwr(letras);

    for(i=0; i<tam; i++)
    {
        if(letras[i]<'a'&&letras[i]!=' '||letras[i]>'z'&&letras[i]!=' ')
        {
            retorno=0;
            break;
        }
        else
        {

            retorno=1;
            letras[0]=toupper(letras[0]);

        }
    }
    return retorno;
}
//*******************************************************************************
void isWord(char aux[])
{
    while(EsLetra(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");

    }
}
//*******************************************************************************
int VefAphaandNumber(char aux[])
{
    int retorno;
    int i;
    int tam=strlen(aux);
    for(i=0; i<tam; i++)
    {
        if(aux[i]>' '&&aux[i]<'/'||aux[i]>'9'&&aux[i]<'`'||aux[i]>'z')
        {
            retorno=0;
        }
        else
        {
            retorno=1;
        }

    }

    return retorno;
}
//***************************************************************************
void isAlphaNumber(char aux [])
{
    while(VefAphaandNumber(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");

    }
}
//***************************************************************************
void validarDNI(char aux[],eUsuario dato[],int tam)
{
    while(verifNumero(aux)==0)
    {
        system("pause");
        system("cls");
        printf("Ingrese un DNI Valido: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");


    }
    while(strlen(aux)<7||strlen(aux)>8)
    {
        system("pause");
        system("cls");
        printf("Ingrese un DNI Valido: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");

    }
    while(buscarUsuario(dato,aux,tam)==1)
    {
        system("pause");
        system("cls");
        printf("Este Usuario ya ha cido registrado");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");

    }


}
//*******************************************************************
void HardCode(eProducto dato[])
{

    int idUsuario[12]= {1,2,1,4,3,4,7,1,3,10};
    int idProducto[12]= {100,101,102,103,104,105,106,107,108,109};
    char nombre[12][50]= {"Enduido INT","Latex INT","Sintetico","Barniz INT","Barniz Marino","Laca poliuretanica","Lijas","Aguarras","Thiner","Latex EXT"};
    float precio[12]= {856,1800,240,190,200,350,23,96,120,2000};
    int stock[12]= {8,4,5,7,6,100,4,78,23,9};
    int estado;
    int i;
   // printf("\t\PRODUCTOS\n");

    for(i=0; i<10; i++)
    {
        strcpy(dato[i].nombre,nombre[i]);
        dato[i].idUsuario=idUsuario[i];
        dato[i].idProducto=idProducto[i];
        dato[i].precio=precio[i];
        dato[i].stock=stock[i];
        dato[i].estado=1;

    }
    // mostrarPRODUCTOS(dato,10);

}
//***************************************************************************************
  void HarcodeUsuarios(eUsuario dato[])
  {
    int edad[10]= {19,27,20,21,22,40,47,50,17,65};//33,37,15,26,28,29,25,23,36,45};
    char nombre[10][50]= {"Juan","Maria","Pedro","Julian","Martina","Julio","Kevin","Joaquin","Leonel","Brenda"};//,"Aldana","Luz","Agustin","Angel","Brian","Gladys","Ruben","Luis","Claudia","Vanina"};
    char dni[20][20]= {"40929964","40929954","40929966","40929969","47929964","40929914","40929963","48929964","41929964","42929964"};//,"43929964","44929964","45929964","46929964","40129964","40229964","41329964","40929644","40926984","40929147"};
    char Direccion[10][50]={"P.Javier 588","Ascasubi 456","Esperanza 452","Libertad 789","N.Pe�a 987","Jacarada 666","P.Buena 365","Boulevard 1919","Av Mitre 750","U.Gonzales 458 "};
    int estado;
    int i;
    for(i=0;i<10;i++)
    {
        dato[i].edad=edad[i];
        strcpy(dato[i].nombre,nombre[i]);
        strcpy(dato[i].documento,dni[i]);
        strcpy(dato[i].direccion,Direccion[i]);
        dato[i].estado=1;
    }
  }

//***************************************************************************************
int numIDusuario(char cad[],eUsuario dato[],int tamU)
{
    int aux,indice;
    printf("Ingrese su numero de Usuario: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",cad);
    isNumber(cad);
    aux=atoi(cad);
    indice=BuscarUSID(dato,tamU,aux);
    while(indice==-1)
    {
        printf("Numero de Usuario inexistente\n");
        printf("Reingrese su numero de Usuario: ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",cad);
        isNumber(cad);
        aux=atoi(cad);
        indice=BuscarUSID(dato,tamU,aux);
        system("pause");
        system("cls");
    }
    return aux;
}
//*************************************************************************************
// Recibe el numero de usuario verifica que exista y muestra los datos que esten relacionados a ese usuario
void publcacionesUsuarios(eUsuario dato[],eProducto estruc[],int tamU,int tamP,int idUs)
{
    int indice,i;


    indice=BuscarUSID(dato,tamU,idUs);


    for(i=0; i<tamP; i++)
    {
        if(estruc[i].idUsuario==dato[indice].idUsuario)
        {
            if(dato[indice].estado==1)
            {
                mostrarProducto(estruc[i]);

            }
        }
    }

}
//****************************************************************************
void comprar(eProducto dato[],eUsuario estruct[],int tamU,int tamP)
{
    int aux,indice,indice2;
    int auxU;
    char auxC[30];
    char confirm;
    mostrarPS(dato,tamP);
    printf("Ingrese el codigo del Producto que deseas comprar: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxC);
    isNumber(auxC);
    aux=atoi(auxC);
    indice=buscarProducto(dato,tamU,aux);

    if(indice!=-1)
    {
        mostrarProducto(dato[indice]);
        printf("Desea Comprar este producto? [s/n]");
        setbuf(stdin,NULL);
        confirm=getch();
        while(confirm!='s'&&confirm!='n')
        {
            printf("ERROR\n");
            printf("Desea Comprar este producto? [s/n]");
            setbuf(stdin,NULL);
            confirm=getch();
        }
        if(confirm=='s')
        {
            dato[indice].sVendida=dato[indice].sVendida+1;
            dato[indice].stock= dato[indice].stock-1;
            indice2=BuscarUSID(estruct,tamU,dato[indice].idUsuario);
            printf("\n La compra se ha realizado con Exito\n");
            if(indice2!=-1)
            {
                printf("\nPor favor ingrese una calificacion al Vendedor(1-10): ");
                setbuf(stdin,NULL);
                scanf("%[^\n]",auxC);
                isNumber(auxC);
                auxU=atoi(auxC);
                estruct[indice2].calificacion=estruct[indice2].calificacion+auxU;
                printf("\nGracais por su Calificacion\n");
            }


        }
        else
        {
            printf("Accion cancelada por el Usuario");
        }
    }

}
//**********************************************************************************
void PrecioMasAlto(eProducto dato[],int tam)
{
    int i;
    int masAlto=0;
    int indice=0;

    for(i=0;i<tam;i++)
    {
       if(dato[i].precio>masAlto)
       {
           masAlto=dato[i].precio;
           indice=i;
       }
    }
    printf("EL producto mas caro es:\n");
    mostrarProducto(dato[indice]);
}
