#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "funciones.h"
#define TAM 100
#define TAM2 1000

void inicializarEstado(eUsuario dato[],int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        dato[i].estado=0;


    }

}
//************************************************************************
int EspacioLibre(eUsuario dato[],int tam)
{
    int i;
    int retorno;
    for(i=0; i<tam; i++)
    {
        if(dato[i].estado==0)
        {
            retorno=i;
            break;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;
}
//**************************************************************************
int buscarPorDNI(eUsuario dato[],char DNI[],int tam)
{
    int i;
    int retorno;

    for(i=0; i<tam; i++)
    {
        if(strcmpi(DNI,dato[i].documento)==0)
        {
            retorno=1;
            break;
        }
        else
        {
            retorno=0;
        }
    }
    return retorno;
}
//****************************************************************************
int BuscarUSID(eUsuario dato[],int tam,int aux)
{
    int i,flag=0;
    int retorno;

    for(i=0; i<tam; i++)
    {

        if(aux==dato[i].idUsuario)
        {
            if(dato[i].estado==1)
            {
                retorno=i;
                flag=1;
                break;

            }

        }
        if(flag==0)
        {
            retorno=-1;
        }
    }
    return retorno;
}
//****************************************************************************
void ID1(eUsuario dato[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {

         dato[i].idUsuario=i+1;

    }
}
//****************************************************************************
void AltaU(eUsuario dato[],int tam)
{
    int indice,i;
    char aux[50];
    char auxEdad[30];
    indice=EspacioLibre(dato,tam);
    if(indice==-1)
    {
        printf("NO HAY MAS ESPACIO DISPONIBLE\n");
    }
    else
    {
        printf(": ");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
       // validarDNI(aux,dato,tam);
        if(buscarUsuario(dato,aux,tam)==0)
        {
            strcpy(dato[indice].documento,aux);
            printf(": ");
            setbuf(stdin,NULL);
            scanf("%[^\n]",dato[indice].nombre);

            printf(": ");
            setbuf(stdin,NULL);
            scanf("%[^\n]",auxEdad);

            setbuf(stdin,NULL);
            printf(": ");
            scanf("%[^\n]",dato[indice].direccion);

            dato[indice].estado=1;
            printf("Usuario registrado exitosamente\n");
            printf("Su numero de Usuario es: %.4d\n",dato[indice].idUsuario);

        }



    }

}
//********************************************************************************************
void mostrarU(eUsuario dato)
{
    printf("|%-10s\t\t%-10d\t\t%-15s\t%-10s\t\t\t%-15.2f|\n",dato.,dato.,dato.,dato.,dato.);
}
//*******************************************************************
void mostrarUS(eUsuario dato[],int tam)
{
    int i,flag=0;
    for(i=0; i<tam; i++)
    {
        if(dato[i].estado==1)
        {
            flag=1;
            if(i==0)
            {
                printf("|=======================================================================================================|\n");
                printf("|                                       USUARIOS                                                        |\n");
                printf("|=======================================================================================================|\n");
                printf("|        |                 |             |             |          |\n");
                printf("|=======================================================================================================|\n");
            }

            mostrarU(dato[i]);
        }

    }
    if(flag==0)
    {
        printf("No hay Usuarios ingresados\n");
    }
}
//****************************************************************************************
void modificarUsuario(eUsuario dato[],int tam)
{
    int aux,indice,opcion;
    char respuesta='s';
    char auxOP[30];
    char confirm;
    printf("Ingres su numero de usuario: ");
    scanf("%d",&aux);
    indice=BuscarUSID(dato,tam,aux);
    if(indice!=-1)
    {
        do
        {
            printf("1-Modificar \n");
            printf("2-Modificar \n");
            printf("3-Modificar \n");
            printf("4-Modificar \n");
            printf("5-Salir\n");
            printf("Ingrese una opcion: ");
            setbuf(stdin,NULL);
            scanf("%s",auxOP);
            if(verifNumero(auxOP)==1)
            {
                opcion=atoi(auxOP);
            }
            switch(opcion)
            {
            case 1:
                printf("Nombre: %s\n",dato[indice].nombre);
                printf("Desea modificar el nombre de este usuario? [s/n]");
                setbuf(stdin,NULL);
                confirm=getch();
                while(confirm!='s'&&confirm!='n')
                {
                    printf("ERROR\n");
                    printf("Desea modificar el nombre de este usuario? [s/n]");
                    setbuf(stdin,NULL);
                    confirm=getch();
                }
                if(confirm=='s')
                {
                    printf("\n Ingrese su nombre: ");
                    setbuf(stdin,NULL);
                    scanf("%[^\n]",dato[indice].nombre);
                    isWord(dato[indice].nombre);
                    printf("\n Modificacion realizada con Exito\n");
                }
                else
                {
                    printf("Accion cancelada por el Usuario");
                }

                break;
            case 2:
                printf("Edad: %d\n",dato[indice].edad);
                printf("Desea modificar la edad de este usuario? [s/n] ");
                setbuf(stdin,NULL);
                confirm=getch();
                while(confirm!='s'&&confirm!='n')
                {
                    printf("ERROR\n");
                    printf("Desea modificar la edad de este usuario? [s/n] ");
                    setbuf(stdin,NULL);
                    confirm=getch();
                }
                if(confirm=='s')
                {
                    printf("\nIngrese su edad: ");
                    setbuf(stdin,NULL);
                    scanf("%[^\n]",auxOP);
                    isNumber(auxOP);
                    aux=atoi(auxOP);
                    dato[indice].edad=aux;
                    printf("\n Modificacion realizada con Exito\n");
                }
                else
                {
                    printf("Accion cancelada por el Usuario");
                }
                break;
            case 3:
                printf("DNI: %s\n",dato[indice].documento);
                printf("Desea modificar el DNI de este usuario? [s/n]");
                setbuf(stdin,NULL);
                confirm=getch();
                while(confirm!='s'&&confirm!='n')
                {
                    printf("ERROR\n");
                    printf("Desea modificar el DNI de este usuario? [s/n]");
                    setbuf(stdin,NULL);

                    confirm=getch();
                }
                if(confirm=='s')
                {
                    printf("\nIngrese su DNI: ");
                    setbuf(stdin,NULL);
                    scanf("%[^\n]",dato[indice].documento);
                    isNumber(dato[indice].documento);
                    printf("\n Modificacion realizada con Exito\n");
                }
                else
                {
                    printf("Accion cancelada por el Usuario");
                }
                break;
            case 4:
                printf("Direccion: %s\n",dato[indice].direccion);
                printf("Desea modificar la direccion de este usuario? [s/n]");
                setbuf(stdin,NULL);
                confirm=getch();
                while(confirm!='s'&&confirm!='n')
                {
                    printf("ERROR\n");
                    printf("Desea modificar la direccion de este usuario? [s/n]");
                    setbuf(stdin,NULL);
                    confirm=getch();
                }
                if(confirm=='s')
                {
                    printf("\nIngrese su direccion: ");
                    setbuf(stdin,NULL);
                    scanf("%[^\n]",dato[indice].direccion);
                    isAlphaNumber(dato[indice].direccion);
                    printf("\n Modificacion realizada con Exito\n");
                }
                else
                {
                    printf("Accion cancelada por el Usuario");
                }
                break;
            case 5:
                respuesta='n';
                break;
            default:
                printf("Ingrese una opcion entre 1-5\n");

                break;
            }


        }
        while(respuesta=='s');
    }
    else
    {
        printf("Usuario inexistente\n");
    }

}
//***********************************************************
void Baja(eUsuario dato[],eProducto estruc[],int tamU,int tamP)
{
    int aux,i,indice;
    char confirm;
    char auxE[30];


    printf("Ingres su numero de usuario: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxE);
    isNumber(aux);
    aux=atoi(auxE);
    indice=BuscarUSID(dato,tamU,aux);
    if(indice!=-1)
    {
        mostrarUsuario(dato[indice]);
        printf("Desea elimar este Usuario y todas sus Publicaciones? [s/n]");
        setbuf(stdin,NULL);
        confirm=getch();
        while(confirm!='s'&&confirm!='n')
        {
            printf("ERROR\n");
            printf("Desea elimar este Usuario y todas sus Publicaciones? [s/n]");
            setbuf(stdin,NULL);
            confirm=getch();
        }
        if(confirm=='s')
        {
            dato[indice].estado=0;
            for(i=0; i<tamP; i++)
            {
                if(estruc[i].idUsuario==dato[indice].idUsuario)
                {
                    estruc[i].estado=0;
                }
            }

            printf("\n Usuario Eliminado con Exito\n");
        }
        else
        {
            printf("Accion cancelada por el Usuario");
        }

    }
}
//********************************************************************************************
// Sirve para que solo busque las publicacione de dicho usuario y las otras las descarte como inexistentes
int buscarPorUsuario(eProducto dato[],int tam,int aux,int id)
{
    int i;
    int retorno;

    for(i=0; i<tam; i++)
    {
        if(aux==dato[i].idProducto&&id==dato[i].idUsuario)
        {
            retorno=i;
            break;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;

}
//*************************************************************
void listarUsuarioCali(eUsuario dato[],eProducto estruct[],int tamU,int tamP)
{
    int i,indice,indiceU,flag=0;
    float resultado;

    for(i=0; i<tamU; i++)
    {
        if(dato[i].estado==1)
        {
            indice=buscarProIDU(estruct,tamP,dato[i].idUsuario);

            if(indice!=-1)
            {


                indiceU=i;
                if(dato[indiceU].calificacion>0&&estruct[indice].sVendida>0)
                {
                    dato[indiceU].promedio=dato[indiceU].calificacion/(float)estruct[indice].sVendida;
                }
                else
                {
                     dato[indiceU].promedio=0;
                }




            }
        }



    }
      mostrarUS(dato,tamU);
}
//*****************************************************************************
