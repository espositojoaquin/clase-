typedef struct
{
    int id;
    char nombre[50];
    char DNI[30];

}e;
typedef struct
{

}e;
