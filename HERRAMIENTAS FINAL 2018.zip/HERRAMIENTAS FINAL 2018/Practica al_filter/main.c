#include <stdio.h>
#include <stdlib.h>
#include "arraylist.h"
#include "funciones.h"
#include "inputs.h"


int main()
{
    char seguir='s';
    int opcion=0;
    char respuesta[20];
    int Arch;
    int aux;
    int i;
    char auxOP[10];
    eEmpleado* auxEmpleados;
    ArrayList* lista;
    ArrayList* listaDep;

    listaDep=al_newArrayList();
    lista = al_newArrayList();

    system("color 4F");


    FILE* archivo;

    while(seguir=='s')
    {
        opcion=menu(auxOP);

        switch(opcion)
        {
        case 1:
            cargar(lista,archivo);
            employeePrint(lista);

            system("pause");
            system("cls");

            break;
        case 2:


            listaDep=al_filter(lista,funcionQueFiltra);

            employeePrint(listaDep);

            system("pause");
            system("cls");

            break;
        case 3:
            generarArchivo(listaDep);

            system("pause");
            system("cls");


            break;

        case 4:
            seguir = 'n';

            system("pause");
            system("cls");
            break;

        default:
            system("pause");
            system("cls");
            printf("Ingrese una opcion entre 1-4\n");

        }


    }
    return 0;

}

