
typedef struct{

    char nombre[20];
    int edad;
    char prof[30];
}eEmpleado;

/** \brief  Setea el nombre
 * \param puntero a variable empleado
 * \param  el nombre ingresado
 * \return nombre seteado
 *
 */
int employee_setName(eEmpleado* Emp, char nombre[]);

/** \brief  Setea el id
 * \param puntero a variable empleado
 * \param  el id ingresado
 * \return id seteado
 *
 */
int employee_setID(eEmpleado* Emp, int id);

/** \brief  Setea la hora
 * \param puntero a variable empleado
 * \param  las horas ingresadas
 * \return Horas seteado
 *
 */
int employee_setHora(eEmpleado* Emp, int HS);

/** \brief  Setea el Sueldo
 * \param puntero a variable empleado
 * \param  el sueldo ingresado
 * \return sueldo seteado
 *
 */
int employee_setSueldo(eEmpleado* Emp, float salario);

/** \brief  Genera lugar para un elemnto del tipo empleado
 * \return NULL en caso de no poder conseguir espacio, de lo contrario el espacio para el dato
 */
eEmpleado* newEmp();

/** \brief Setea los campos del dato empleado
 * \param  nombre ingresado
 * \param  id ingresado
 * \param  hora ingresada
 * \return nombre seteado
 *
 */
eEmpleado* newPersonParametros( char nombre[],int id, int hora);

/** \brief Lee y carga los datos de un Archivo
 * \param  puntero a File
 * \param  ArrayList
 * \param  nombre del archivo
 * \return 0 si no pudo cargar el archivo, 1 si lo pudo cargar correctamente
 *
 */

int parserEmployee( FILE* Archivo,ArrayList* lista,char nombreArch[]);

/** \brief imprime por pantalla un dato del tipo empleado
 * \param  dato empleado
 * \return la impresion del empleado
 *
 */
void employee_print(eEmpleado* Emp);

/** \brief imprime Todos los empleados que se encuentren en al Arraylist
 * \param  ArrayList donde se encuentran los datos
 * \return Lista de empleados
 *
 */
void employeePrint(ArrayList* lista);

/** \brief se encarga de leer y cargar los datos a Memoria
 * \param  ArrayList
 * \param  Archivo
 * \return datos en memoria
 *
 */
void cargar(ArrayList* lista, FILE* archivo);

/** \brief Genera un archivo.csv
 * \param  Array list
 * \return un mensaje de alerta de si se pudo o no generar el archivo
 *
 */
void generarArchivo(ArrayList* lista);

/** \brief Clacula los sueldos
 * \param  elemento
 * \return campo sueldo del elemento calculado
 *
 */

void em_calcularSueldo(void* p);
int funcionQueFiltra(void* p);
