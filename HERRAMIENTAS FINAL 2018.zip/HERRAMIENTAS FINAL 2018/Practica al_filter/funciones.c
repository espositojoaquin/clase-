#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <conio.h>

#include "arraylist.h"
#include "funciones.h"
#include "inputs.h"


/*void em_calcularSueldo(void* p)
{
    if(((eEmpleado*)p)!=NULL)
    {
        if(((eEmpleado*)p)->horasTrab<=176)
        {
            ((eEmpleado*)p)->sueldo = ((eEmpleado*)p)->horasTrab * 180;
        }
        if(((eEmpleado*)p)->horasTrab>176 && ((eE  strcpy(Emp->nombre,nombre);mpleado*)p)->horasTrab<=208)
        {
            ((eEmpleado*)p)->sueldo = ((eEmpleado*)p)->horasTrab * 270;
        }
        if(((eEmpleado*)p)->horasTrab>208 && ((eEmpleado*)p)->horasTrab<=240)
        {
            ((eEmpleado*)p)->sueldo = ((eEmpleado*)p)->horasTrab * 360;
        }
    }
}*/
//**************************************************************************
int funcionQueFiltra(void* p)
{
    int retorno=0;
    if(((eEmpleado*)p)!=NULL)
    {
      if(((eEmpleado*)p)->edad>30)
      {
          if(strcmpi(((eEmpleado*)p)->prof,"Programador")==0)
          {
            retorno=1;

          }
      }


   }
   return retorno;

}
/*int funcionQueFiltra(void* empleado)
{
    int retorno;
    if(((eEmpleado*)empleado)->edad>30)
    {
        if(strcmpi(((eEmpleado*)empleado)->prof,"Programador")==0)
        {
           retorno=1;
        }
        else
        {
            retorno=0;
        }
    }
    else
    {
        retorno=0;
    }
    return retorno;
}*/
//**************************************************************************
int employee_setName(eEmpleado* Emp, char nombre[])
{
    strcpy(Emp->nombre,nombre);
    return 0;

}
//***************************************************************************
int employee_setedad(eEmpleado* Emp, int edad)
{

    Emp->edad=edad;
    return 0;

}
//*****************************************************************************
int employee_setProf(eEmpleado* Emp, int prof)
{

    strcpy(Emp->prof,prof);
    return 0;


}
//******************************************************************************

//******************************************************************************
eEmpleado* newEmp()
{
    eEmpleado* aux;
    aux = (eEmpleado*) malloc (sizeof(eEmpleado));
    return aux;
}
//******************************************************************************
eEmpleado* newPersonParametro( char nombre[],int edad, char prof[])
{
    eEmpleado* Emp;

    Emp = newEmp();
    if(Emp!=NULL)
    {
        strcpy(Emp->nombre,nombre);
        Emp->edad=edad;
        strcpy(Emp->prof,prof);

    }

    return Emp;
}

//******************************************************************************
int parserEmployee(FILE* Archivo,ArrayList* lista,char nombreArch[])
{
    char  fitrs_name[50], edad[10],Profesion[50];
    eEmpleado* emp;
    int retorno;

    Archivo=fopen(nombreArch,"r");
    if(Archivo==NULL||lista==NULL)
    {
        retorno=0;
    }
    else
    {

        fscanf(Archivo, "%[^,],%[^,],%[^\n]\n",fitrs_name,edad,Profesion);

        while(!feof(Archivo))
        {
            fscanf(Archivo, "%[^,],%[^,],%[^\n]\n",fitrs_name,edad,Profesion);
            emp=newPersonParametro(fitrs_name,edad,Profesion);
            if(emp!=NULL)
            {

                employee_setName(emp,fitrs_name);
                employee_setedad(emp,atoi(edad));
                employee_setProf(emp,Profesion);


                lista->add(lista,emp);
                if(feof(Archivo))
                {
                    break;
                }


            }

        }

        retorno=1;
    }


    fclose(Archivo);

    return retorno;

}
//*******************************************************************************
void employee_print(eEmpleado* Emp)
{
    printf("|%-5s\t\t%-15d\t\t%-15s|\n",Emp->nombre,Emp->edad,Emp->prof);
}
//*******************************************************************************
void employeePrint(ArrayList* lista)
{
    eEmpleado* Emp;
    if(lista->isEmpty(lista)==0)
    {
        int i;
        printf("|===============================================================================|\n");
        printf("|                               EMPLEADOS                                       |\n");
        printf("|===============================================================================|\n");
        printf("|     NOMBRES        |        EDAD       |            PROFESION        \n");
        printf("|===============================================================================|\n");
        for(i=0; i<lista->len(lista); i++)
        {
            if(i>0)
            {
                if(i%50==0)
                {
                    system("pause");
                }
            }
            Emp = al_get(lista,i);
            employee_print(Emp);
        }
    }
    else
    {
        printf("\nNo hay registro de empleados\n");
    }



}
//**********************************************************************
void cargar(ArrayList* lista, FILE* archivo)
{
    int Arch;
    char respuesta[30];
    printf("\nIngrese el nombre del archivo: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",respuesta);
    Arch=parserEmployee(archivo,lista,respuesta);
    if(Arch==0)
    {
        printf("\n Error al abrir el archivo\n");
    }
    else
    {
        printf("\n Archivo cargado con exito\n");

    }

}
//********************************************************
void generarArchivo(ArrayList* lista )
{
    int i;
    eEmpleado* Emp;
    FILE* archivo;
    archivo = fopen("out.csv","w");

    if(archivo!=NULL)
    {
        if(lista->isEmpty(lista)==0)
        {
            for(i=0; i<al_len(lista); i++)
            {

                Emp = al_get(lista,i);

                fprintf(archivo,"%s,%d,%s\n",Emp->nombre,Emp->edad,Emp->prof);

            }
            printf("Archivo generado correctamente!\n");
        }
        else
        {
            printf("\nNo hay Registros de empleados para generar el archivo\n");
        }

    }
    else
    {
        printf("Ha ocurrido un error!\n");
    }
    fclose(archivo);

}
