#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Funciones.h"

int main()
{
    char seguir='s';
    int opcion=0;
    int Arch;
    ArrayList* lista;
    ArrayList* sublista;
    ArrayList* sublista2;
    sublista= al_newArrayList();
    sublista2= al_newArrayList();
    lista = al_newArrayList();
    int i;

    FILE* archivo;
     system("color 2E");
     printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\tEMPRESA\n\n\n\n\n\n\n\n\n\n");
     printf("Si quiere ingresar: ");
     system("pause");
     system("cls");
    system("color 4F");


    while(seguir=='s')
    {
        printf("1- Cargar lista de tareas\n");
        printf("2- ordenar\n");
        printf("3- Particionar por Prioridad\n");
        printf("4- Resolver tarea\n");
        printf("5- Generar archivos\n");
        printf("6- Salir\n");

        printf("\nIngrese una opcion: ");
        scanf("%d",&opcion);
        system("cls");

        switch(opcion)
        {
        case 1:
            Arch=LeerTareas(archivo,lista);
            if(Arch==0)
            {
                printf("\n Error al abrir el archivo\n");
            }
            else
            {
                printf("\n Archivo cargado con exito\n");

            }
            system("pause");
            system("cls");

            break;
        case 2:
            lista->sort(lista,comparaTarea,0);
            mostrarTareas(lista);
            system("pause");
            system("cls");

            break;
        case 3:
            particionar(lista,sublista,sublista2);


            break;
        case 4:
            if(lista->isEmpty(lista)==0)
            {
                 ResolverTarea(sublista,sublista2);
            }
            else
            {
                printf("\nNo hay tareas cargadas\n");
            }
            break;
        case 5:
            if(sublista->isEmpty(sublista)==0)
            {
                generarAlta(sublista);
            }
            else
            {
                printf("\nNo se han cargado elementos en la lista de tarea de mayor importancia, o estas ya fueron resueltas\n");

            }
            if(sublista2->isEmpty(sublista2)==0)
            {
                generarBaja(sublista2);
            }
            else
            {
                printf("\nNo se han cargado elementos en la lista de tarea de menor importancia, o estas ya fueron resueltas\n");

            }

            break;
        case 6:
            seguir = 'n';
            break;

        default:
        {
            printf("\nPor favor ingrese una opcion entre (1-6)\n");
        }



        }

    }

    return 0;
}
