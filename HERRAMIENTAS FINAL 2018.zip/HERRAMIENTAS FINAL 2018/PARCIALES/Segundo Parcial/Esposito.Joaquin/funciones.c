
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Funciones.h"

ETarea* newTarea()
{
    ETarea* aux;
    aux = (ETarea*) malloc (sizeof(ETarea));
    return aux;
}
ETarea* newTareaParametros(char nombre[],int importancia,int horas)
{
    ETarea* tarea;
    ArrayList* lista;

    tarea = newTarea();
    if(tarea!=NULL)
    {
        strcpy(tarea->Tarea,nombre);
        tarea->importancia=importancia;
        tarea->hora=horas;


    }

    return tarea;
}

int LeerTareas( FILE* Archivo,ArrayList* lista)
{
    char nombre[20], importancia[20],tiempo[20];
    ETarea* tarea;
    int retorno;
    Archivo=fopen("tar.csv","r");
    if(Archivo==NULL||lista==NULL)
    {
        retorno=0;
    }
    else
    {

        fscanf(Archivo, "%[^,],%[^,],%[^\n]\n",nombre,importancia,tiempo);

        while(!feof(Archivo))
        {
            fscanf(Archivo, "%[^,],%[^,],%[^\n]\n",nombre,importancia,tiempo);

            tarea=newTareaParametros(nombre,importancia,tiempo);
            if(tarea!=NULL)
            {

                tarea->importancia=atoi(importancia);
                strcpy(tarea->Tarea,nombre);
                tarea->hora=atoi(tiempo);

                al_add(lista,tarea);


            }

        }

        retorno=1;
    }


    fclose(Archivo);

    return retorno;


}
int comparaTarea(void* tarea,void* deber)
{

    if(((ETarea*)tarea)->hora > ((ETarea*)deber)->hora)
    {
        return 1;
    }
    if(((ETarea*)tarea)->hora < ((ETarea*)deber)->hora)
    {
        return -1;
    }
    return 0;
}
int comparaIMP(void* tarea,void* deber)
{

    if(((ETarea*)tarea)->importancia > ((ETarea*)deber)->importancia)
    {
        return 1;
    }
    if(((ETarea*)tarea)->importancia < ((ETarea*)deber)->importancia)
    {
        return -1;
    }
    return 0;
}
void mostrarTareas(ArrayList* lista)
{
    ETarea* tarea;
    if(lista->isEmpty(lista)==0)
    {
        int i;
        printf("|===============================================================================|\n");
        printf("|                              TABLA DE TAREAS                                  \n");
        printf("|===============================================================================|\n");
        printf("|    TAREA   |    IMPORTANCIA      |    TIEMPO     |              \n");
        printf("|===============================================================================|\n");
        for(i=0; i<lista->len(lista); i++)
        {
            tarea=(ETarea*)lista->get(lista,i);

            printf("|%-20s%-20d%-10d|\n",tarea->Tarea,tarea->importancia,tarea->hora);
            printf("|===============================================================================|\n");
        }
    }
    else
    {
        printf("\nNo hay Tareas ingresadas");
    }

}
void particionar(ArrayList* lista,ArrayList* sublista,ArrayList* sublista2)
{
    int i;
    ETarea* tarea;

    lista->sort(lista,comparaIMP,1);

    if(sublista!=NULL)
    {
        for(i=0; i<lista->len(lista); i++)
        {
            tarea=(ETarea*)lista->get(lista,i);
            if(tarea->importancia==1)
            {
                al_add(sublista,al_get(lista,i));
            }


        }

    }
    if(sublista2!=NULL)
    {
        for(i=0; i<lista->len(lista); i++)
        {
            tarea=(ETarea*)lista->get(lista,i);
            if(tarea->importancia==0)
            {
                al_add(sublista2,al_get(lista,i));
            }


        }

    }
    mostrarTareas(sublista);
    system("pause");
    system("cls");
    mostrarTareas(sublista2);
    system("pause");
    system("cls");

}
void ResolverTarea(ArrayList* sublista,ArrayList* sublista2)
{
    int i,auxi;
    ETarea* tarea;


     if(sublista->isEmpty(sublista)==0)
     {
           sublista->sort(sublista,comparaTarea,1);
           tarea=sublista->pop(sublista,0);
           printf("|%-5s\t\t%-10d\t\t %-15d|\n",tarea->Tarea,tarea->importancia,tarea->hora);
           system("pause");
           system("cls");

     }
     else
     {
         if(sublista2->isEmpty(sublista2)==0)
         {
             sublista2->sort(sublista2,comparaTarea,1);
           tarea=sublista2->pop(sublista2,0);
           printf("|%-5s\t\t%-10d\t\t %-15d|\n",tarea->Tarea,tarea->importancia,tarea->hora);
           system("pause");
           system("cls");

         }
         else
         {
            printf("\nSe han realizado todas las tareas\n");
            system("pause");
            system("cls");
         }

     }

}
void generarAlta(ArrayList* lista )
{
    int i;
    ETarea* tarea;
    FILE* archivo;
    archivo = fopen("pAlta.csv","w");

    if(archivo!=NULL)
    {
        for(i=0; i<al_len(lista); i++)
        {
            tarea = newTarea();
            tarea = al_get(lista,i);
            fprintf(archivo,"%s, %d, %d \n",tarea->Tarea,tarea->importancia,tarea->hora);
        }
        printf("Archivo de tareas de mayor importancia generado correctamente!\n");
    }
    else
    {
        printf("Ha ocurrido un error!\n");
    }
    fclose(archivo);

}
void generarBaja(ArrayList* lista )
{
    int i;
    ETarea* tarea;
    FILE* archivo;
    archivo = fopen("pBaja.csv","w");

    if(archivo!=NULL)
    {
        for(i=0; i<al_len(lista); i++)
        {
            tarea = newTarea();
            tarea = al_get(lista,i);
            fprintf(archivo,"%s, %d, %d \n",tarea->Tarea,tarea->importancia,tarea->hora);

         }
         printf("Archivo de tareas de menor importancia generado correctamente!\n");
    }
    else
    {
        printf("Ha ocurrido un error!\n");
    }
    fclose(archivo);

}


