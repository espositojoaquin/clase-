#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "funciones.h"

int main()
{
    ArrayList* lista = al_newArrayList();
    ArrayList* sublista;
    //eEmpleados* empleado;

    int opcion;
    char seguir = 's';

    do
    {
        printf("\t\t\tRECUPERATORIO PARCIAL N2 LABORATORIO\n\n\
1.Leer empleados\n\
2.Mostrar empleados\n\
3.Filtrar y mostrar\n\
4.Salir\n\n\
Elija una opcion: ");

        scanf("%d", &opcion);
        while(opcion < 1 || opcion > 4)
        {
            printf("\nError!! ingrese una opcion valida (1-4): ");
            scanf("%d", &opcion);
        }

        switch(opcion)
        {
        case 1:
            if(leerEmpleados(lista))
            {
                printf("\nArchivo de empleados cargado correctamente!!\n\n");
            }
            system("pause");
            system("cls");

            break;

        case 2:
            mostrar(lista);
            system("pause");
            system("cls");
            break;

        case 3:
            sublista = al_filter(lista, funcionQueFiltra);

            if(sublista != NULL)
            {
                mostrar(sublista);
            }
            else
            {
                printf("\nError!!!\n");
            }
            system("pause");
            system("cls");
            break;

        case 4:
            guardarOut(sublista);
            system("pause");
            seguir = 'n';
            break;
        }

    }
    while(seguir == 's');

    return 0;
}
