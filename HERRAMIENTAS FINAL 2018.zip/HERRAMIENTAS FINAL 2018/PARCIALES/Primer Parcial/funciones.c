#include "funciones.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#define TALADRO 100
#define AMOLADORA 101
#define MEZCLADORA 102
#define ALQUILADO 1
#define FINALIZADO 2
#define TAM 15
#define TAMA 30


void inicializarRP(ECliente cliente[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {
        cliente[i].estado=0;
    }

}
//**********************************************************
int EspacioLibre(ECliente cliente[],int tam)
{
    int i;
    int flag= -1;
    for(i=0; i<tam; i++)
    {
        if(cliente[i].estado==0)
        {
            flag=i;
            break;
        }
    }
    return flag;
}
//***********************************************************
void IngresoDatos(ECliente cliente[],int tam)
{

    int i;


    for(i=0; i<tam; i++)
    {
        if(cliente[i].estado==0)
        {

            cliente[i].idCliente=i+100;

            printf("\nPor favor ingrese su nombre: ");
            fflush(stdin);
            gets(cliente[i].nombre);
            printf("\ningrese su Apellido: ");
            fflush(stdin);
            gets(cliente[i].Apellido);
            printf("\ningrese su dni: ");
            scanf("%d",&cliente[i].dni);
            cliente[i].dni=validacionDNI(cliente,tam,cliente[i].dni);

            cliente[i].estado=1;
            printf("\n CLIENTE INGRESADO\n ");
            mostrarPersonaIgresada(cliente[i]);


            break;
        }
    }



}
//*****************************************************
void mostrarPersonaIgresada(ECliente cliente)
{
    printf("\nCodigo de cliente: %d\nNombre: %s\nApellido: %s\nDNI: %d\n\n",cliente.idCliente,cliente.nombre,cliente.Apellido,cliente.dni);
}

//***************************************************************
int validacionDNI(ECliente cliente[],int tam,int aux)
{
    int i;
    for(i=0; i<tam; i++)
    {
        if(cliente[i].estado==1)
        {
            while(aux<999999||aux>99000000)
            {
                printf("introduzca un documento valido: ");
                fflush(stdin);
                scanf("%d",&aux);
                system("pause");
                system("cls");

            }
            while(aux==cliente[i].dni)
            {
                printf("Este DNI ya fue Registrado por favor indroduzca otro: ");
                fflush(stdin);
                scanf("%d",&aux);
                system("pause");
                system("cls");

            }
        }




        break;
    }
    return aux;
}
//******************************************************************

void altaCliente(ECliente cliente[],int tam)
{


    int EL;

    EL=EspacioLibre(cliente,tam);
    if(EL==-1)
    {
        printf("No hay mas espacio disponible \n");

    }
    else
    {
        IngresoDatos(cliente,tam);

    }


}
//************************************************************

void inicializarRPA(EAlquiler alquiler[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {
        alquiler[i].estado=0;
    }

}
//*************************************************************

int EspacioLibreA(EAlquiler alquiler[],int tam)
{
    int i;
    int flag= -1;
    for(i=0; i<tam; i++)
    {
        if(alquiler[i].estado==0)
        {
            flag=i;
            break;
        }
    }
    return flag;
}
//***********************************************************

//***************************************************

//***************************************************

void HardCode(ECliente gente[],int tam)
{
    int id[6]= {100,101,102,103,104,105};
    char nombre[6][50]= {"Juan","Maria","Pedro","Julian","Martina","Julio"/*"Kevin","Joaquin","Leonel","Brenda","Aldana","Luz","Agustin","Angel","Brian","Gladys","Ruben","Luis","Claudia","Vanina"*/};
    char Apellido[6][50]= {"Perez","Suarez","Gonzales","Martinez","Lopez","Fernandez"};
    int dni[6]= {40929964,40929954,40929966,40929969,47929964,40929914/*40929963,48929964,41929964,42929964,43929964,44929964,45929964,46929964,40129964,40229964,41329964,40929644,40926984,40929147*/};

    int i;
    printf("\tCLIENTES\n");

    for(i=0; i<6; i++)
    {
        gente[i].idCliente=id[i];
        gente[i].dni=dni[i];
        strcpy(gente[i].nombre,nombre[i]);
        strcpy(gente[i].Apellido,Apellido[i]);


        gente[i].estado=1;
        if(gente[i].estado==1)
        {
            mostrarPersonaIgresada(gente[i]);
        }




    }
    system("pause");
    system("cls");



}
//****************************************************
void mostrar(ECliente gente[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {
        if(gente[i].estado==1)
        {
            mostrarPersonaIgresada(gente[i]);

        }

    }
}
//***************************************************************

void HardCodeA(EAlquiler alquiler[],int tam)
{
    int Cliente[]= {100,101,102,103,104,105,100,100,105,103};
    int idA[]= {10,11,12,13,14,15,16,17,18,19};
    char Operador[][30]= {"Kevin","Joaquin","Leonel","Brenda","Aldana","Luz","Agustin","Angel","Brian","Gladys"};
    float tiempo[]= {3.50,4.2,5.80,8,6,4.30,6.30,7.30,5,10};
    char auxE[10][30]= {"Mezcladora","Amoladora","Mezcladora","Taladro","Taladro","Amoladora","Mezcladora","Taladro","Taladro","Mezcladora"};
    int i;
    printf("\tALQUILERES\n");

    for(i=0; i<10; i++)
    {
        alquiler[i].estado=ALQUILADO;
    }


    for(i=0; i<tam; i++)
    {
        alquiler[i].cliente=Cliente[i];
        alquiler[i].id=idA[i];
        strcpy(alquiler[i].Operador,Operador[i]);
        alquiler[i].tiempoEstimado=tiempo[i];




        if(alquiler[i].estado==ALQUILADO)
        {
            if(strcmpi(auxE[i],"Taladro")==0)
            {
                alquiler[i].equipo= TALADRO;

            }
            else
            {
                if(strcmpi(auxE[i],"Amoladora")==0)
                {
                    alquiler[i].equipo= AMOLADORA;
                }
                if(strcmpi(auxE[i],"Mezcladora")==0)
                {
                    alquiler[i].equipo= MEZCLADORA;
                }
            }

            switch(alquiler[i].equipo)
            {
            case AMOLADORA:
                printf("\nCodigo de cliente: %d\nNumero de Alquiler : %d\nEquipo: Amoladora\nTiempo Estimado: %.2f\nOperador: %s\n\n",alquiler[i].cliente,alquiler[i].id,alquiler[i].tiempoEstimado,alquiler[i].Operador);
                break;
            case TALADRO:

                printf("\nCodigo de cliente: %d\nNumero de Alquiler : %d\nEquipo: Taladro\nTiempo Estimado: %.2f\nOperador: %s\n\n",alquiler[i].cliente,alquiler[i].id,alquiler[i].tiempoEstimado,alquiler[i].Operador);
                break;

            case MEZCLADORA:

                printf("\nCodigo de cliente: %d\nNumero de Alquiler : %d\nEquipo: Mezcladora\nTiempo Estimado: %.2f\nOperador: %s\n\n",alquiler[i].cliente,alquiler[i].id,alquiler[i].tiempoEstimado,alquiler[i].Operador);
                break;


            }
        }

    }
    system("pause");
    system("cls");


}

void clientesYalquileres(ECliente cliente[],EAlquiler alquiler[],int tam,int tamA)
{
    int i,j;

    for(i=0; i<tam; i++)
    {
        if(cliente[i].estado==1)
        {

            printf("\n\n %s %s\n",cliente[i].nombre,cliente[i].Apellido);

            for(j=0; j<tamA; j++)
            {
                if(alquiler[j].estado==ALQUILADO&&cliente[i].estado==1)
                {

                    if(cliente[i].idCliente==alquiler[j].cliente)
                    {

                        switch(alquiler[j].equipo)
                        {
                        case AMOLADORA:
                            printf("\nNumero de Alquiler : %d\nEquipo: Amoladora\nTiempo Estimado: %.2f\nOperador: %s\n\n",alquiler[j].id,alquiler[j].tiempoEstimado,alquiler[j].Operador);
                            break;
                        case TALADRO:

                            printf("\nNumero de Alquiler : %d\nEquipo: Taladro\nTiempo Estimado: %.2f\nOperador: %s\n\n",alquiler[j].id,alquiler[j].tiempoEstimado,alquiler[j].Operador);
                            break;

                        case MEZCLADORA:

                            printf("\nNumero de Alquiler : %d\nEquipo: Mezcladora\nTiempo Estimado: %.2f\nOperador: %s\n\n",alquiler[j].id,alquiler[j].tiempoEstimado,alquiler[j].Operador);
                            break;

                            system("pause");
                            system("cls");

                        }

                    }

                }
                if(alquiler[j].estado==FINALIZADO&&cliente[i].idCliente==alquiler[j].cliente)
                {
                    printf("\n Sin Alquileres\n");
                }



            }
        }


    }
}
//*************************************************************************
void ModificarP(ECliente gente[],int tam)
{
    int i;
    int flag=0;
    int aux;
    char auxN[30];
    char auxE[30];
    char respuesta='s';
    printf("\nPor favor ingrese su numero de indentificacion: ");
    scanf("%d",&aux);
    for(i=0; i<tam; i++)
    {
        if(aux==gente[i].idCliente)
        {
            flag=1;
            printf(" Desea modificar este Nombre y Apellido?(s/n)\n %s\t%s \n",gente[i].nombre,gente[i].Apellido);
            fflush(stdin);
            respuesta=getch();
            while(respuesta!='s'&&respuesta!='n')
            {
                printf("Por favor responda (s/n)\n");
                fflush(stdin);
                respuesta=getch();
                system("pause");
                system("cls");
            }
            if(respuesta=='s')
            {
                printf("\nIngrese el nombre : \n");
                scanf("%s",&auxN);
                strcpy(gente[i].nombre,auxN);
                printf("\nIngrese el Apellido: \n");
                scanf("%s",&auxE);
                strcpy(gente[i].Apellido,auxE);


                printf("Nombre y Apellido moficado con exito\n");
                system("pause");
                system("cls");
                break;
            }
            else
            {
                printf("Accion cancelada por el usuario\n");
                system("pause");
                system("cls");
                break;
            }
        }

    }
    if(flag==0)
    {
        printf(" Usuario inexistente\n");
        system("pause");
        system("cls");

    }

}
//************************************************************************

void BajaC(ECliente gente[],int tam)
{
    int i;
    int flag=0;
    int aux;

    char respuesta='s';
    printf("\nPor favor ingrese su numero de indentificacion: ");
    scanf("%d",&aux);
    for(i=0; i<tam; i++)
    {
        if(gente[i].estado!=0)
        {
            if(aux==gente[i].idCliente)
            {
                flag=1;
                printf(" Desea eliminar este usuario?(s/n)\n %s\t%s\t%d\n",gente[i].nombre,gente[i].Apellido,gente[i].dni);
                fflush(stdin);
                respuesta=getch();
                while(respuesta!='s'&&respuesta!='n')
                {
                    printf("Por favor responda (s/n)\n");
                    fflush(stdin);
                    respuesta=getch();
                    system("pause");
                    system("cls");
                }
                if(respuesta=='s')
                {
                    gente[i].estado=2;

                    printf("Usuario eliminado con exito\n");
                    system("pause");
                    system("cls");
                    break;
                }
                else
                {
                    printf("Accion cancelada por el usuario\n");
                    system("pause");
                    system("cls");
                    break;
                }
            }
        }



    }
    if(flag==0)
    {
        printf(" Usuario inexistente\n");
        system("pause");
        system("cls");

    }

}
//*******************************************************************
void IngreseAlquiler(EAlquiler alquiler[],ECliente clientes[],int tamA,int tamC)
{
    int i,j,flag=0;
    char auxE[30];


    for(i=0; i<tamA; i++)
    {
        if(alquiler[i].estado==0)
        {

            printf("\nPor favor ingrese el numero de cliente: ");
            scanf("%d",&alquiler[i].cliente);

            for(j=0; j<tamC; j++)
            {
                if(clientes[j].estado!=0)
                {
                    if(alquiler[i].cliente==clientes[j].idCliente)
                    {
                        flag=1;
                        printf("\ningrese el nombre del Operador: ");
                        fflush(stdin);
                        gets(alquiler[i].Operador);
                        alquiler[i].id=i+10;
                        printf("\n ingrese el Tiempo estimado: ");
                        scanf("%f",&alquiler[i].tiempoEstimado);
                        alquiler[i].estado=ALQUILADO;
                        if(alquiler[i].estado==ALQUILADO)
                        {
                            printf("\nPor favor ingrese el equipo(TALADRO-AMOLADORA-MEZCLADORA)\n");
                            fflush(stdin);
                            gets(auxE);
                            while(strcmpi(auxE,"Taladro")!=0&&strcmpi(auxE,"Amoladora")!=0&&strcmpi(auxE,"Mezcladora")!=0)
                            {
                                printf("\nPor favor ingrese uno de estos equipos(TALADRO-AMOLADORA-MEZCLADORA)\n");
                                fflush(stdin);
                                gets(auxE);
                                system("pause");
                                system("cls");
                            }

                            if(strcmpi(auxE,"Taladro")==0)
                            {
                                alquiler[i].equipo= TALADRO;

                            }
                            else
                            {
                                if(strcmpi(auxE,"Amoladora")==0)
                                {
                                    alquiler[i].equipo= AMOLADORA;
                                }
                                if(strcmpi(auxE,"Mezcladora")==0)
                                {
                                    alquiler[i].equipo= MEZCLADORA;
                                }



                            }

                            switch(alquiler[i].equipo)
                            {
                            case AMOLADORA:
                                printf("\nCodigo de cliente: %d\nNumero de Alquiler : %d\nEquipo: Amoladora\nTiempo Estimado: %.2f\nOperador: %s\n\n",alquiler[i].cliente, alquiler[i].id, alquiler[i].tiempoEstimado, alquiler[i].Operador);
                                break;
                            case TALADRO:

                                printf("\nCodigo de cliente: %d\nNumero de Alquiler : %d\nEquipo: Taladro\nTiempo Estimado: %.2f\nOperador: %s\n\n",alquiler[i].cliente, alquiler[i].id, alquiler[i].tiempoEstimado, alquiler[i].Operador);
                                break;

                            case MEZCLADORA:

                                printf("\nCodigo de cliente: %d\nNumero de Alquiler : %d\nEquipo: Mezcladora\nTiempo Estimado: %.2f\nOperador: %s\n\n",alquiler[i].cliente, alquiler[i].id, alquiler[i].tiempoEstimado, alquiler[i].Operador);
                                break;
                                system("pause");
                                system("cls");


                            }
                        }


                    }


                }
            }

            break;

        }
    }
    if(flag==0)
    {
        printf("\nUsuario inexistente\n");
        system("pause");
        system("cls");

    }



}




//*********************************
void altaAlquiler(EAlquiler alquiler[],ECliente cliente[],int tamA,int tamC)
{
    int EL;
    EL=EspacioLibreA(alquiler,tamA);
    if(EL==-1)
    {
        printf("\nNo hay Espacio disponible\n");
    }
    else
    {
        IngreseAlquiler(alquiler,cliente,tamA,tamC);
    }
}


//********************

//******************************************************

//************************************************
void finDeAlquiler(EAlquiler alquiler[],int tam)
{
    int aux;
    int verificar;
    int i;

    printf("ingrese el codigo de indentificacion del alquiler:");
    scanf("%d",&aux);
    verificar=CodigoAlquiler(alquiler,tam,aux);
    while(verificar==-1)
    {
        printf("ingrese una orden de alquiler existente:");
        scanf("%d",&aux);
        verificar=CodigoAlquiler(alquiler,tam,aux);
    }

    for(i=0; i<tam; i++)
    {
        if(alquiler[i].id==aux)
        {
            printf("\ningrese la hora real de alquiler: \n");
            scanf("%f",&alquiler[i].tiempoReal);
            alquiler[i].estado=FINALIZADO;

            printf("alquiler finalizado.\n");

            system("pause");
        }

    }

}
//***************************************************
int CodigoAlquiler(EAlquiler alquiler[],int tam,int orden)
{
    int i;
    int retorno=-1;
    for(i=0; i<tam; i++)
    {
        if(alquiler[i].estado==ALQUILADO&&alquiler[i].id==orden)
        {
            retorno=i;
            return retorno;
        }
    }
    return retorno;
}
//********************************************************

//*******************************************************************************

//**************************************************************************************

//****************************************************************************************
void promedioHoras(EAlquiler alquiler[],int tam)
{
    int i;
    int cont=0;
    int flag=0;
    float acumulador=0;
    float resultado;
    float ResultadoEntero;
    float ResultadoD;
    float promedio;

    for(i=0; i<tam; i++)
    {

        if(alquiler[i].estado==FINALIZADO)
        {
            flag=1;
            acumulador=(acumulador+alquiler[i].tiempoEstimado)-alquiler[i].tiempoReal;
            cont++;
        }
    }

    if(flag==1)
    {
        promedio=acumulador/cont;
        resultado=(promedio-(int)promedio);
        if(resultado>0.59)
        {
            ResultadoEntero=(int)promedio+1;
            ResultadoD=(resultado-0.60);
            promedio=ResultadoEntero+ResultadoD;

        }


        printf("\nEl promedio de las hora reales es: %.2f Hs\n",promedio);
    }
    else
    {
        printf("\nEl promedio de las hora reales es: 0 Hs\n");
    }

}
//********************************************************
void MasAlquilado(EAlquiler alquiler[],ECliente cliente[],int tam,int tamC)
{
    int i,j;
    int conT=0;
    int conA=0;
    int conM=0;
    for(j=0; j<tamC; j++)
    {
        if(cliente[j].estado==1)
        {
            for(i=0; i<tam; i++)
            {
                if(alquiler[i].estado!=0)
                {
                    if(cliente[j].idCliente==alquiler[i].cliente)
                    {
                        if(alquiler[i].equipo==TALADRO)
                        {
                            conT++;
                        }
                        else
                        {
                            if(alquiler[i].equipo==AMOLADORA)
                            {
                                conA++;
                            }
                            else
                            {
                                if(alquiler[i].equipo==MEZCLADORA)
                                {
                                    conM++;
                                }


                            }
                        }
                    }
                }



            }
        }

    }


    if(conT>conA&&conT>conM)
    {

        printf("\n el equipo mas alquilado es: Taladro con:%d alquileres\n",conT);

    }

    else
    {

        if(conA>conT&&conA>conM)
        {
            printf("\n el equipo mas alquilado es: Amoladora con:%d alquileres\n",conA);


        }

        else
        {

            if(conM>conT&&conM>conA)
            {

                printf("\n el equipo mas alquilado es: Mezcladora con:%d alquileres\n",conM);

            }

        }


        if(conT==conA&&conT>conM)
        {

            printf("\n Los equipos mas alquilados son: el Taladro y la Amoladora con:%d alquileres cada uno\n",conT);



        }
        else
        {
            if(conT==conM&&conT>conA)
            {

                printf("\n Los equipos mas alquilados son: el Taladro y la Mezcladora con:%d alquileres cada uno\n",conT);



            }


            else
            {

                if(conA==conM&&conA>conT)
                {

                    printf("\n Los equipos mas alquilados son: Amoladora y Mezcladora con:%d alquileres cada uno\n",conA);




                }


                else
                {

                    if(conT==conA&&conT==conM)
                    {
                        printf("\n Todos los equipos fueron alquilados por igual,con:%d alquileres cada uno\n",conT);

                    }


                }

            }
        }
    }


}
//************************************************************************************************
void clienteMasA(EAlquiler alquiler[],ECliente cliente[],int tamC,int tamA)
{
    int i;
    int j;
    int cont1=0;
    int cont2=0;
    int flag=0;
    int aux;
    int aux2;

    for(i=0; i<tamC; i++)
    {
        for(j=0; j<tamC; j++)
        {
            if(alquiler[j].cliente==cliente[i].idCliente&&cliente[i].estado==1)
            {
                cont2++;
            }

        }
        if(cont2>=cont1)
        {
            if(cont1==cont2)
            {
                aux2=i;
                flag=1;
            }
            else
            {
                cont1=cont2;
                aux=i;
            }

        }
        cont2=0;
    }
    for(i=0; i<tamC; i++)
    {

        if(alquiler[i].cliente==cliente[aux].idCliente&&cliente[i].estado==1)
        {
            printf("===============================================\n");
            printf("el cliente con mas alquileres es: %s %s\n",cliente[aux].Apellido,cliente[aux].nombre);
            if(flag==1)
            {
                for(j=0; j<tamC; j++)
                {
                    if(alquiler[j].cliente==cliente[aux2].idCliente&&cliente[i].estado==1)
                    {

                        printf("y tambien:%s %s\n",cliente[aux2].Apellido,cliente[aux2].nombre);
                        break;
                    }
                }
            }
            break;
        }
        if(alquiler[i].estado==0)
        {
            printf("\n No se ha producido Ningun alquiler\n");
            break;
        }
    }

}







