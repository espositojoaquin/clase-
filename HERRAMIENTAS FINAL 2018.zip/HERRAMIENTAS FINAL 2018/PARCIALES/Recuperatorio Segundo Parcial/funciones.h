
typedef struct
{
    char nombre[30];
    int edad;
    char profesion[30];
}eEmpleado;

void mostrarEmpleado(ArrayList* lista);
eEmpleado* newEmpleado();
eEmpleado* newEmpleadoPar(char nombre[],int edad, char profesion[]);
int LeerTareas( FILE* Archivo,ArrayList* lista);
void mostrarEmpleado(ArrayList* lista);
int funcionQueFiltra(void* empleado);

