#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "ArrayList.h"

int main()
{
    char seguir='s';
    int opcion=0;
    char respuesta[20];
    int Arch;
    ArrayList* lista;
    ArrayList* listaB;
    ArrayList* listaD;
    lista = al_newArrayList();
    listaB=al_newArrayList();
    listaD=al_newArrayList();
    system("color 4F");
    int i;

    FILE* archivo;

    while(seguir=='s')
    {
        printf("1- Cargar destinatarios\n");
        printf("2- Cargar lista negra \n");
        printf("3- Depurar y generar txt\n");
        printf("4- Listar\n");
        printf("5- Salir\n");

        printf("\nIngrese una opcion: ");
        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:
            cargar(lista,archivo);

            system("pause");
            system("cls");

            break;
        case 2:
               cargar(listaB,archivo);

            system("pause");
            system("cls");

            break;
        case 3: listaD=Depurar(lista,listaB);
                 if(listaD==NULL)
                 {
                     printf("\nNo hay elementos ");
                 }
                 else
                 {
                     employeePrint(listaD);
                 }
                 guardarDocumento(listaD,listaD->len(listaD));

            system("pause");
            system("cls");


            break;
        case 4:

            system("pause");
            system("cls");


            break;

        case 5:
            seguir = 'n';

            system("pause");
            system("cls");
            break;

            default:
            printf("Ingreso una opcion incorrecta! \n");
            break;
        }
    }


    return 0;
}
