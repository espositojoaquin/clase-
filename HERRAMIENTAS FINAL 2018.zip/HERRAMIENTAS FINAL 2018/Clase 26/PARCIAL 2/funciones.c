#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "ArrayList.h"
#include "funciones.h"

int employee_setName(eEmpleado* Emp, char nombre[])
{
    //Emp->name;
    strcpy(Emp->nombre,nombre);
    return 0;

}
int employee_setEmail(eEmpleado* Emp, char email[])
{
    //Emp->name;
    strcpy(Emp->email,email);
    return 0;

}
//*****************************************************************************
int employee_setEmty(eEmpleado* Emp, int estado)
{
    //Emp->name;
    Emp->estado=estado;
    return 0;

}
//******************************************************************************
eEmpleado* newEmp()
{
    eEmpleado* aux;
    aux = (eEmpleado*) malloc (sizeof(eEmpleado));
    return aux;
}
//******************************************************************************
eEmpleado* newPersonParametros( char nombre[],char email[])
{
    eEmpleado* Emp;

    Emp = newEmp();
    if(Emp!=NULL)
    {
        strcpy(Emp->nombre,nombre);

        strcpy(Emp->email,email);

    }

    return Emp;
}

//******************************************************************************
int parserEmployee( FILE* Archivo,ArrayList* lista,char nombreArch[])
{
    char  fitrs_name[50], eMail[50];
    eEmpleado* emp;
    int retorno;

    Archivo=fopen(nombreArch,"r");
    if(Archivo==NULL||lista==NULL)
    {
        retorno=0;
    }
    else
    {

        // fscanf(Archivo, "%[^,],%[^\n]\n",fitrs_name,eMail);

        while(!feof(Archivo))
        {

            fscanf(Archivo, "%[^,],%[^\n]\n",fitrs_name,eMail);
            emp=newPersonParametros(fitrs_name,eMail);
            if(emp!=NULL)
            {

                employee_setName(emp,fitrs_name);
                employee_setEmail(emp,eMail);
                employee_setEmty(emp,1);

                al_add(lista,emp);


            }

        }

        retorno=1;
    }


    fclose(Archivo);

    return retorno;


}
//*******************************************************************************
void employee_print(eEmpleado* Emp)
{
    printf("|%-5s\t\t%-15s|\n",Emp->nombre,Emp->email);
}

void employeePrint(ArrayList* lista)
{
    eEmpleado* Emp;
    if(lista->isEmpty(lista)==0)
    {
        int i;
        printf("|===============================================================================|\n");
        printf("|                               EMPLEADOS                                        \n");
        printf("|===============================================================================|\n");
        printf("| NAME        |        EMAIL            \n");
        printf("|===============================================================================|\n");
        for(i=0; i<lista->len(lista); i++)
        {
            Emp=(eEmpleado*)lista->get(lista,i);


            employee_print(Emp);
            printf("|===============================================================================|\n");
            if(i>0)
            {
                if(i%50==0)
                {
                    system("pause");
                }
            }

        }
    }
    else
    {
        printf("\nNo hay equipos ingresados");
    }

}
//**********************************************************************
void cargar(ArrayList* lista, FILE* archivo)
{
    int Arch;
    char respuesta[30];
    printf("Ingrese el nombre del archivo: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",respuesta);
    Arch=parserEmployee(archivo,lista,respuesta);
    if(Arch==0)
    {
        printf("\n Error al abrir el archivo\n");
    }
    else
    {
        printf("\n Archivo cargado con exito\n");

    }
    // employeePrint(lista);
}
//******************************************************************************
ArrayList* Depurar(ArrayList* lista,ArrayList* listaN)
{
    int i,j;
    int aux;
    int flag=0;
    ArrayList* ListaD;
    ArrayList* retorno;
    eEmpleado* auxI;
    eEmpleado* auxj;
    ListaD=al_newArrayList();

    if(lista!=NULL&&listaN!=NULL&&ListaD!=NULL)
    {
        for(i=0; i<lista->len(lista); i++)
        {
            for(j=0; j<listaN->len(listaN); j++)
            {
               auxj=listaN->get(listaN,j);
               auxI=lista->get(lista,i);

                if(strcmpi(auxI->email,auxj->email)==0)
                {
                    flag=1;
                    break;
                }
                else
                {
                    flag=0;
                }
            }
            if(flag==0)
            {
               ListaD->add(ListaD,lista->get(lista,i));
            }

        }
        if(flag==1)
        {
            retorno=ListaD;
        }
        else
        {
            retorno=NULL;
        }

    }
    else
    {
        retorno=NULL;

    }
    return retorno;

}
//********************************************************
void guardarDocumento(ArrayList* pList,int tam)
{
    FILE* pDep;
    int i;
    eEmpleado* emp;
    pDep=fopen("Archivo.txt","w");
    if(pDep==NULL)
    {
        printf("Error al abrir el archivo binario\n");
        exit(1);
    }

    setbuf(stdin,NULL);
    for(i=0;i<pList->len(pList);i++)
    {
        emp=pList->get(pList,i);

         fprintf(pDep,"|%-5s\t\t%-15s|\n",emp->nombre,emp->email);
    }

    printf("\nArchivo guardado con exito!\n");
    fclose(pDep);
}



