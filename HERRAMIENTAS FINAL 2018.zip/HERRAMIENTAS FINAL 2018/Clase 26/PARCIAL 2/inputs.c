
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

int verifNumero(char cad[])
{
    int tam;
    int i;
    int retorno;
    tam= strlen(cad);
    for(i=0; i<tam; i++)
    {
        if(cad[i]>'9'||cad[i]<'0')
        {
            retorno=0;
            break;
        }
        else
        {
            retorno=1;
        }
    }
    return retorno;
}
//**************************************************************************************************************
int verifFloat(char cad[])
{
    int tam;
    int i;
    int cont=0;
    int retorno;
    tam= strlen(cad);
    for(i=0; i<tam; i++)
    {
        if(cad[i]=='.')
        {
            cont++;
        }
        if(cad[i]>'9'&&cad[i]!='.'||cad[i]<'0'&&cad[i]!='.')
        {
            retorno=0;
            break;
        }
        else
        {
            if(cont>1)
            {
                retorno=0;
            }
            else
            {
                retorno=1;
            }

        }
    }
    return retorno;
}
//**************************************************************************************************************
int EsLetra(char letras[])
{
    int i,retorno;
    int tam=strlen(letras);
    strlwr(letras);

    for(i=0; i<tam; i++)
    {
        if(letras[i]<'a'&&letras[i]!=' '||letras[i]>'z'&&letras[i]!=' ')
        {
            retorno=0;
            break;
        }
        else
        {

            retorno=1;
            letras[0]=toupper(letras[0]);

        }
    }
    return retorno;
}
//**************************************************************************************************************

//**************************************************************************************************************
void isWord(char aux[])
{
    while(EsLetra(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");

    }
}
//**************************************************************************************************************
void isNumber(char aux[])
{
    while(verifNumero(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");


    }
}
//**************************************************************************************************************
void isFloat(char aux[])
{
    while(verifFloat(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");


    }
}
//**************************************************************************************************************
int VefAphaandNumber(char aux[])
{
    int retorno;
    int i;
    int tam=strlen(aux);
    for(i=0; i<tam; i++)
    {
        if(aux[i]>' '&&aux[i]<'/'||aux[i]>'9'&&aux[i]<'`'||aux[i]>'z')
        {
            retorno=0;
        }
        else
        {
            retorno=1;
        }

    }

    return retorno;
}

//**************************************************************************************************************
void isAlphaNumber(char aux [])
{
    while(VefAphaandNumber(aux)==0)
    {
        printf("Error por favor Reingrese: \n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",aux);
        system("pause");
        system("cls");

    }
}
//**************************************************************************************************************
int menu(char auxOP[])
{
    int opcion;
        printf("1. Alta Usuario\n");
        printf("2. Modificar datos del usuario\n");
        printf("3. Baja de Usuario\n");
        printf("4. Publicar producto\n");
        printf("5.Modificar Publicacion\n");
        printf("6.Cancelar publicacion\n");
        printf("7.Comprar Producto\n");
        printf("8.Listar Publicaciones de Usuarios\n");
        printf("9.Listar Publicaciones\n");
        printf("10.Listar Usuarios\n");
        printf("11.Salir\n");
        printf("Ingrese una opcion: \n");
        setbuf(stdin,NULL);
        scanf("%s",auxOP);
        isNumber(auxOP);
        opcion=atoi(auxOP);
        return opcion;

}
//*************************************************************************************************************
