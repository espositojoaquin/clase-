#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
typedef struct
{
    char nombre[20];
    char email[50];
    int estado;
}eEmpleado;

int employee_setName(eEmpleado* Emp, char nombre[]);
int employee_setEmail(eEmpleado* Emp, char email[]);
int employee_setEmty(eEmpleado* Emp, int estado);
eEmpleado* newEmp();
eEmpleado* newPersonParametros( char nombre[],char email[]);
int parserEmployee( FILE* Archivo,ArrayList* lista,char nombreArch[]);
void employee_print(eEmpleado* Emp);
void employeePrint(ArrayList* lista);
