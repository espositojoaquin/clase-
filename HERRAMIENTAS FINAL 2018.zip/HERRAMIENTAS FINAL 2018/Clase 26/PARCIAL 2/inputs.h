
int verifNumero(char cad[]);
int verifFloat(char cad[]);
int EsLetra(char letras[]);
void isWord(char aux[]);
void isNumber(char aux[]);
void isFloat(char aux[]);
int VefAphaandNumber(char aux[]);
void isAlphaNumber(char aux []);
int menu(char auxOP[]);
