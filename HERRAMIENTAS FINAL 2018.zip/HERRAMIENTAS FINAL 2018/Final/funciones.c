#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <conio.h>

#include "arraylist.h"
#include "funciones.h"
#include "inputs.h"



/*//**************************************************************************
int funcionQueFiltra(void* p)
{
    int retorno=0;
    if(((eEmpleado*)p)!=NULL)
    {
      if(((eEmpleado*)p)->edad>30)
      {
          if(strcmpi(((eEmpleado*)p)->prof,"Programador")==0)
          {
            retorno=1;

          }
      }


   }
   return retorno;

}*/

//**************************************************************************
int numeros_setName(eNumeros* Emp, char nombre[])
{
    strcpy(Emp->nombre,nombre);
    return 0;

}
//***************************************************************************
int numeros_setNum(eNumeros* Emp, int Num)
{

    Emp->numero=Num;
    return 0;

}
//*****************************************************************************
/*int employee_setProf(eEmpleado* Emp, int prof)
{

    strcpy(Emp->prof,prof);
    return 0;


}*/
//******************************************************************************

//******************************************************************************
eNumeros* newNum()
{
    eNumeros* aux;
    aux = (eNumeros*) malloc (sizeof(eNumeros));
    return aux;
}
//******************************************************************************
eNumeros* newNumParametro( char nombre[],int num)
{
    eNumeros* Emp;

    Emp = newNum();
    if(Emp!=NULL)
    {
        strcpy(Emp->nombre,nombre);
        Emp->numero=num;


    }

    return Emp;
}

//******************************************************************************
int parserNum(FILE* Archivo,ArrayList* lista,char nombreArch[])
{
    char  fitrs_name[50], num[50];
    eNumeros* emp;
    int retorno;

    Archivo=fopen(nombreArch,"r");
    if(Archivo==NULL||lista==NULL)
    {
        retorno=0;
    }
    else
    {

        fscanf(Archivo, "%[^,],%[^\n]\n",fitrs_name,num);

        while(!feof(Archivo))
        {
            fscanf(Archivo, "%[^,],%[^\n]\n",fitrs_name,num);
            emp=newNumParametro(fitrs_name,num);
            if(emp!=NULL)
            {

                numeros_setName(emp,fitrs_name);
                numeros_setNum(emp,atoi(num));



                lista->add(lista,emp);
                if(feof(Archivo))
                {
                    break;
                }


            }

        }

        retorno=1;
    }


    fclose(Archivo);

    return retorno;

}
//*******************************************************************************
void Num_print(eNumeros* Emp)
{
    printf("|%-10s\t\t%-10d\t\t%-7d\t\t%-8d\t\t%-5d|\n",Emp->nombre,Emp->numero,Emp->par,Emp->impar,Emp->primo);
}
//*******************************************************************************
void NumPrint(ArrayList* lista)
{
    eNumeros* Emp;
    if(lista->isEmpty(lista)==0)
    {
        int i;
        printf("|============================================================================================|\n");
        printf("|                               NUMEROS                                                      |\n");
        printf("|============================================================================================|\n");
        printf("|     NOMBRES    |       NUMEROS      |       PAR      |         IMPAR      |        PRIMO   |\n");
        printf("|============================================================================================|\n");
        for(i=0; i<lista->len(lista); i++)
        {
            if(i>0)
            {
                if(i%50==0)
                {
                    system("pause");
                }
            }
            Emp = al_get(lista,i);
            Num_print(Emp);
        }
    }
    else
    {
        printf("\nNo hay registro de NUMEROS\n");
    }



}
//**********************************************************************
void cargar(ArrayList* lista, FILE* archivo)
{
    int Arch;
    char respuesta[30];
    printf("\nIngrese el nombre del archivo: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",respuesta);
    Arch=parserNum(archivo,lista,respuesta);
    if(Arch==0)
    {
        printf("\n Error al abrir el archivo\n");
    }
    else
    {
        printf("\n Archivo cargado con exito\n");

    }

}
//********************************************************
void generarArchivo(ArrayList* lista,FILE* archivo)
{
    int i;
    char aux[50];
    eNumeros* Emp=newNum();

    printf("\nIngrese el nombre con el cual desea Guardar el Archivo: ");
    //setbuf(stdin,NULL);
    fflush(stdin);
    gets(aux);

    archivo = fopen(aux,"w");


    if(archivo!=NULL)
    {
        if(lista->isEmpty(lista)==0)
        {   fprintf(archivo,"nombre,numero,par,impar,primo");
            for(i=0; i<al_len(lista); i++)
            {

                Emp = al_get(lista,i);

                fprintf(archivo,"%s,%d,%d,%d,%d\n",Emp->nombre,Emp->numero,Emp->par,Emp->impar,Emp->primo);


            }
            printf("Archivo generado correctamente!\n");
        }
        else
        {
            printf("\nNo hay Registros de Numeros para generar el archivo\n");
        }

    }
    else
    {
        printf("Ha ocurrido un error!\n");
    }
    fclose(archivo);

}
//*****************************************************************
int isPar_impar(int num)
{
    int retorno=0;
    if(num%2==0)
    {
        retorno=1;
    }
    return retorno;
}
int isPrimo(int num)
{
    int cont=0;
    int i;
    int retorno;

    for(i=1; i<num; i++)
    {

        if((num%i)==0)
        {
            cont++;
        }

    }

    if(cont>1)
    {
        retorno=0;

    }
    else
    {
        retorno=1;
    }
    return retorno;

}
//*******************************************************
void validar(ArrayList* lista)
{
    int i;
    eNumeros* numeros;
    numeros=newNum();
    if(lista!=NULL&&lista->isEmpty(lista)==0)
    {
        for(i=0; i<lista->len(lista); i++)
        {
            numeros=lista->get(lista,i);

            if(isPar_impar(numeros->numero)==1)
            {
                numeros->par=1;
                numeros->impar=0;
            }
            else
            {
                numeros->par=0;
                numeros->impar=1;
            }

            if(isPrimo(numeros->numero)==1)
            {
                numeros->primo=1;
            }
            else
            {
                numeros->primo=0;
            }

            numeros=lista->get(lista,i);
        }
        printf("\nCampos completados con exito\n");


    }
    else
    {
        printf("\nError al completar los campos\n");
    }


}
//****************************************************************
int comparaNumeros(void* pPersonA,void* pPersonB)
{

    if(((eNumeros*)pPersonA)->numero > ((eNumeros*)pPersonB)->numero)
    {
        return 1;
    }
    if(((eNumeros*)pPersonA)->numero < ((eNumeros*)pPersonB)->numero)
    {
        return -1;
    }
    return 0;

}
//****************************************************************
ArrayList* listarDescendente(ArrayList* lista)
{
    int aux;
    ArrayList* retorno;
    int i;
    retorno=al_newArrayList();
    eNumeros* ant=newNum();
    eNumeros* act=newNum();
    eNumeros* sig=newNum();

    if(lista!=NULL&&lista->isEmpty(lista)==0)
    {
        for(i=0; i<lista->len(lista); i++)
        {
            if(i==0)
            {
                act=lista->get(lista,i);
                sig=lista->get(lista,i+1);
                if(act->numero==sig->numero)
                {
                    retorno->add(retorno,act);

                }

            }
            else
            {
                ant=lista->get(lista,i-1);
                act=lista->get(lista,i);
                sig=lista->get(lista,i+1);

                if(act->numero==ant->numero||act->numero==sig->numero)
                {
                       retorno->add(retorno,act);

                }

            }

        }
    }

    retorno->sort(retorno,comparaNumeros,0);

    return retorno;


}
//*****************************************************************
ArrayList* listarAscendente(ArrayList* lista)
{
    int aux;
    ArrayList* retorno;
    int i;
    retorno=lista->clone(lista);
    eNumeros* ant=newNum();
    eNumeros* act=newNum();
    eNumeros* sig=newNum();


    if(retorno!=NULL&&retorno->isEmpty(retorno)==0)
    {
        for(i=0; i<retorno->len(retorno); i++)
        {
            if(i==0)
            {
                act=retorno->get(retorno,i);
                sig=retorno->get(retorno,i+1);
                if(act->numero==sig->numero)
                {
                     retorno->remove(retorno,i);

                }

            }
            else
            {
                ant=retorno->get(retorno,i-1);
                act=retorno->get(retorno,i);
                sig=retorno->get(retorno,i+1);

                if(act->numero==ant->numero||act->numero==sig->numero)
                {
                    if(act->numero==ant->numero)
                    {
                        retorno->remove(retorno,i-1);

                    }
                    else
                    {
                        if(act->numero==sig->numero)
                        {
                            retorno->remove(retorno,i);
                        }
                    }

                }


            }

        }
    }
    retorno->sort(retorno,comparaNumeros,1);


    return retorno;


}
