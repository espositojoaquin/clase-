#include <stdio.h>
#include <stdlib.h>
#include "arraylist.h"
#include "funciones.h"
#include "inputs.h"

int main()
{
    char seguir='s';
    int opcion=0;
    char respuesta[20];
    int Arch;
    int aux;
    int i;
    char auxOP[10];
    eNumeros* auxEmpleados;
    ArrayList* lista;
    ArrayList* listaRep;
    ArrayList* listaDep;
    lista = al_newArrayList();
    listaRep=al_newArrayList();
    listaDep=al_newArrayList();


    system("color 4F");


    FILE* archivo;

    while(seguir=='s')
    {
        opcion=menu(auxOP);

        switch(opcion)
        {
        case 1:
            cargar(lista,archivo);


            system("pause");
            system("cls");

            break;
        case 2:
            validar(lista);

            system("pause");
            system("cls");

            break;
        case 3:
            aux=lista->sort(lista,comparaNumeros,0);

            listaRep=listarDescendente(lista);
            NumPrint(listaRep);
            system("pause");
            system("cls");


            listaDep=listarAscendente(lista);
            NumPrint(listaDep);

            system("pause");
            system("cls");


            break;
        case 4:
                generarArchivo(lista,archivo);
                generarArchivo(listaRep,archivo);
                generarArchivo(listaDep,archivo);

            system("pause");
            system("cls");
            break;

        case 5:
            seguir = 'n';

            system("pause");
            system("cls");
            break;

        default:
            system("pause");
            system("cls");
            printf("Ingrese una opcion entre 1-5\n");

        }


    }
    return 0;

}
