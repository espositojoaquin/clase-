
typedef struct{

    char nombre[50];
    int numero;
    int par;
    int impar;
    int primo;

}eNumeros;


/** \brief  Setea el nombre
 * \param puntero a variable empleado
 * \param  el nombre ingresado
 * \return nombre seteado
 *
 */

int numeros_setName(eNumeros* Emp, char nombre[]);
int comparaNumeros(void* pPersonA,void* pPersonB);
void generarArchivo(ArrayList* lista,FILE* archivo);

/** \brief  Setea el numero
 * \param puntero a variable numero
 * \param  el id ingresado
 * \return id seteado
 *
 */
int numeros_setNum(eNumeros* Emp, int Num);




/** \brief  Genera lugar para un elemnto del tipo numero
 * \return NULL en caso de no poder conseguir espacio, de lo contrario el espacio para el dato
 */
eNumeros* newNum();

/** \brief Setea los campos del dato numero
 * \param  nombre ingresado
 * \param  numero ingresado
 * \return numero seteado
 *
 */
eNumeros* newNumParametro( char nombre[],int num);

/** \brief Lee y carga los datos de un Archivo
 * \param  puntero a File
 * \param  ArrayList
 * \param  nombre del archivo
 * \return 0 si no pudo cargar el archivo, 1 si lo pudo cargar correctamente
 *
 */
int parserNum(FILE* Archivo,ArrayList* lista,char nombreArch[]);

/** \brief imprime por pantalla un dato del tipo numero
 * \param  dato numero
 * \return la impresion del elemento
 *
 */
void Num_print(eNumeros* Emp);

/** \brief imprime Todos los datos que se encuentren en al Arraylist
 * \param  ArrayList donde se encuentran los datos
 * \return Lista de datos
 *
 */
void NumPrint(ArrayList* lista);

/** \brief se encarga de leer y cargar los datos a Memoria
 * \param  ArrayList
 * \param  Archivo
 * \return datos en memoria
 *
 */
void cargar(ArrayList* lista, FILE* archivo);

/** \brief Genera un archivo.csv
 * \param  Array list
 * \param  Puntero a FILE
 * \return un mensaje de alerta de si se pudo o no generar el archivo
 *
 */
void generarArchivo(ArrayList* lista,FILE* arch);


int isPar_impar(int num);
int isPrimo(int num);
