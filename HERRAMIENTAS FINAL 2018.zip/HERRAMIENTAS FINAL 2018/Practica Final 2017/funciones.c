#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <conio.h>

#include "arraylist.h"
#include "funciones.h"
#include "inputs.h"

void HardCodeProducto(ArrayList* lista)
{
    eProductos* Pro;

    Pro=(eProductos*)malloc(sizeof(eProductos));


    int idProducto[6]= {100,101,102,103,104,105};
    char descripcion[6][50]= {"Enduido INT","Latex INT","Sintetico","Barniz INT","Barniz EXT","Aguarras"};
    int i;

    for(i=0; i<6; i++)
    {
       Pro=(eProductos*)malloc(sizeof(eProductos));
       Pro->idProducto=idProducto[i];
       strcpy(Pro->nombrePro,descripcion[i]);


        if(lista!=NULL)
        {
          lista->add(lista,Pro);
        }


    }

}
//*************************************************************************
int GenerarID(ArrayList* lista,int idC)
{
    eClientes* Emp;
    int aux;
    if(lista->isEmpty(lista)==0)
    {
        Emp=(eClientes*)lista->get(lista,lista->len(lista)-1);
        aux=Emp->id;
        if(aux>0)
        {
            idC=aux+1;
        }
    }
    else
    {
        idC=1;
    }
    return idC;
}

//*************************************************************************
void addEmployeed(ArrayList* lista)
{
    char nombre[50];
    char apellido[50];
    int idC;
    int aux;
    //int estado;
    char Dni[30];
    eClientes* Emp;

    printf("Por favor ingrese su nombre: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",nombre);
    isWord(nombre);
    printf("Por favor ingrese su Apellido: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",apellido);
    isWord(apellido);
    printf("Por favor ingrese su Dni: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",Dni);
    isNumber(Dni);

    idC=GenerarID(lista,idC);

    Emp=newPersonParametros(nombre,apellido,Dni,idC);

    if(Emp!=NULL)
    {
        lista->add(lista,Emp);
        printf("\n Empleado cargado con exito\n");
    }


}

//**************************************************************************

//**************************************************************************
int employee_setName(eClientes* Emp, char nombre[])
{
    strcpy(Emp->nombre,nombre);
    return 0;

}
//***************************************************************************
int employee_setSurmane(eClientes* Emp, char Ape[])
{

   strcpy(Emp->Apellido,Ape);
    return 0;

}
//*****************************************************************************
int employee_setDni(eClientes* Emp, char Dni[])
{

    strcpy(Emp->Dni,Dni);
    return 0;


}
//******************************************************************************

//******************************************************************************
eClientes* newEmp()
{
    eClientes* aux;
    aux = (eClientes*) malloc (sizeof(eClientes));
    return aux;
}
//******************************************************************************
eClientes* newPersonParametros( char nombre[],char Apellido[], char Dni[],int id)
{
    eClientes* Emp;

    Emp = newEmp();
    if(Emp!=NULL)
    {
        strcpy(Emp->nombre,nombre);
        strcpy(Emp->Apellido,Apellido);
        strcpy(Emp->Dni,Dni);
        Emp->id=id;

    }

    return Emp;
}

//******************************************************************************
int parserEmployee(FILE* Archivo,ArrayList* lista,char nombreArch[])
{
    char  fitrs_name[50], Apellido[50],Dni[50];
    int idC;
    eClientes* emp;
    int retorno;

    Archivo=fopen(nombreArch,"r");
    if(Archivo==NULL||lista==NULL)
    {
        retorno=0;
    }
    else
    {

        fscanf(Archivo, "%[^,],%[^,],%[^\n]\n",fitrs_name,Apellido,Dni);

        while(!feof(Archivo))
        {

        fscanf(Archivo, "%[^,],%[^,],%[^\n]\n",fitrs_name,Apellido,Dni);
        idC=GenerarID(lista,idC);
        emp=newPersonParametros(fitrs_name,Apellido,Dni,idC);

            if(emp!=NULL)
            {

                employee_setName(emp,fitrs_name);
                employee_setSurmane(emp,Apellido);
                employee_setDni(emp,Dni);


                lista->add(lista,emp);
                if(feof(Archivo))
                {
                    break;
                }



            }

        }

        retorno=1;
    }


    fclose(Archivo);

    return retorno;

}
//*******************************************************************************
void employee_print(eClientes* Emp)
{
    printf("|%-10d\t\t%-12s\t\t%-15s\t\t%-14s|\n",Emp->id,Emp->nombre,Emp->Apellido,Emp->Dni);
}
//*******************************************************************************
void employeePrint(ArrayList* lista)
{
    eClientes* Emp;
    if(lista->isEmpty(lista)==0)
    {
        int i;
        printf("|=====================================================================================|\n");
        printf("|                               CLIENTES                                              |\n");
        printf("|=====================================================================================|\n");
        printf("|    ID         |      NOMBRES        |        APELLIDO       |          DNI          |\n");
        printf("|=====================================================================================|\n");
        for(i=0; i<lista->len(lista); i++)
        {
            if(i>0)
            {
                if(i%50==0)
                {
                    system("pause");
                }
            }
            Emp = al_get(lista,i);
            employee_print(Emp);
        }
    }
    else
    {
        printf("\nNo hay registro de empleados\n");
    }



}
//**********************************************************************
void cargar(ArrayList* lista, FILE* archivo)
{
    int Arch;
    char respuesta[30];
    printf("\nIngrese el nombre del archivo: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",respuesta);
    Arch=parserEmployee(archivo,lista,respuesta);
    if(Arch==0)
    {
        printf("\n Error al abrir el archivo\n");
    }
    else
    {
        printf("\n Archivo cargado con exito\n");

    }

}
//********************************************************
int buscarCliente(ArrayList* dato,int aux)
{
    int i;
    int retorno;
    eClientes* func;


    for(i=0; i<dato->len(dato); i++)
    {
        func=dato->get(dato,i);
        if(aux==func->id)
        {
            retorno=i;
            break;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;

}
//********************************************************
void respuestaMod(char confirm,char dato[])
{
                while(confirm!='s'&&confirm!='n')
                {
                    printf("ERROR\n");
                    printf("Desea realizar esta modificacion ? [s/n]");
                    setbuf(stdin,NULL);
                    confirm=getch();
                }
                if(confirm=='s')
                {
                    printf("\n Modificacion: ");
                    setbuf(stdin,NULL);
                    scanf("%[^\n]",dato);
                    isWord(dato);
                    printf("\n Modificacion realizada con Exito\n");
                }
                else
                {
                    printf("Accion cancelada por el Usuario");
                }
}
//********************************************************
void respuestaModNum(char confirm,char dato[])
{
                while(confirm!='s'&&confirm!='n')
                {
                    printf("ERROR\n");
                    printf("Desea realizar esta modificacion ? [s/n]");
                    setbuf(stdin,NULL);
                    confirm=getch();
                }
                if(confirm=='s')
                {
                    printf("\n Modificacion: ");
                    setbuf(stdin,NULL);
                    scanf("%[^\n]",dato);
                    isNumber(dato);
                    printf("\n Modificacion realizada con Exito\n");
                }
                else
                {
                    printf("Accion cancelada por el Usuario");
                }
}
//********************************************************
void modificarUsuario(ArrayList* dato)
{
    int aux,indice,opcion;
    char auxa[10];
    char respuesta='s';
    char auxOP[30];
    char confirm;
    eClientes* Cliente;
    printf("Ingres su numero de usuario: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxa);
    isNumber(auxa);
    indice=buscarCliente(dato,atoi(auxa));
    if(indice!=-1)
    {
        Cliente=dato->get(dato,indice);
        do
        {
            system("pause");
            system("cls");

            printf("1-Modificar nombre\n");
            printf("2-Modificar Apellido\n");
            printf("3-Modificar Documento\n");
            printf("4-Salir\n");
            printf("Ingrese una opcion: ");
            setbuf(stdin,NULL);
            scanf("%s",auxOP);
            isNumber(auxOP);
            opcion=atoi(auxOP);

            switch(opcion)
            {
            case 1:
                printf("Nombre: %s\n",Cliente->nombre);
                printf("Desea modificar el nombre de este usuario? [s/n]");
                setbuf(stdin,NULL);
                confirm=getch();
                respuestaMod(confirm,Cliente->nombre);

                break;
            case 2:
                printf("Apellido: %s\n",Cliente->Apellido);
                printf("Desea modificar el Apellido de este usuario? [s/n] ");
                setbuf(stdin,NULL);
                confirm=getch();
                respuestaMod(confirm,Cliente->Apellido);


            case 3:
                printf("DNI: %s\n",Cliente->Dni);
                printf("Desea modificar el DNI de este usuario? [s/n]");
                setbuf(stdin,NULL);
                confirm=getch();
                respuestaModNum(confirm,Cliente->Dni);


            case 4:
                respuesta='n';
                break;
            default:
                printf("Ingrese una opcion entre 1-4\n");

                break;
            }
          Cliente=dato->get(dato,indice);


        }while(respuesta=='s');
    }
    else
    {
        printf("Usuario inexistente\n");
    }

}
//********************************************************
void Baja(ArrayList* dato)
{
    int aux,i,indice;
    char confirm;
    char auxE[30];
    eClientes* cliente;


    printf("Ingres su numero de usuario: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxE);
    isNumber(auxE);
    aux=atoi(auxE);
    indice=buscarCliente(dato,aux);
    if(indice!=-1)
    {
        cliente=dato->get(dato,indice);
        employee_print(cliente);
        printf("Desea elimar este Usuario ? [s/n]");
        setbuf(stdin,NULL);
        confirm=getch();
        while(confirm!='s'&&confirm!='n')
        {
            printf("ERROR\n");
            printf("Desea elimar este Usuario ? [s/n]");
            setbuf(stdin,NULL);
            confirm=getch();
        }
        if(confirm=='s')
        {
            dato->remove(dato,indice);

            printf("\n Usuario Eliminado con Exito\n");
        }
        else
        {
            printf("Accion cancelada por el Usuario");
        }

    }
}
//********************************************************
/*void generarArchivo(ArrayList* lista )
{
    int i;
    eClientes* Emp;
    FILE* archivo;
    archivo = fopen("out.csv","w");

    if(archivo!=NULL)
    {
        if(lista->isEmpty(lista)==0)
        {
            for(i=0; i<al_len(lista); i++)
            {

                Emp = al_get(lista,i);

                fprintf(archivo,"%s,%d,%s\n",Emp->nombre,Emp->edad,Emp->prof);

            }
            printf("Archivo generado correctamente!\n");
        }
        else
        {
            printf("\nNo hay Registros de empleados para generar el archivo\n");
        }

    }
    else
    {
        printf("Ha ocurrido un error!\n");
    }
    fclose(archivo);

}*/
//***************************************************************
void Producto_print(eProductos* Pro)
{
     printf("|%-10d\t\t%-12s|\n",Pro->idProducto,Pro->nombrePro);
}
//***************************************************************
void ProductosPrint(ArrayList* lista)
{
    eProductos* Pro;
   if(lista->isEmpty(lista)==0)
    {
        int i;
        printf("|=====================================|\n");
        printf("|            PRODUCTOS                |\n");
        printf("|=====================================|\n");
        printf("|    ID         |      NOMBRES        |\n");
        printf("|=====================================|\n");
        for(i=0; i<lista->len(lista); i++)
        {
            if(i>0)
            {
                if(i%50==0)
                {
                    system("pause");
                }
            }
            Pro= al_get(lista,i);
            Producto_print(Pro);

        }
    }
    else
    {
        printf("\nNo hay registro de empleados\n");
    }



}
//***************************************************************
eVentas* newVenta()
{
    eVentas* aux;
    aux = (eVentas*) malloc (sizeof(eVentas));
    return aux;
}
//******************************************************************************
eVentas* newVentasParametros( int idCliente,int codigoPro,float costo,int cantidad,eFecha fecha,float importe)
{
    eVentas* Emp;

    Emp = newVenta();
    if(Emp!=NULL)
    {
       Emp->idClientes=idCliente;
       Emp->idArt=codigoPro;
       Emp->Uni=costo;
       Emp->cantidad=cantidad;
       Emp->fecha=fecha;
       Emp->importe=importe;

    }

    return Emp;
}
//******************************************************************************
void addVentas(ArrayList* lista,ArrayList* lista2)
{
    char idClientes[10];
    char idProducto[10];
    char costo[10];
    char cantidad[15];
    char auxF[10];
    int aux;
    float importe;
    eFecha fecha;


    char Dni[30];
    eVentas* Emp;

    printf("Por favor ingrese el Id de cliente: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",idClientes);
    isNumber(idClientes);
   while(buscarCliente(lista,atoi(idClientes))==-1)
   {
    printf("\nCliente inexistente\n");
    printf("Por favor ingrese el Id de cliente: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",idClientes);
    isNumber(idClientes);
    system("pause");
    system("cls");

   }
    ProductosPrint(lista2);
    printf("Por favor ingrese el codigo de Articulo: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",idProducto);
    isNumber(idProducto);
    printf("Por favor ingrese el costo de la Unidad: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",costo);
    isFloat(costo);
    printf("Por favor ingrese la cantidad de articulos: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",cantidad);
    isNumber(cantidad);
    printf("\nPor Favor ingrese la fecha: ");
    printf("\nDia: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxF);
    isNumber(auxF);
    fecha.dia=atoi(auxF);
    printf("\nMes: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxF);
    isNumber(auxF);
    fecha.mes=atoi(auxF);
    printf("\nAnio: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",auxF);
    isNumber(auxF);
    fecha.anio=atoi(auxF);

    importe=atof(costo)*atoi(cantidad);


    Emp=newVentasParametros(atoi(idClientes),atoi(idProducto),atof(costo),atoi(cantidad),fecha,importe);

    if(Emp!=NULL&&lista!=NULL)
    {
        lista->add(lista,Emp);
        printf("\n Venta cargada con exito\n");
    }

}
//*************************************************************
//int idCliente,int codigoPro,float costo,int cantidad,eFecha fecha,float importe
void Ventas_print(eVentas* Emp)
{
    printf("|%-10d\t\t%-12d\t\t%-15.2f\t\t%-14d\t\t%d/%d/%d\t\t%-14.2f|\n",Emp->idClientes,Emp->idArt,Emp->Uni,Emp->cantidad,Emp->fecha.dia,Emp->fecha.mes,Emp->fecha.anio,Emp->importe);
}
//*******************************************************************************
void VentasPrint(ArrayList* lista)
{
    eVentas* Emp;
    if(lista->isEmpty(lista)==0)
    {
        int i;
        printf("|==============================================================================================================|\n");
        printf("|                               CLIENTES                                                                       |\n");
        printf("|==============================================================================================================|\n");
        printf("|    ID CLIENTES       |      ID PRODUCTOS        |        COSTO/U       |       FECHA     |      IMPORTE      |\n");
        printf("|==============================================================================================================|\n");
        for(i=0; i<lista->len(lista); i++)
        {
            if(i>0)
            {
                if(i%50==0)
                {
                    system("pause");
                }
            }
            Emp = al_get(lista,i);
            Ventas_print(Emp);
        }
    }
    else
    {
        printf("\nNo hay ventas Realizadas\n");
    }



}
//*************************************************************
int VerifProducto(ArrayList* dato,int aux)
{
    int i;
    int retorno;
    eProductos* func;


    for(i=0; i<dato->len(dato); i++)
    {
        func=dato->get(dato,i);
        if(aux==func->idProducto)
        {
            retorno=i;
            break;
        }
        else
        {
            retorno=-1;
        }
    }

    return retorno;

}
//*************************************************************
void informePorProducto(ArrayList* listaPro,ArrayList* ventas)
{
    char aux[10];
    printf("Por favor ingrese el codigo del producto ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",aux);
    isNumber(aux);
    buscarCliente()

}

