#include <stdio.h>
#include <stdlib.h>
#include "arraylist.h"
#include "funciones.h"
#include "inputs.h"


int main()
{
    char seguir='s';
    int opcion=0;
    char respuesta[20];
    int Arch;
    int aux;
    int i;
    char auxOP[10];
    eClientes* auxEmpleados;
    ArrayList* listaCli;
    ArrayList* listaPro;
    ArrayList* listaVen;


    listaPro=al_newArrayList();
    listaCli = al_newArrayList();
    listaVen= al_newArrayList();
   //

    system("color 4F");


    FILE* archivo;

    while(seguir=='s')
    {HardCodeProducto(listaPro);
        opcion=menu(auxOP);

        switch(opcion)
        {
        case 1:
            addEmployeed(listaCli);
            system("pause");
            system("cls");

            break;
        case 2:modificarUsuario(listaCli);
            system("pause");
            system("cls");

            break;
        case 3: Baja(listaCli);
            system("pause");
            system("cls");

            break;
        case 4: employeePrint(listaCli);
            system("pause");
            system("cls");
            break;
        case 5: cargar(listaCli,archivo);
            system("pause");
            system("cls");
            break;
        case 6:
            employeePrint(listaCli);
            addVentas(listaVen,listaPro);
            system("pause");
            system("cls");
            break;
        case 7: VentasPrint(listaVen);
            system("pause");
            system("cls");
            break;
        case 8:
            system("pause");
            system("cls");
            break;
        case 9:
            seguir = 'n';

            system("pause");
            system("cls");
            break;

        default:
            system("pause");
            system("cls");
            printf("Ingrese una opcion entre 1-4\n");

        }


    }
    return 0;

}
