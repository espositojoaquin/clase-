#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include"inputs.h"
#include "ArrayList.h"
#include <string.h>
#include "Employee.h"


/*int parserEmployee(FILE* pFile , ArrayList* pArrayListEmployee)
{
    return 0;
}*/
//***********************************************
Employee* newEmp()
{
    Employee* aux;
    aux = (Employee*) malloc (sizeof(Employee));
    return aux;
}
//***********************************************
Employee* newPersonParametros( char nombre[],int estado,int id,char Apellido[])
{
    Employee* Emp;
    ArrayList* lista;


    Emp = newEmp();
    if(Emp!=NULL)
    {
        strcpy(Emp->name,nombre);
        Emp->id=id;
        Emp->isEmpty=estado;
        strcpy(Emp->lastName,Apellido);


    }

    return Emp;
}
//***********************************************
int parserEmployee( FILE* Archivo,ArrayList* lista)
{
    char  id[50],fitrs_name[50], last_name[50],empty[50];
    Employee* emp;
    int retorno;

    Archivo=fopen("data.csv","r");
    if(Archivo==NULL||lista==NULL)
    {
        retorno=0;
    }
    else
    {    //parserEmployee

        fscanf(Archivo, "%[^,],%[^,],%[^,],%[^\n]\n",id,fitrs_name,last_name,empty);

        while(!feof(Archivo))
        {

          fscanf(Archivo, "%[^,],%[^,],%[^,],%[^\n]\n",id,fitrs_name,last_name,empty);

            emp=newPersonParametros(fitrs_name,empty,id,last_name);
            if(emp!=NULL)
            {
                //emp->id=atoi(id);
                employee_setId(emp,atoi(id));
                employee_setName(emp,fitrs_name);
                employee_setlastName(emp,last_name);
               // strcpy(emp->name,fitrs_name);
               // strcpy(emp->lastName,last_name);
                if(strcmp(empty,"true")==0)
                {
                    emp->isEmpty=1;
                }
                else
                {
                    emp->isEmpty=0;
                }


                al_add(lista,emp);


            }

        }

        retorno=1;
    }


    fclose(Archivo);

    return retorno;


}
