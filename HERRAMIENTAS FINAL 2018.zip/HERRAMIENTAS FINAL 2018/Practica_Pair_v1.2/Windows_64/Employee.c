#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include"inputs.h"
#include "ArrayList.h"
#include "Employee.h"


int employee_compare(void* pEmployeeA,void* pEmployeeB)
{
    int aux;
    Employee* e1=(Employee*) pEmployeeA;

    Employee* e2=(Employee*) pEmployeeB;
    aux=(Employee*) strcmp(e1->name,e2->name);

    return aux;

}


void employee_print(Employee* Emp)
{
    printf("|%-5d\t\t%-10s\t\t %-15s\t %-15d|\n",Emp->id,Emp->name,Emp->lastName,Emp->isEmpty);
}

void employeePrint(ArrayList* lista)
{
    Employee* Emp;
    if(lista->isEmpty(lista)==0)
    {
        int i;
        printf("|===============================================================================|\n");
        printf("|                               EMPLEADOS                                        \n");
        printf("|===============================================================================|\n");
        printf("| ID      |       NAME       |        LAST NAME     |         EMPTY                  \n");
        printf("|===============================================================================|\n");
        for(i=0; i<lista->len(lista); i++)
        {
            Emp=(Employee*)lista->get(lista,i);


            employee_print(Emp);
            printf("|===============================================================================|\n");
            if(i>0)
            {
                if(i%50==0)
                {
                    system("pause");
                }
            }

        }
    }
    else
    {
        printf("\nNo hay equipos ingresados");
    }

}


Employee* employee_new(void)
{

    Employee* returnAux = NULL;

    return returnAux;

}

void employee_delete(ArrayList* lista)
{
    int indice;
    int aux;
    char respuesta;
    printf("\nPor favor ingrese el numero de usuario que desea dar de baja\n");
    scanf("%d",&aux);
    indice=buscarEmpleado(lista,aux);
    while(indice==-1)
    {
        printf("\nPor favor Reingrese el numero de usuario que desea dar de baja\n");
        scanf("%d",&aux);
        indice=buscarEmpleado(lista,aux);
    }
    if(indice!=-1)
    {
        //employee_print()
        printf("\nEstas Seguro que desea eliminar a este empleado? s/n \n");
        setbuf(stdin,NULL);
        respuesta=getch();
        if(respuesta=='s')
        {
            lista->remove(lista,indice);
            printf("\n Usuario eliminado con exito\n");
        }
    }



}

int employee_setId(Employee* Emp, int id)
{
    Emp->id=id;
    return 0;

}

int employee_getId(Employee* this)
{

    return 0;

}
//***************************************
int employee_setName(Employee* Emp, char nombre[])
{
    //Emp->name;
    strcpy(Emp->name,nombre);
    return 0;

}
//***************************
int employee_setlastName(Employee* Emp, char lastName[])
{
    strcpy(Emp->lastName,lastName);
    //Emp->lastName;
    return 0;

}
//***************************************
int comparaPersonas(void* pEmployeeA,void* pEmployeeB)
{
    int aux;
    Employee* e1=(Employee*) pEmployeeA;

    Employee* e2=(Employee*) pEmployeeB;
    aux=(Employee*) strcmp(e1->name,e2->name);

    return aux;

}
//*********************************************
void addEmployeed(ArrayList* lista)
{
    char nombre[50];
    char apellido[50];
    int id;
    int aux;
    int estado;
    Employee* Emp;

    printf("Por favor ingrese su nombre: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",nombre);
    isWord(nombre);
    printf("Por favor ingrese su Apellido: ");
    setbuf(stdin,NULL);
    scanf("%[^\n]",apellido);
    isWord(apellido);
    if(lista->isEmpty(lista)==0)
    {
        Emp=(Employee*)lista->get(lista,lista->len(lista)-1);
        aux=Emp->id;
        if(aux>0)
        {
            id=aux+1;
        }
    }
    else
    {
        id=1;
    }
    estado=1;
    Emp=newPersonParametros(nombre,estado,id,apellido);

    if(Emp!=NULL)
    {
        lista->add(lista,Emp);
        printf("\n Empleado cargado con exito\n");
    }


}
//*************************************
int buscarEmpleado(ArrayList* lista,int aux)
{
    int i,flag=0;
    int retorno;
    Employee* Emp;

    for(i=0; i<lista->len(lista); i++)
    {
        Emp=(Employee*)lista->get(lista,i);
        if(aux==Emp->id)
        {

            retorno=i;
            flag=1;
            break;

        }
        if(flag==0)
        {
            retorno=-1;
        }
    }
    return retorno;
}
//******************************************************

void ListarDesdeHasta(ArrayList* pList)
{
    int from;
    int to;
    char respuesta[30];
    ArrayList* nuevoArray;

    nuevoArray=al_newArrayList();

    if(pList!=NULL)
    {
        printf("\n Desde dondee desea mostrar los empleados?\n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",respuesta);
        isNumber(respuesta);
        from=atoi(respuesta);
        printf("\n Hasta dondee desea mostrar los empleados?\n");
        setbuf(stdin,NULL);
        scanf("%[^\n]",respuesta);
        isNumber(respuesta);
        to=atoi(respuesta);

        if(nuevoArray!=NULL)
        {
            nuevoArray=pList->subList(pList,from,to);

            employeePrint(nuevoArray);

        }
    }



}
