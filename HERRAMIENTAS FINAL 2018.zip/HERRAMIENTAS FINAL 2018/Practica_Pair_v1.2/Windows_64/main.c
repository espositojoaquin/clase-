#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include"inputs.h"
#include "ArrayList.h"
#include "Employee.h"

/****************************************************
    Menu:
        1. Parse del archivo data.csv
        2. Listar Empleados
        3. Ordenar por nombre
        4. Agregar un elemento
        5. Elimina un elemento
        6. Listar Empleados (Desde/Hasta)
*****************************************************/


int main()
{
   char seguir='s';
    int opcion=0;
    int Arch;
    char auxOP[10];
    ArrayList* lista;
    lista = al_newArrayList();
    system("color 4F");
    int i;

    FILE* archivo;

    while(seguir=='s')
    {
        opcion=menu(auxOP);

        switch(opcion)
        {
        case 1:
            Arch=parserEmployee(archivo,lista);
            if(Arch==0)
            {
                printf("\n Error al abrir el archivo\n");
            }
            else
            {
                printf("\n Archivo cargado con exito\n");

            }

            system("pause");
            system("cls");

            break;
        case 2: employeePrint(lista);


            system("pause");
            system("cls");

            break;
        case 3:     lista->sort(lista,employee_compare,1);
                    employeePrint(lista);

            system("pause");
            system("cls");


            break;
        case 4:addEmployeed(lista);

            system("pause");
            system("cls");


            break;
        case 5: employee_delete(lista);

            system("pause");
            system("cls");
            break;
        case 6: ListarDesdeHasta(lista);

            system("pause");
            system("cls");


            break;
        case 7:
            seguir = 'n';

            system("pause");
            system("cls");
            break;

            default:
            printf("Ingreso una opcion incorrecta! \n");
            break;
        }
    }


    return 0;
}
