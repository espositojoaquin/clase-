
int verifNumero(char cad[]);
void isNumber(char aux[]);
int verifFloat(char cad[]);
void isFloat(char aux[]);
int EsLetra(char letras[]);
void isWord(char aux[]);
int VefAphaandNumber(char aux[]);
void isAlphaNumber(char aux []);
int menu(char auxOP[]);
