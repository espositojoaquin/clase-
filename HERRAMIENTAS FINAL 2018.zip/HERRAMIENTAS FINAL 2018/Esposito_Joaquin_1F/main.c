#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arraylist.h"
#include "funciones.h"

int main()
{
    char seguir='s';
    int opcion=0;
    char respuesta[20];
    int Arch;
    int aux;
    int i;
    char auxOP[10];
    eEmpleado* auxEmpleados;
    ArrayList* lista;

    lista = al_newArrayList();

    system("color 4E");
    printf("\n\n\n\n\n\n\n\n\t\t\t\t DAVID EL MAS GRANDE\n\n\n\n\n\n\n\n\n\n");
    system("pause");
    system("cls");

    system("color 4F");


    FILE* archivo;

    while(seguir=='s')
    {
        opcion=menu(auxOP);

        switch(opcion)
        {
        case 1:
            cargar(lista,archivo);
            system("pause");
            system("cls");

            break;

        case 2:

            system("color 1F");
            lista->map(lista,em_calcularSueldo);
            system("cls");
            employeePrint(lista);

            system("pause");
            system("cls");
            system("color 4F");

            break;
        case 3:
            generarArchivo(lista);

            system("pause");
            system("cls");

            break;

        case 4:
            seguir = 'n';

            system("pause");
            system("cls");
            break;

        default:
            system("pause");
            system("cls");
            printf("Ingrese una opcion entre 1-4\n");

        }


    }
    return 0;

}
