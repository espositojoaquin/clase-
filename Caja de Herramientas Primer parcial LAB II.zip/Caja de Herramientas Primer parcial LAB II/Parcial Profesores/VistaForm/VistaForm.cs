﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace VistaForm
{
    
  public partial class VistaForm : Form
  {
      Curso curso; 
    public VistaForm()
    {
      InitializeComponent();
    }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        private void InicializarComponentes()
        {
            cmbDivisionCurso.DataSource = Enum.GetValues(typeof(Divisiones));
            cmbDivision.DataSource= Enum.GetValues(typeof(Divisiones));

        }
        private void VistaForm_Load(object sender, EventArgs e)
        {
            InicializarComponentes();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            Profesor profesor = new Profesor(txtNombreProfe.Text, txtApellidoProfe.Text, txtDocumentoProfe.Text);
            Divisiones division;
        
            Enum.TryParse<Divisiones>(cmbDivisionCurso.SelectedValue.ToString(), out division);
            this.curso = new Curso((short)nudAnioCurso.Value, division, profesor);
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            string validar=(string)curso;
            if (validar != "NULL")
            {
                rtbDatos.Text = validar;
            }
            else
            {
                MessageBox.Show("Curso Inexistente", "Registro de Cursos", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Divisiones division;
            Enum.TryParse<Divisiones>(cmbDivision.SelectedValue.ToString(), out division);
            Alumno alumno = new Alumno(txtNombre.Text, txtApellido.Text, txtLegajo.Text, (short)nudAnio.Value, division);

            this.curso += alumno;
        }
    }
}
