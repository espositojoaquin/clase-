using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace VistaConsola
{
  class Program
  {
    static void Main(string[] args)
    {
            // Genero un curso nuevo
            Curso curso = new Curso(2, Divisiones.A, new Profesor("Fede", "D�vila", "12345678", new
            DateTime(2015, 03, 20)));
            // Genero alumnos...
            Alumno a6 = new Alumno("Juan", "L�pez", "22-3333-2", 2, Divisiones.A);
            Alumno a1 = new Alumno("Juan", "L�pez", "22-3333-2", 2, Divisiones.A);
            Alumno a2 = new Alumno("Jos�", "Mart�nez", "23-3343-6", 2, Divisiones.B);
            Alumno a3 = new Alumno("Mar�a", "Guti�rrez", "22-3333-2", 2, Divisiones.A);
            Alumno a4 = new Alumno("Marta", "Rodr�guez", "23-3343-6", 2, Divisiones.A);
            Alumno a5 = new Alumno("Marta", "Rodr�guez", "233343126", 2, Divisiones.A);
            // ... Y los agrego al curso
            curso += a1;
            curso += a2;
            curso += a3;
            curso += a4;
            curso += a5;
            // Imprimo los datos del curso
          
            Console.WriteLine((string)curso);
  

        
           
            
            Console.ReadKey();
        }
  }
}
