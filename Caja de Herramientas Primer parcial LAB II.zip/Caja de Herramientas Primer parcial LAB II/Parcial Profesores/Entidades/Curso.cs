using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public enum Divisiones
    {
        A, B, C, D, E

    }
    public class Curso
    {
        public List<Alumno> alumnos;
        private short anio;
        private Divisiones division;
        private Profesor profesor;

        public string AnioDivision
        {
            get
            {
                StringBuilder s = new StringBuilder();
                s.AppendFormat("{0}�{1}", this.anio, this.division);
                return s.ToString();
            }
        }
        private Curso()
        {
            this.alumnos = new List<Alumno>();
        }
        public Curso(short anio,Divisiones div,Profesor prof):this()
        {
            this.anio = anio;
            this.division = div;
            this.profesor = prof;
        }

        public static explicit  operator string(Curso cur)
        {
            string retorno;
            if(cur is null)
            {
                retorno = "NULL";
            }
            else
            {
             StringBuilder sb = new StringBuilder();

            sb.AppendFormat("{0} Profesor:{1} {2} \n", cur.AnioDivision, cur.profesor.Nombre, cur.profesor.Apellido);

             foreach (Alumno item in cur.alumnos)
             {
                 sb.AppendFormat(item.ExponerDatos());
             }
                retorno = sb.ToString();
            }
          
            return retorno;
        }

        public static Curso operator +(Curso cur,Alumno alu)
        {
            if(cur==alu)
            {
                 cur.alumnos.Add(alu);
            }
            return cur;

        }
        public static bool operator==(Curso cur, Alumno alu)
        {
            /* bool retorno=false;
             if (cur.AnioDivision == alu.AnioDivision)
             {
                 retorno = true;
             }*/
            return cur.AnioDivision == alu.AnioDivision;

        }
        public static bool operator !=(Curso cur, Alumno alu)
        {
            return !(cur==alu);
        }





    }
}
