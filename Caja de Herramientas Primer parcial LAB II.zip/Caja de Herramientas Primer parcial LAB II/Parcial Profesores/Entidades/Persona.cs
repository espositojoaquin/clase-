using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Entidades
{
    public abstract class Persona
    {
        string apellido;
        string nombre;
        string documento;

        public string Apellido
        {
            get
            {
                return this.apellido;
            }

        }
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
        }
        public string Documento
        {
            get
            {
                return this.documento;
            }
            set
            {
                this.documento = value;
            }
        }
        public Persona(string nom, string ape, string doc)
        {
            this.nombre = nom;
            this.apellido = ape;
            this.documento = doc;
        }
        public virtual string ExponerDatos()
        {
            StringBuilder sb = new StringBuilder();

            if (ValidarDocumentacion(this.documento))
            {
                sb.AppendFormat("\nNombre : {0}\nApellido: {1}\nDNI: {2} ", this.nombre, this.apellido, this.documento);
            }
            else
            {
                sb.AppendFormat("\nNombre : {0}\nApellido: {1}\nDNI: Error ", this.nombre, this.apellido);
            }

            sb.AppendLine("");


            return sb.ToString();
        }

        public abstract bool ValidarDocumentacion(string doc);

    }
}
