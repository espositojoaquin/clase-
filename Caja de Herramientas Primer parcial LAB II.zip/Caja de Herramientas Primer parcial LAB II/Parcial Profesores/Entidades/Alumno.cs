using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
   public class Alumno : Persona
    {
        private short anio;
        private Divisiones division;

        public string AnioDivision
        {
            get
            {
                StringBuilder s = new StringBuilder();
                s.AppendFormat("{0}º{1}", this.anio, this.division);
                return s.ToString();
            }
        }
        public Alumno(string nombre, string apellido, string DNI, short anio, Divisiones div) : base(nombre, apellido, DNI)
        {
            this.anio = anio;
            this.division = div;
        }

        public override string ExponerDatos()
        {
            return base.ExponerDatos() +"\nCurso: "+this.AnioDivision+"\n------------------------";
        }

        public override bool ValidarDocumentacion(string doc)
        {
            bool retorno = false;
            bool verif = false;
            int num;
            int i;
            if (doc.Length == 9)
            {
                doc.ToCharArray();
               
                if (doc[2] == '-' && doc[7] == '-')
                {
                    for (i = 0; i < 9; i++)
                    {
                        if (i != 2 && i != 7)
                        {
                            if (verif = int.TryParse(char.ToString(doc[i]), out num))
                            {
                                retorno = true;
                            }
                            else
                            {
                                retorno = false;
                                break;

                            }
                        }

                    }

                }
            }

            return retorno;

        }








    }
}
