﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
 public class Profesor:Persona
  {
        DateTime fechaIngreso;

        public Profesor(string nombre,string apellido,string Documento):base(nombre,apellido,Documento)
        {

        }
        public Profesor(string nombre, string apellido, string Documento,DateTime Fecha):this(nombre,apellido,Documento)
        {
            this.fechaIngreso = Fecha;
        }
        public int Antiguedad
        {
            get
            {
                return DateTime.Now.Day - this.fechaIngreso.Day;
            }
        }
        public override bool ValidarDocumentacion(string doc)
        {
            bool retorno=false;
            bool verif = false;
            int num;
           if(doc.Length==8)
            {
                verif = int.TryParse(doc, out num);
                if(verif)
                {
                    retorno = true;
                }
            }
            return retorno;
           
        }
        public override string ExponerDatos()
        {
            return base.ExponerDatos()+""+"\nFecha de ingreso"+this.fechaIngreso.ToString();
        }

    }
}
