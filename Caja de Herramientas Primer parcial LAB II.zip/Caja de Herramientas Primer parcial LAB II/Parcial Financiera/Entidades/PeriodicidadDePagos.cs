﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    namespace PrestamosPersonales
    {
        #region "Enumerados"
        public enum PeriodicidadDePagos
        {
            Mensual, Bimestral, Trimestral
        }
        #endregion
    }
}
