#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Funciones.h"

int main()
{
    char seguir='s';
    int opcion=0;
    int Arch;
    ArrayList* lista;
    lista = al_newArrayList();
    int i;

    FILE* archivo;

    while(seguir=='s')
    {
        printf("1- Agregar Equipo\n");
        printf("2- Listar clubes\n");
        printf("3- Descender club\n");
        printf("4- Modificar datos del club\n");
        printf("5- Eliminar todos los equipos\n");
        printf("6- Ingresar un equipo en la posicion especificada\n");
        printf("7- Ordenar por posicion\n");
        printf("8  Cargar Equipos\n");
        printf("9- Clasificados a la Libertadores\n");
        printf("10- Salir\n");

        printf("\nIngrese una opcion: ");
        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:
            agregarClub(lista);

            system("pause");
            system("cls");

            break;
        case 2:

            if(lista->isEmpty(lista))
            {
                printf("No se han cargado equipos\n");
            }
            else
            {
                mostrarClub(lista);
            }
            system("pause");
            system("cls");

            break;
        case 3:
            EliminarClub(lista);
            system("pause");
            system("cls");


            break;
        case 4:
            ModifocarClub(lista);
            system("pause");
            system("cls");


            break;
        case 5:
            if(lista->clear(lista)==0)
            {
                printf("Todos los equipos fueron eliminados");
            }
            system("pause");
            system("cls");
            break;
        case 6:
            PosicionEspecificada(lista);
            system("pause");
            system("cls");


            break;
        case 7:
            lista->sort(lista,comparaEquipo,1);
            mostrarClub(lista);
            system("pause");
            system("cls");
            break;
        case 8:
            Arch=LeerEquipos(archivo,lista);
            if(Arch==0)
            {
                printf("\n Error al abrir el archivo\n");
            }
            else
            {
                printf("\n Archivo cargado con exito\n");

            }
            system("pause");
            system("cls");

            break;
        case 9:
            if(lista->isEmpty(lista)==0)
            {
                EquiposLIB(lista);
            }
            else
            {
                printf("\n No Hay Equipos clasificados\n");
            }
            break;
        case 10:
            seguir = 'n';
            break;
        default:
            printf("Ingreso una opcion incorrecta! \n");
            break;
        }
    }



    return 0;
}
